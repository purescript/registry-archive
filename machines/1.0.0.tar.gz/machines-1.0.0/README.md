# purescript-machines

[![Latest release](http://img.shields.io/bower/v/purescript-machines.svg)](https://github.com/purescript-contrib/purescript-machines/releases)
[![Build Status](https://travis-ci.org/purescript-contrib/purescript-machines.svg?branch=master)](https://travis-ci.org/purescript-contrib/purescript-machines)

This library helps you build finite state machines. Currently, there's an implementation for Mealy machines with halting.

## Installation

```shell
bower i purescript-machines
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-machines).
