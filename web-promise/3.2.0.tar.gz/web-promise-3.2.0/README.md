# DEPRECATED

Promises work on Node and in the browser, so this library has been deprecated. The same functionality can be found in the platform-agnostic [`purescript-js-promise`](https://github.com/purescript-contrib/purescript-js-promise) library.

Versions of `purescript-web-promise` up to [3.0.1](https://github.com/purescript-web/purescript-web-promise/releases/tag/v3.1.0) continue to work.
