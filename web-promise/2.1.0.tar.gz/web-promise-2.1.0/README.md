# purescript-web-promise

[![Latest release](http://img.shields.io/github/release/purescript-web/purescript-web-promise.svg)](https://github.com/purescript-web/purescript-web-promise/releases)
[![Build status](https://github.com/purescript-web/purescript-web-promise/workflows/CI/badge.svg?branch=master)](https://github.com/purescript-web/purescript-web-promise/actions?query=workflow%3ACI+branch%3Amaster)
[![Pursuit](https://pursuit.purescript.org/packages/purescript-web-promise/badge)](https://pursuit.purescript.org/packages/purescript-web-promise)

Types and low-level implementations for JavaScript Promises.

## Installation

```
spago install web-promise
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-web-promise).

