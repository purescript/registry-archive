# PureScript Howl
A PureScript wrapper for howler.js 2
