/* global exports */

// module Control.Monad.Eff.WebGL


    "use strict";

    exports.runWebGl_ = function (f) {
      return f;
  };
