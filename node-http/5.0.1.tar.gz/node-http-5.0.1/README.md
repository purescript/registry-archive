# purescript-node-http

[![Latest release](http://img.shields.io/github/release/purescript-node/purescript-node-http.svg)](https://github.com/purescript/purescript-node-http/releases)
[![Build Status](https://travis-ci.org/purescript-node/purescript-node-http.svg?branch=master)](https://travis-ci.org/purescript-node/purescript-node-http)

A wrapper for Node's HTTP APIs.

## Installation

```
bower install purescript-node-http
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-node-http).
