# purescript-node-http

A wrapper for Node's HTTP APIs

- [Module Documentation](docs/Node)
- [Example](test/Main.purs)
