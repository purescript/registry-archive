# purescript-node-http

A wrapper for Node's HTTP server API

- [Module Documentation](docs/Node)
- [Example](test/Main.purs)
