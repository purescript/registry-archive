# purescript-datetime

[![Latest release](http://img.shields.io/bower/v/purescript-datetime.svg)](https://github.com/purescript/purescript-datetime/releases)
[![Build Status](https://travis-ci.org/purescript/purescript-datetime.svg?branch=master)](https://travis-ci.org/purescript/purescript-datetime)
[![Dependency Status](https://www.versioneye.com/user/projects/55848c1636386100150003d4/badge.svg?style=flat)](https://www.versioneye.com/user/projects/55848c1636386100150003d4)

Date and time types and functions.

## Installation

```
bower install purescript-datetime
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-datetime).
