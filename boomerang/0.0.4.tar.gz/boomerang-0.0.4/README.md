### purescript-boomerang

This library contains (basic) implementation of invertible parserers and priters. Using these (semi)isomorphic stuctures with provided combinators should allow simple definition of bidirectional web routes, so URL path can be transfored to value and value can transfored into URL path.

This is an attempt to create purescript clone of haskell's boomerang library, and it is really early stage of developement...

Look into `test/Main.purs` for some simple examples...
