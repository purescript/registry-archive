An attempt to create purescript clone of haskell's boomerang library.
