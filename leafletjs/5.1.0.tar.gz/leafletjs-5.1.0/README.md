Basic bindings to leaflet.js only parts of API is supported.

This repo also has port of [simpleheat](https://github.com/mourner/simpleheat) and
[Leaflet.heat](https://github.com/Leaflet/Leaflet.heat)
