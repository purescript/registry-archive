# purescript-isotypes

iso for common newtypes.

## Installation

```
bower install purescript-isotypes
```

## Documentation

See on [Pursuit](https://pursuit.purescript.org/packages/purescript-isotypes/).

Or build docs with `npm run build:docs`.
