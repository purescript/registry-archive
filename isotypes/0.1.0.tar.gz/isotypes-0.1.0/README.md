# purescript-isotype

iso for common newtypes.
