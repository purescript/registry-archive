# purescript-freet

[![Latest release](http://img.shields.io/github/release/purescript-contrib/purescript-freet.svg)](https://github.com/purescript-contrib/purescript-freet/releases)
[![Build Status](https://travis-ci.org/purescript-contrib/purescript-freet.svg?branch=master)](https://travis-ci.org/purescript-contrib/purescript-freet)
[![Maintainer: paf31](https://img.shields.io/badge/maintainer-paf31-lightgrey.svg)](http://github.com/paf31)
[![Pursuit](http://pursuit.purescript.org/packages/purescript-freet/badge)](http://pursuit.purescript.org/packages/purescript-freet/)

Free monad transformers.

## Installation

```
bower install purescript-freet
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-freet).
