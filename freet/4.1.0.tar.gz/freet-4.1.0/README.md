# purescript-freet

[![Latest release](http://img.shields.io/github/release/purescript-contrib/purescript-freet.svg)](https://github.com/purescript-contrib/purescript-freet/releases)
[![Build status](https://travis-ci.org/purescript-contrib/purescript-freet.svg?branch=master)](https://travis-ci.org/purescript-contrib/purescript-freet)
[![Pursuit](http://pursuit.purescript.org/packages/purescript-freet/badge)](http://pursuit.purescript.org/packages/purescript-freet/)
[![Maintainer: garyb](https://img.shields.io/badge/maintainer-garyb-lightgrey.svg)](http://github.com/garyb)
[![Maintainer: thomashoneyman](https://img.shields.io/badge/maintainer-thomashoneyman-lightgrey.svg)](http://github.com/thomashoneyman)

Free monad transformers.

## Installation

```
bower install purescript-freet
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-freet).

## Contributing

Read the [contribution guidelines](https://github.com/purescript-contrib/purescript-freet/blob/master/.github/contributing.md) to get started and see helpful related resources.
