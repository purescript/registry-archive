# purescript-freet

Free monad transformers

- [Module Documentation](docs/Control/Monad/Free/Trans.md)
- [Example](test/Main.purs)
