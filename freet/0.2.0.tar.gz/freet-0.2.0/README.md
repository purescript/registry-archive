# purescript-freet

[![Pursuit](http://pursuit.purescript.org/packages/purescript-freet/badge)](http://pursuit.purescript.org/packages/purescript-freet/)

Free monad transformers

- [Module Documentation](docs/Control/Monad/Free/Trans.md)
- [Example](test/Main.purs)
