# purescript-freet

[![Latest release](http://img.shields.io/bower/v/purescript-freet.svg)](https://github.com/purescript-contrib/purescript-freet/releases)
[![Maintainer: paf31](https://img.shields.io/badge/maintainer-paf31-lightgrey.svg)](http://github.com/paf31)
[![Pursuit](http://pursuit.purescript.org/packages/purescript-freet/badge)](http://pursuit.purescript.org/packages/purescript-freet/)

Free monad transformers

- [Module Documentation](docs/Control/Monad/Free/Trans.md)
- [Example](test/Main.purs)
