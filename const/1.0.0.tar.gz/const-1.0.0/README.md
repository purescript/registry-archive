# purescript-const

[![Latest release](http://img.shields.io/bower/v/purescript-const.svg)](https://github.com/purescript/purescript-const/releases)
[![Build Status](https://travis-ci.org/purescript/purescript-const.svg?branch=master)](https://travis-ci.org/purescript/purescript-const)
[![Dependency Status](https://www.versioneye.com/user/projects/55848c9e363861001b0001a2/badge.svg?style=flat)](https://www.versioneye.com/user/projects/55848c9e363861001b0001a2)

Constant data type.

## Installation

```
bower install purescript-const
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-const).
