PureScript Const
================

Const type classes and instances for PureScript.
