# purescript-const

[![Latest release](http://img.shields.io/github/release/purescript/purescript-const.svg)](https://github.com/purescript/purescript-const/releases)
[![Build status](https://travis-ci.org/purescript/purescript-const.svg?branch=master)](https://travis-ci.org/purescript/purescript-const)

Constant data type.

## Installation

```
bower install purescript-const
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-const).
