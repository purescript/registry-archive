# purescript-const

[![Latest release](http://img.shields.io/github/release/purescript/purescript-const.svg)](https://github.com/purescript/purescript-const/releases)
[![Build status](https://github.com/purescript/purescript-const/workflows/CI/badge.svg?branch=master)](https://github.com/purescript/purescript-const/actions?query=workflow%3ACI+branch%3Amaster)
[![Pursuit](https://pursuit.purescript.org/packages/purescript-const/badge)](https://pursuit.purescript.org/packages/purescript-const)

Constant data type.

## Installation

```
spago install const
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-const).
