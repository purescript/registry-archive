# purescript-const

[![Build Status](https://travis-ci.org/purescript/purescript-const.svg?branch=master)](https://travis-ci.org/purescript/purescript-const)

Constant data type.

## Installation

```
bower install purescript-const
```

## Module documentation

- [Data.Const](docs/Data.Const.md)
