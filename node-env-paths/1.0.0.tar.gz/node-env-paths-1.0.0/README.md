# purescript-node-env-paths

A PureScript port of [`env-paths`](https://github.com/sindresorhus/env-paths) ([NPM library](https://www.npmjs.com/package/env-paths)).

## License Requirements

- [`env-paths`](https://github.com/sindresorhus/env-paths) - MIT
