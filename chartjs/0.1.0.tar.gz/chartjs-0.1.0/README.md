# purescript-chartjs
Purescript bindings for chartjs

View the module documentation [here](MODULES.md).

Check out the [example](example/) directory for an example usage.

Note that right now it doesn't allow you to configure the graphs since the defaults worked for me initially. Working on that next!
