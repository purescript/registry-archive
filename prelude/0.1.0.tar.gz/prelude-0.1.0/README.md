# purescript-prelude

[![Build Status](https://travis-ci.org/purescript/purescript-prelude.svg?branch=master)](https://travis-ci.org/purescript/purescript-prelude)

The PureScript prelude. For use with compiler version >= 0.7.

## Installation

```
bower install purescript-prelude
```

## Module documentation

- [Prelude](docs/Prelude.md)
