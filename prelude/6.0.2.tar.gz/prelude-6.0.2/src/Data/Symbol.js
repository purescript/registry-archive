// module Data.Symbol

export const unsafeCoerce = function (arg) {
  return arg;
};

