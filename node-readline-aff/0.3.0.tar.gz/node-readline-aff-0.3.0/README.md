# purescript-node-readline-aff

[![Latest release](http://img.shields.io/bower/v/purescript-node-readline-aff.svg)](https://github.com/ChrisPenner/purescript-node-readline-aff/releases)
[![Build Status](https://travis-ci.org/ChrisPenner/purescript-node-readline-aff.svg?branch=master)](https://travis-ci.org/purescript/purescript-node-readline-aff)

## Installation

```
bower install purescript-node-readline-aff
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-node-readline-aff).
