'use strict';

const RN = require('react-native');

exports.platformVersion = RN.Platform.Version;
exports.platformSelect = RN.Platform.select
exports.platformOSImpl = RN.Platform.OS
