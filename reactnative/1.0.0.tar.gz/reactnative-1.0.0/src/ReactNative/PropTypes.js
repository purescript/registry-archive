'use strict';

exports.nativeImageSource = require("nativeImageSource");
