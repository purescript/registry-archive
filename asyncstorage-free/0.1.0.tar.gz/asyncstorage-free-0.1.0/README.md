# purescript-asyncstorage-free

A library modeling operations on async storage.

## Installation

```bash
bower install --save purescript-asyncstorage-free
```
