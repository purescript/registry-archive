# purescript-dom-filereader
Aff-based wrappers for FileReader API based on top of purescript-dom

An example is available in `test/`, which can be viewed with `npm test`.

# Documentation

Available on [Pursuit](https://pursuit.purescript.org/packages/purescript-dom-filereader/).
