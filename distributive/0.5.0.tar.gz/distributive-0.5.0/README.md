# purescript-distributive

[![Build Status](https://travis-ci.org/purescript/purescript-distributive.svg?branch=master)](https://travis-ci.org/purescript/purescript-distributive)

Distributive typeclass - the categorical dual of `Traversable`.

## Installation

```
bower install purescript-distributive
```

## Module documentation

- [Data.Distributive](docs/Data.Distributive.md)
