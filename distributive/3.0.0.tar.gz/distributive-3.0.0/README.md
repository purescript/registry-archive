# purescript-distributive

[![Latest release](http://img.shields.io/github/release/purescript/purescript-distributive.svg)](https://github.com/purescript/purescript-distributive/releases)
[![Build status](https://travis-ci.org/purescript/purescript-distributive.svg?branch=master)](https://travis-ci.org/purescript/purescript-distributive)

Distributive typeclass - the categorical dual of `Traversable`.

## Installation

```
bower install purescript-distributive
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-distributive).
