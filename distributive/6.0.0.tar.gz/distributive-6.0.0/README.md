# purescript-distributive

[![Latest release](http://img.shields.io/github/release/purescript/purescript-distributive.svg)](https://github.com/purescript/purescript-distributive/releases)
[![Build status](https://github.com/purescript/purescript-distributive/workflows/CI/badge.svg?branch=master)](https://github.com/purescript/purescript-distributive/actions?query=workflow%3ACI+branch%3Amaster)
[![Pursuit](https://pursuit.purescript.org/packages/purescript-distributive/badge)](https://pursuit.purescript.org/packages/purescript-distributive)

Distributive typeclass - the categorical dual of `Traversable`.

## Installation

```
spago install distributive
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-distributive).
