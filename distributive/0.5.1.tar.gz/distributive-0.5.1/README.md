# purescript-distributive

[![Latest release](http://img.shields.io/bower/v/purescript-distributive.svg)](https://github.com/purescript/purescript-distributive/releases)
[![Build Status](https://travis-ci.org/purescript/purescript-distributive.svg?branch=master)](https://travis-ci.org/purescript/purescript-distributive)
[![Dependency Status](https://www.versioneye.com/user/projects/55848c97363861001d000341/badge.svg?style=flat)](https://www.versioneye.com/user/projects/55848c97363861001d000341)


Distributive typeclass - the categorical dual of `Traversable`.

## Installation

```
bower install purescript-distributive
```

## Module documentation

- [Data.Distributive](docs/Data/Distributive.md)
