purescript-lens-simple
======================

Very simple lenses.

- [Module Documentation](docs/Optic/Lens/Simple.md)
- [Example](test/Main.purs)
