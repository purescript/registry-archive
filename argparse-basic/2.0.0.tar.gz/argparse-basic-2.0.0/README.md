# purescript-argparse-basic

A no frills CLI argument parser for PureScript.
