// module Text.Markdown.SlamDown.Parser.Inline

exports.error = function(s) {
    throw new Error(s);
};
