# purescript-bigintegers
Simple bindings to JS BigInt
