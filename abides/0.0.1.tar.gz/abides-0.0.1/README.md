# abides


![](https://github.com/athanclark/abides/raw/master/images/the_dude.jpg)


Just a bunch of functions that make sure a class abides by its laws, man.
