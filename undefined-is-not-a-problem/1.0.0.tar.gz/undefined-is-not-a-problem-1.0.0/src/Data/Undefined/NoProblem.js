const undefinedImpl = undefined
export { undefinedImpl as undefined }
