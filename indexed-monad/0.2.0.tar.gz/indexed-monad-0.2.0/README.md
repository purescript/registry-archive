# purescript-indexed-monad

[![Latest release](http://img.shields.io/github/release/garyb/purescript-indexed-monad.svg)](https://github.com/garyb/purescript-indexed-monad/releases)
[![Build status](https://travis-ci.org/garyb/purescript-indexed-monad.svg?branch=master)](https://travis-ci.org/garyb/purescript-indexed-monad)

Indexed monads in PureScript.

## Installation

```
bower install purescript-indexed-monad
```
