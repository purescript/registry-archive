# purescript-aff-reattempt

[![Latest release](http://img.shields.io/bower/v/purescript-aff-reattempt.svg)](https://github.com/slamdata/purescript-aff-reattempt/releases)
[![Build Status](https://travis-ci.org/slamdata/purescript-aff-reattempt.svg?branch=master)](https://travis-ci.org/slamdata/purescript-aff-reattempt)
[![Dependency Status](https://www.versioneye.com/user/projects/56e6d48d96f80c002c8ceb4f/badge.svg?style=flat)](https://www.versioneye.com/user/projects/56e6d48d96f80c002c8ceb4f)

A PureScript library for reattempting asynchronous computations.

## Installation

``` purescript
bower install purescript-aff-reattempt
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-aff-reattempt).
