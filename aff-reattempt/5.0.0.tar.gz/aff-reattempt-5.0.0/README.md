# purescript-aff-reattempt

[![Latest release](http://img.shields.io/github/release/slamdata/purescript-aff-reattempt.svg)](https://github.com/slamdata/purescript-aff-reattempt/releases)
[![Build status](https://travis-ci.org/slamdata/purescript-aff-reattempt.svg?branch=master)](https://travis-ci.org/slamdata/purescript-aff-reattempt)

A PureScript library for reattempting asynchronous computations.

## Installation

``` purescript
bower install purescript-aff-reattempt
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-aff-reattempt).
