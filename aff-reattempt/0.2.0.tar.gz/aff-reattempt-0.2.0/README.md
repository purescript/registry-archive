# purescript-aff-reattempt

A PureScript library for reattempting asynchronous computations.

### Module documentation

* [Control.Monad.Aff.Reattempt](docs/Control/Monad/Aff/Reattempt.md)

### Installation

Please install [Bower](https://github.com/bower/bower) and run `bower install
purescript-aff-reattempt`.

### Tests

Please install [Pulp](https://github.com/bodil/pulp) and run `pulp test`.

