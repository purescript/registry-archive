# purescript-ethereum-client

[![Build Status](https://travis-ci.org/Unisay/purescript-ethereum-client.svg?branch=master)](https://travis-ci.org/Unisay/purescript-ethereum-client)

Ethereum [RPC protocol](https://github.com/ethereum/wiki/wiki/JSON-RPC) client 
