# purescript-node-readable

Custom Node Readable streams.

See the `examples` directory for usage examples.

## Installation

```
bower install purescript-node-readable
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-node-readable).
