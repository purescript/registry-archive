# purescript-sorted-array

WIP, need to:
  - add documentation
  - write tests
  - figure out how to publish on pursuit / bower