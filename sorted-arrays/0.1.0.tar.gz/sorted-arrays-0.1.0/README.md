# purescript-sorted-array

WIP, need to:
  - review tests
  - add documentation
  - figure out how to publish on pursuit / bower