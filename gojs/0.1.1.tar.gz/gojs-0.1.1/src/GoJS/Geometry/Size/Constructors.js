import * as go from 'gojs';

export const newSize = (w) => (h) => {
    return new go.Size(w, h)
}