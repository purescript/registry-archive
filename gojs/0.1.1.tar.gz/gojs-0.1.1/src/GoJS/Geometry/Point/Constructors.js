import * as go from 'gojs';

export const newPoint = (x) => (y) => {
    return new go.Point(x, y)
}
