import * as go from 'gojs';

export const packNone_ = go.LayeredDigraphLayout.PackNone
export const packExpand_ = go.LayeredDigraphLayout.PackExpand
export const packStraighten_ = go.LayeredDigraphLayout.PackStraighten
export const packMedian_ = go.LayeredDigraphLayout.PackMedian
export const packAll_ = go.LayeredDigraphLayout.PackAll
export const alignNone_ = go.LayeredDigraphLayout.AlignNone
export const alignUpperLeft_ = go.LayeredDigraphLayout.AlignUpperLeft
export const alignUpperRight_ = go.LayeredDigraphLayout.AlignUpperRight
export const alignLowerLeft_ = go.LayeredDigraphLayout.AlignLowerLeft
export const alignLowerRight_ = go.LayeredDigraphLayout.AlignLowerRight
export const alignAll_ = go.LayeredDigraphLayout.AlignAll