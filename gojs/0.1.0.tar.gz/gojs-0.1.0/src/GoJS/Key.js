export const typeofk = (k) => {
    return typeof k;
}
export const undefinedk = undefined;