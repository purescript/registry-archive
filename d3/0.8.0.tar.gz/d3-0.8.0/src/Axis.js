/* global exports */
"use strict";

// module Graphics.D3.SVG.Axis

exports.axis = d3.svg.axis;
