/* global exports */
"use strict";

// module Graphics.D3.Layout.Force

exports.forceLayout = d3.layout.force;
