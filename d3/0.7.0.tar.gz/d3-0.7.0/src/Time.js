/* global exports */
"use strict";

// module Graphics.D3.Time

exports.timeScale = d3.time.scale;
