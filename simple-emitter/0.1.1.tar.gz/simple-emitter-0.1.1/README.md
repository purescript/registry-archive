# purescript-simple-emitter

[![Latest release](http://img.shields.io/github/release/oreshinya/purescript-simple-emitter.svg)](https://github.com/oreshinya/purescript-simple-emitter/releases)

PureScript simple event emitter.

## Installation

```
bower install purescript-simple-emitter
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-simple-emitter).

## LICENSE

MIT
