Browser Sniffer
===

[![Build Status](https://travis-ci.org/CapillarySoftware/purescript-browser-sniffer.svg)](https://travis-ci.org/CapillarySoftware/purescript-browser-sniffer)

User agent string stiffing. Intended as practicle and minimal.
Simple mobile detection for the moment.

```
    isMobile  :: Boolean
    isDesktop :: Boolean
```

