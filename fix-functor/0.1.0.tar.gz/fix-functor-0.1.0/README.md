# purescript-fix-functor

Provides a higher-order functor `HFunctor`, and `Fix`, made for writing and
interpreting recursive data structures.
