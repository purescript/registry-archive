# PureScript-StrongCheck

## Installation

```shell
bower install purescript-strongcheck
```

## Documentation

- [Test.StrongCheck](docs/Test/StrongCheck.md)
- [Test.StrongCheck.Gen](docs/Test/StrongCheck/Gen.md)
- [Test.StrongCheck.Landscape](docs/Test/StrongCheck/Landscape.md)
- [Test.StrongCheck.Perturb](docs/Test/StrongCheck/Perturb.md)
