# DEPRECATED

StrongCheck has been deprecated because [QuickCheck](https://github.com/purescript/purescript-quickcheck) is now stack safe, which was the major reason to use StrongCheck. Since that's no longer an advantage and StrongCheck is significantly slower than QuickCheck, there's not much reason to keep this library around vs. putting all efforts into QuickCheck as the standard.

You can see the full [discussion on Discourse](https://discourse.purescript.org/t/proposed-purescript-contrib-library-deprecations) for more details. Previous releases continue to work.
