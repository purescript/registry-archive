# purescript-symbols

Utilities for working with type-level strings.

This library requires version 0.10 of the PureScript compiler, or later.
