# purescript-symbols

[![Latest release](http://img.shields.io/github/release/purescript/purescript-symbols.svg)](https://github.com/purescript/purescript-symbols/releases)
[![Build status](https://travis-ci.org/purescript/purescript-symbols.svg?branch=master)](https://travis-ci.org/purescript/purescript-symbols)

Utilities for working with type-level strings.

This library requires version 0.10 of the PureScript compiler or later.

## Installation

```
bower install purescript-symbols
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-symbols).
