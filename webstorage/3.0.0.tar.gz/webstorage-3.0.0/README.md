# purescript-webstorage
[![Build Status](https://travis-ci.org/joneshf/purescript-webstorage.svg?branch=master)](https://travis-ci.org/joneshf/purescript-webstorage)

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-webstorage).
