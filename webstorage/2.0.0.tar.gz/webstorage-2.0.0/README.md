# purescript-webstorage

# Docs

## [Browser.WebStorage](docs/Browser/WebStorage.md)
