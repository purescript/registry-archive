# purescript-console-timer

A type-safe interface to JavaScript's `console.timer`.

## Installation

```
bower install purescript-console-timer
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-console-timer).
