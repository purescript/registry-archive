# purescript-math-equation

This library simply defines data types to represent equations, generally speaking,
numerically. It's specifically meant to be used to communicate an equation over-the-wire,
not particually to support or implement computer algebra systems per-se, but potentially in
the future.
