/* global exports */
"use strict";

exports.writeNull = null;
