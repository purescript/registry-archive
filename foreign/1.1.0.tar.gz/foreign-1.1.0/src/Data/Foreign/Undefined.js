/* global exports */
"use strict";

exports.writeUndefined = undefined;
