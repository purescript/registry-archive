// module MaterialUI.SelectField

exports.selectFieldClass = require('material-ui/SelectField/SelectField').default;
