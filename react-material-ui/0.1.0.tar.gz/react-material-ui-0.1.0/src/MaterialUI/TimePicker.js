// module MaterialUI.TimePicker

exports.timePickerClass = require('material-ui/TimePicker/TimePicker').default;
