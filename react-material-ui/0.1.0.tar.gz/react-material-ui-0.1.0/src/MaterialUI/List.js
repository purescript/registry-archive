// module MaterialUI.List

exports.listClass = require('material-ui/List/List').default;
