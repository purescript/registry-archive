// module MaterialUI.CircularProgress

exports.circularProgressClass = require('material-ui/CircularProgress/CircularProgress').default;
