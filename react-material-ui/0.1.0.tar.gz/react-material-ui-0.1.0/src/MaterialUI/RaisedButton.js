// module MaterialUI.RaisedButton

exports.raisedButtonClass = require('material-ui/RaisedButton/RaisedButton').default;
