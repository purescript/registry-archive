// module MaterialUI.TableRowColumn

exports.tableRowColumnClass = require('material-ui/Table/TableRowColumn').default;
