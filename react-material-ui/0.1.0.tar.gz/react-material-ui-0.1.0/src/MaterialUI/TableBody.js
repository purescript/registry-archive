// module MaterialUI.TableBody

exports.tableBodyClass = require('material-ui/Table/TableBody').default;
