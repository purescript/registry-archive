// module MaterialUI.MenuItem

exports.menuItemClass = require('material-ui/MenuItem/MenuItem').default;
