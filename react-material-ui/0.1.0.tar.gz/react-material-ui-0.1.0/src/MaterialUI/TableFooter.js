// module MaterialUI.TableFooter

exports.tableFooterClass = require('material-ui/Table/TableFooter').default;
