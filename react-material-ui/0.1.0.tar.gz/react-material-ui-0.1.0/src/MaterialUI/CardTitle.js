// module MaterialUI.CardTitle

exports.cardTitleClass = require('material-ui/Card/CardTitle').default;
