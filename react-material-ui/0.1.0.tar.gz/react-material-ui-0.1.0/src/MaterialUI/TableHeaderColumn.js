// module MaterialUI.TableHeaderColumn

exports.tableHeaderColumnClass = require('material-ui/Table/TableHeaderColumn').default;
