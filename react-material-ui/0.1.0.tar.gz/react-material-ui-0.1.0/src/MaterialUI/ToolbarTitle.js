// module MaterialUI.ToolbarTitle

exports.toolbarTitleClass = require('material-ui/Toolbar/ToolbarTitle').default;
