// module MaterialUI.RefreshIndicator

exports.refreshIndicatorClass = require('material-ui/RefreshIndicator/RefreshIndicator').default;
