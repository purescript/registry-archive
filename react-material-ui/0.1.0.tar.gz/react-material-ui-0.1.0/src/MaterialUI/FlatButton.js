// module MaterialUI.FlatButton

exports.flatButtonClass = require('material-ui/FlatButton/FlatButton').default;
