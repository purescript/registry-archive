// module MaterialUI.RadioButton

exports.radioButtonClass = require('material-ui/RadioButton/RadioButton').default;
