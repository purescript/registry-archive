// module MaterialUI.StepLabel

exports.stepLabelClass = require('material-ui/Stepper/StepLabel').default;
