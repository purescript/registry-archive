// module MaterialUI.Toggle

exports.toggleClass = require('material-ui/Toggle/Toggle').default;
