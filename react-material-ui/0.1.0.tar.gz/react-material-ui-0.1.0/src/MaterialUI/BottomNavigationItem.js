// module MaterialUI.BottomNavigationItem

exports.bottomNavigationItemClass = require('material-ui/BottomNavigation/BottomNavigationItem').default;
