// module MaterialUI.SvgIcon

exports.svgIconClass = require('material-ui/SvgIcon/SvgIcon').default;
