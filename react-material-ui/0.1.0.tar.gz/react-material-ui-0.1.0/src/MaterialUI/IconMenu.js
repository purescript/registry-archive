// module MaterialUI.IconMenu

exports.iconMenuClass = require('material-ui/IconMenu/IconMenu').default;
