// module MaterialUI.Stepper

exports.stepperClass = require('material-ui/Stepper/Stepper').default;
