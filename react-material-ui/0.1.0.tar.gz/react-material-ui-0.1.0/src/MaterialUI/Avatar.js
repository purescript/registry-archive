// module MaterialUI.Avatar

exports.avatarClass = require('material-ui/Avatar/Avatar').default;
