// module MaterialUI.Slider

exports.sliderClass = require('material-ui/Slider/Slider').default;
