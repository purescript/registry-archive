// module MaterialUI.Step

exports.stepClass = require('material-ui/Stepper/Step').default;
