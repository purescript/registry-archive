// module MaterialUI.IconButton

exports.iconButtonClass = require('material-ui/IconButton/IconButton').default;
