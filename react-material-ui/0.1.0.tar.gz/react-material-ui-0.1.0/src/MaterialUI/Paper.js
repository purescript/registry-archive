// module MaterialUI.Paper

exports.paperClass = require('material-ui/Paper/Paper').default;
