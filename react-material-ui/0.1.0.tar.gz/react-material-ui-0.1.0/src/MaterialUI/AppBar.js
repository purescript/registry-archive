// module MaterialUI.AppBar

exports.appBarClass = require('material-ui/AppBar/AppBar').default;
