// module MaterialUI.DatePicker

exports.datePickerClass = require('material-ui/DatePicker/DatePicker').default;
