// module MaterialUI.AutoComplete

exports.autoCompleteClass = require('material-ui/AutoComplete/AutoComplete').default;
