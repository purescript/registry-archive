// module MaterialUI.ToolbarGroup

exports.toolbarGroupClass = require('material-ui/Toolbar/ToolbarGroup').default;
