// module MaterialUI.DropDownMenu

exports.dropDownMenuClass = require('material-ui/DropDownMenu/DropDownMenu').default;
