// module MaterialUI.Subheader

exports.subheaderClass = require('material-ui/Subheader/Subheader').default;
