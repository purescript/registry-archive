// module MaterialUI.CardHeader

exports.cardHeaderClass = require('material-ui/Card/CardHeader').default;
