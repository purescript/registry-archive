// module MaterialUI.ListItem

exports.listItemClass = require('material-ui/List/ListItem').default;
