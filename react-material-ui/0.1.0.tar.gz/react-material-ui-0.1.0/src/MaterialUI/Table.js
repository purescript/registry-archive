// module MaterialUI.Table

exports.tableClass = require('material-ui/Table/Table').default;
