// module MaterialUI.Checkbox

exports.checkboxClass = require('material-ui/Checkbox/Checkbox').default;
