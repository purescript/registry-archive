// module MaterialUI.StepContent

exports.stepContentClass = require('material-ui/Stepper/StepContent').default;
