// module MaterialUI.MuiThemeProvider

exports.muiThemeProviderClass = require('material-ui/styles/MuiThemeProvider').default;
