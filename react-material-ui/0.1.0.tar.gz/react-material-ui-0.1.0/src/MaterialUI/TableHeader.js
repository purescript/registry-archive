// module MaterialUI.TableHeader

exports.tableHeaderClass = require('material-ui/Table/TableHeader').default;
