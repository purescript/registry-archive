// module MaterialUI.FontIcon

exports.fontIconClass = require('material-ui/FontIcon/FontIcon').default;
