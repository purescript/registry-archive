// module MaterialUI.LinearProgress

exports.linearProgressClass = require('material-ui/LinearProgress/LinearProgress').default;
