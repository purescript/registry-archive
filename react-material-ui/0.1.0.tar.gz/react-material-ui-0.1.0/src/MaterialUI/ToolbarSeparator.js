// module MaterialUI.ToolbarSeparator

exports.toolbarSeparatorClass = require('material-ui/Toolbar/ToolbarSeparator').default;
