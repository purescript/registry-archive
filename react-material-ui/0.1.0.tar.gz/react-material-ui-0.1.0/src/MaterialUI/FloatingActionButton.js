// module MaterialUI.FloatingActionButton

exports.floatingActionButtonClass = require('material-ui/FloatingActionButton/FloatingActionButton').default;
