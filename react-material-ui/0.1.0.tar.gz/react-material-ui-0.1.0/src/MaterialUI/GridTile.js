// module MaterialUI.GridTile

exports.gridTileClass = require('material-ui/GridList/GridTile').default;
