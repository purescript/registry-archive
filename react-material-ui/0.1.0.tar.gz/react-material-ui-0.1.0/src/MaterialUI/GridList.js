// module MaterialUI.GridList

exports.gridListClass = require('material-ui/GridList/GridList').default;
