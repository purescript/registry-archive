// module MaterialUI.CardText

exports.cardTextClass = require('material-ui/Card/CardText').default;
