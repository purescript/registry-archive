// module MaterialUI.Popover

exports.popoverClass = require('material-ui/Popover/Popover').default;
