// module MaterialUI.Divider

exports.dividerClass = require('material-ui/Divider/Divider').default;
