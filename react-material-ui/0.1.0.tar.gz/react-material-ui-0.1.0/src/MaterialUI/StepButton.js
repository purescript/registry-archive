// module MaterialUI.StepButton

exports.stepButtonClass = require('material-ui/Stepper/StepButton').default;
