// module MaterialUI.RadioButtonGroup

exports.radioButtonGroupClass = require('material-ui/RadioButton/RadioButtonGroup').default;
