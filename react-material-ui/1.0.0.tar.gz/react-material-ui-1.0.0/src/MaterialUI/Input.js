// module MaterialUI.Input

exports.inputClass = require('material-ui/Input/Input').default;
