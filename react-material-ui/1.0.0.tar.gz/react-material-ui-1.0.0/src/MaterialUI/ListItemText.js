// module MaterialUI.ListItemText

exports.listItemTextClass = require('material-ui/List/ListItemText').default;
