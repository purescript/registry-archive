// module MaterialUI.DialogActions

exports.dialogActionsClass = require('material-ui/Dialog/DialogActions').default;
