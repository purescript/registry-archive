// module MaterialUI.CardActions

exports.cardActionsClass = require('material-ui/Card/CardActions').default;
