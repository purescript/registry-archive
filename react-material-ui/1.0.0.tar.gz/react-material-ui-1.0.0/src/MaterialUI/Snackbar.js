// module MaterialUI.Snackbar

exports.snackbarClass = require('material-ui/Snackbar/Snackbar').default;
