// module MaterialUI.CardContent

exports.cardContentClass = require('material-ui/Card/CardContent').default;
