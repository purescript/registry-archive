// module MaterialUI.FormLabel

exports.formLabelClass = require('material-ui/Form/FormLabel').default;
