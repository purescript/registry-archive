// module MaterialUI.Card

exports.cardClass = require('material-ui/Card/Card').default;
