// module MaterialUI.CircularProgress

exports.circularProgressClass = require('material-ui/Progress/CircularProgress').default;
