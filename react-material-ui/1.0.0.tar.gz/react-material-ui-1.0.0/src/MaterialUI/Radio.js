// module MaterialUI.Radio

exports.radioClass = require('material-ui/Radio/Radio').default;
