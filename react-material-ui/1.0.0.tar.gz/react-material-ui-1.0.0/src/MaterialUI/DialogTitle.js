// module MaterialUI.DialogTitle

exports.dialogTitleClass = require('material-ui/Dialog/DialogTitle').default;
