// module MaterialUI.Dialog

exports.dialogClass = require('material-ui/Dialog/Dialog').default;
