// module MaterialUI.Toolbar

exports.toolbarClass = require('material-ui/Toolbar/Toolbar').default;
