// module MaterialUI.FormControl

exports.formControlClass = require('material-ui/Form/FormControl').default;
