// module MaterialUI.DialogContent

exports.dialogContentClass = require('material-ui/Dialog/DialogContent').default;
