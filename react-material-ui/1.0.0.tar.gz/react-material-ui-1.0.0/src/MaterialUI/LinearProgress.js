// module MaterialUI.LinearProgress

exports.linearProgressClass = require('material-ui/Progress/LinearProgress').default;
