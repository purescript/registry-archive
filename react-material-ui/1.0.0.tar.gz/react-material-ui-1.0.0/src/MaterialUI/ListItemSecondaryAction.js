// module MaterialUI.ListItemSecondaryAction

exports.listItemSecondaryActionClass = require('material-ui/List/ListItemSecondaryAction').default;
