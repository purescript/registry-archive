// module MaterialUI.Badge

exports.badgeClass = require('material-ui/Badge/Badge').default;
