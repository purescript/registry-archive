// module MaterialUI.InputLabel

exports.inputLabelClass = require('material-ui/Input/InputLabel').default;
