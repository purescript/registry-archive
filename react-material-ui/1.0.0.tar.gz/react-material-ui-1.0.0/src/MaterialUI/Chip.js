// module MaterialUI.Chip

exports.chipClass = require('material-ui/Chip/Chip').default;
