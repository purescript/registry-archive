// module MaterialUI.BottomNavigation

exports.bottomNavigationClass = require('material-ui/BottomNavigation/BottomNavigation').default;
