// module MaterialUI.ListItemAvatar

exports.listItemAvatarClass = require('material-ui/List/ListItemAvatar').default;
