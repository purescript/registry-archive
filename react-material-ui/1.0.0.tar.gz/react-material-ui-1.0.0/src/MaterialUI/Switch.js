// module MaterialUI.Switch

exports.switchClass = require('material-ui/Switch/Switch').default;
