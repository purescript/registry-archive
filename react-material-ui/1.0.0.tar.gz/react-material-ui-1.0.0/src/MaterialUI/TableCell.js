// module MaterialUI.TableCell

exports.tableCellClass = require('material-ui/Table/TableCell').default;
