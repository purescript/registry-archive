// module MaterialUI.Drawer

exports.drawerClass = require('material-ui/Drawer/Drawer').default;
