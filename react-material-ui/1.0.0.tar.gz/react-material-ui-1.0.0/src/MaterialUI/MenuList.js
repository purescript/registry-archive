// module MaterialUI.MenuList

exports.menuListClass = require('material-ui/Menu/MenuList').default;
