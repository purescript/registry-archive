// module MaterialUI.BottomNavigationButton

exports.bottomNavigationButtonClass = require('material-ui/BottomNavigation/BottomNavigationButton').default;
