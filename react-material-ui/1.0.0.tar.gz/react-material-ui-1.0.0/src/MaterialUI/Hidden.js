// module MaterialUI.Hidden

exports.hiddenClass = require('material-ui/Hidden/Hidden').default;
