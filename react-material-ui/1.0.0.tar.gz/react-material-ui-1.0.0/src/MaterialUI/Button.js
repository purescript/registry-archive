// module MaterialUI.Button

exports.buttonClass = require('material-ui/Button/Button').default;
