// module MaterialUI.FormControlLabel

exports.formControlLabelClass = require('material-ui/Form/FormControlLabel').default;
