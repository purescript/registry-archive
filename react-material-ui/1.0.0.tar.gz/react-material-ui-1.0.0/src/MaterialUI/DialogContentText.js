// module MaterialUI.DialogContentText

exports.dialogContentTextClass = require('material-ui/Dialog/DialogContentText').default;
