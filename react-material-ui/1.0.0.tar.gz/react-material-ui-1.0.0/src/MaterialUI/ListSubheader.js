// module MaterialUI.ListSubheader

exports.listSubheaderClass = require('material-ui/List/ListSubheader').default;
