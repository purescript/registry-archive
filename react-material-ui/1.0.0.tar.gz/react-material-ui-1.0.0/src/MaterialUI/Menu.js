// module MaterialUI.Menu

exports.menuClass = require('material-ui/Menu/Menu').default;
