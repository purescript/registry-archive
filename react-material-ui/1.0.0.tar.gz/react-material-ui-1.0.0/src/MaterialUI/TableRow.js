// module MaterialUI.TableRow

exports.tableRowClass = require('material-ui/Table/TableRow').default;
