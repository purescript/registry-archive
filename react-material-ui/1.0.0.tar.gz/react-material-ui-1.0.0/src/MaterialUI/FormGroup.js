// module MaterialUI.FormGroup

exports.formGroupClass = require('material-ui/Form/FormGroup').default;
