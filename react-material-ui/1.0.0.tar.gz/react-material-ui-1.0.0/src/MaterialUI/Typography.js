// module MaterialUI.Typography

exports.typographyClass = require('material-ui/Typography/Typography').default;
