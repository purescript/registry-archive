// module MaterialUI.FormHelperText

exports.formHelperTextClass = require('material-ui/Form/FormHelperText').default;
