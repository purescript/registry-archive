// module MaterialUI.MenuItem

exports.menuItemClass = require('material-ui/Menu/MenuItem').default;
