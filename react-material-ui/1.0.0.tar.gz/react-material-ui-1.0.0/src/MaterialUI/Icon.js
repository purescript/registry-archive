// module MaterialUI.Icon

exports.iconClass = require('material-ui/Icon/Icon').default;
