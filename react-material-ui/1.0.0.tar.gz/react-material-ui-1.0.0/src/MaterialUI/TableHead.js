// module MaterialUI.TableHead

exports.tableHeadClass = require('material-ui/Table/TableHead').default;
