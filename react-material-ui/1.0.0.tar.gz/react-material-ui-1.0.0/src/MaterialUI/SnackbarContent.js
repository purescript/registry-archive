// module MaterialUI.SnackbarContent

exports.snackbarContentClass = require('material-ui/Snackbar/SnackbarContent').default;
