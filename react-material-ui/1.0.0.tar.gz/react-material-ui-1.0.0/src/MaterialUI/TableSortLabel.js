// module MaterialUI.TableSortLabel

exports.tableSortLabelClass = require('material-ui/Table/TableSortLabel').default;
