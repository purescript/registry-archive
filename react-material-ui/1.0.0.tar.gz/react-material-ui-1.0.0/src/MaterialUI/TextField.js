// module MaterialUI.TextField

exports.textFieldClass = require('material-ui/TextField/TextField').default;
