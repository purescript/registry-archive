// module MaterialUI.CardMedia

exports.cardMediaClass = require('material-ui/Card/CardMedia').default;
