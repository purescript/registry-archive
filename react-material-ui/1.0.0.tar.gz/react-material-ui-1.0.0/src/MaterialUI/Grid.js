// module MaterialUI.Grid

exports.gridClass = require('material-ui/Grid/Grid').default;
