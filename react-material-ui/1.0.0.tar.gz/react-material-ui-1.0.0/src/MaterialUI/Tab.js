// module MaterialUI.Tab

exports.tabClass = require('material-ui/Tabs/Tab').default;
