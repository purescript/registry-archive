// module MaterialUI.ListItemIcon

exports.listItemIconClass = require('material-ui/List/ListItemIcon').default;
