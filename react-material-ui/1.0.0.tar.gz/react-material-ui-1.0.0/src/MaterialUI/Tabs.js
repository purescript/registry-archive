// module MaterialUI.Tabs

exports.tabsClass = require('material-ui/Tabs/Tabs').default;
