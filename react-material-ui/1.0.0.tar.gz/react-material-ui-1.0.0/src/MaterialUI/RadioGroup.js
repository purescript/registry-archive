// module MaterialUI.RadioGroup

exports.radioGroupClass = require('material-ui/Radio/RadioGroup').default;
