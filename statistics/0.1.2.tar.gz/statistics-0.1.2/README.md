# purescript-statistics

Some statistics functions for PureScript.


## Installation

```
	bower install purescript-statistics
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-statistics).

