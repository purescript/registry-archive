# purescript-statistics

Some statistics functions for PureScript.


## Installation

```
	spago install statistics
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-statistics).

