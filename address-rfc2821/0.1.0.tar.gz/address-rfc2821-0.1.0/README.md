# purescript-address-rfc2821

A lightweight interface to validating email addresses with
https://www.npmjs.com/package/address-rfc2821.

To build:
```sh
nix develop
bun install
bun spago build
bun spago test
```
