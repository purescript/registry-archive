/* global exports */
"use strict";

// module React.DOM

exports.text = function(text) {
    return text;
};
