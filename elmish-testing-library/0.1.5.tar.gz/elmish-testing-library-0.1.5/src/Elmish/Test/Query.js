export const innerText_ = e => e.innerText || ""
export const outerHTML_ = e => e.outerHTML || ""
export const prop_ = (name, e) => e[name]
