# purescript-these

[![Latest release](http://img.shields.io/github/release/purescript-contrib/purescript-these.svg)](https://github.com/purescript-contrib/purescript-these/releases)
[![Build Status](https://travis-ci.org/purescript-contrib/purescript-these.svg?branch=master)](https://travis-ci.org/purescript-contrib/purescript-these)
[![Maintainer: garyb](https://img.shields.io/badge/maintainer-garyb-lightgrey.svg)](http://github.com/garyb)

Data type isomorphic to `α ∨ β ∨ (α ∧ β)`

## Installation

```
bower install purescript-these
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-these).
