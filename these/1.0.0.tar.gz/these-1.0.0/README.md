# purescript-these

[![Latest release](http://img.shields.io/bower/v/purescript-these.svg)](https://github.com/purescript/purescript-these/releases)
[![Build Status](https://travis-ci.org/purescript-contrib/purescript-these.svg?branch=master)](https://travis-ci.org/purescript-contrib/purescript-these)
[![Dependency Status](https://www.versioneye.com/user/projects/57553f1e7757a0004a1ddf1d/badge.svg?style=flat)](https://www.versioneye.com/user/projects/57553f1e7757a0004a1ddf1d)
[![Maintainer: garyb](https://img.shields.io/badge/maintainer-garyb-lightgrey.svg)](http://github.com/garyb)

Data type isomorphic to `α ∨ β ∨ (α ∧ β)`

## Installation

```
bower install purescript-these
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-these).
