# purescript-these

[![Build Status](https://travis-ci.org/purescript/purescript-these.svg?branch=master)](https://travis-ci.org/purescript/purescript-these)

Data type ismorphic to `α ∨ β ∨ (α ∧ β)`

## Installation

```
bower install purescript-these
```

## Module documentation

- [Data.These](docs/Data.These.md)
