# purescript-boolean-eq

[![Latest release](http://img.shields.io/github/release/Risto-Stevcev/purescript-boolean-eq.svg)](https://github.com/Risto-Stevcev/purescript-boolean-eq/releases)

A typeclass that expresses a congruence with boolean equality


## Installation

```
bower install purescript-boolean-eq
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-boolean-eq).
