[![Build Status](https://travis-ci.org/jutaro/purescript-matrix.svg?branch=master)](https://travis-ci.org/jutaro/purescript-matrix)

Matrices for purescript. (Started for the purescript-webgl binding).

This module should be imported qualified, like:
~~~
import Data.Matrix as M
import Data.Matrix4 as M
~~~
