# purescript-yarn

Miscellaneous functions relating to `String`s and `Char`acters.

## installing

`bower i purescript-yarn`
