### Selective applicative functors

This is a PureScript fork of [selective applicative functors](https://github.com/snowleopard/selective) by Andrey Mokhov.
`Selective` is a typeclass somewhere between `Applicative` and `Monad`.

Read more about `Selective` [here](https://blogs.ncl.ac.uk/andreymokhov/selective/).