# purescript-zippable

A type class generalizing the functions `zip`, `zipWith`, etc. which are defined for [a lot of
different types](https://pursuit.purescript.org/search?q=zip). 

## Installation

```
bower install purescript-zippable
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-zippable).