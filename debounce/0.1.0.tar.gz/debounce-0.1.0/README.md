# purescript-debouncing

PureScript bindings for [debouncing](https://www.npmjs.com/package/debouncing).
