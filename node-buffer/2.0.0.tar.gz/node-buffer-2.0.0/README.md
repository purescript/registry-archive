# purescript-node-buffer

Type declarations and FFI wrappers for Node's Buffer class.

## Documentation

Module documentation is [published on Pursuit](https://pursuit.purescript.org/packages/purescript-node-buffer).
