# purescript-node-buffer

Type declarations and FFI wrappers for Node's Buffer class.

## Module documentation

* [Node.Buffer](docs/Node/Buffer.md)
* [Node.Buffer.Encoding](docs/Node/Buffer/Encoding.md)
* [Node.Buffer.Unsafe](docs/Node/Buffer/Unsafe.md)
