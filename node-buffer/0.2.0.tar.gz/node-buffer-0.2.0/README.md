# purescript-node-buffer

Type declarations and FFI wrappers for Node's Buffer class.

## Module documentation

* [Node.Encoding](docs/Node/Encoding.md)
* [Node.Buffer](docs/Node/Buffer.md)
* [Node.Buffer.Unsafe](docs/Node/Buffer/Unsafe.md)
