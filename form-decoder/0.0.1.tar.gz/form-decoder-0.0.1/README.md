# purescript-form-decoder
Scalable way to decode user inputs into neat structure for PureScript, inspired by [elm-form-decoder](https://package.elm-lang.org/packages/arowM/elm-form-decoder/latest/).
