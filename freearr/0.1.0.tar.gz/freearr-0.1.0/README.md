# purescript-freearr

Free arrows for PureScript.

See the following reference for further information.
* [Notions of Computation as Monoids](http://www.fceia.unr.edu.ar/~mauro/pubs/Notions_of_Computation_as_Monoids.pdf) (Rivas and Jaskelioff 2016)

## Installation

```
bower install purescript-freearr
```
