# purescript-higher-order

Typeclass interfaces for registering partial orders and bounds to type operators

## Installation

```
bower install purescript-higher-order
```
