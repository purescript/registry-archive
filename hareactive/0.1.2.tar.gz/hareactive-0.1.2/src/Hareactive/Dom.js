const Hd = require("@funkia/hareactive/dom");

exports._streamFromEvent = Hd.streamFromEvent;

exports.keyDown = Hd.keyDown;

exports.keyUp = Hd.keyUp;

exports.keyPressed = Hd.keyPressed;

exports._render = Hd.render;
