# purescript-elmish-time-machine

Time travel debug tool for purescript-elmish
