export const parseJSONImpl = (str) => JSON.parse(str);
