export const aNull = null;
export const anUndefined = undefined;
