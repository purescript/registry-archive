"use strict";

exports.lengthComputable = function(ev) {
  return ev.lengthComputable;
};

exports.lengthComputable = function(ev) {
  return ev.lengthComputable;
};

exports.loaded = function(ev) {
  return ev.loaded;
};

exports.total = function(ev) {
  return ev.total;
};
