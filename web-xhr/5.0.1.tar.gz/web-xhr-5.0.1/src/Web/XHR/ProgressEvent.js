export function lengthComputable(ev) {
  return ev.lengthComputable;
}

export function loaded(ev) {
  return ev.loaded;
}

export function total(ev) {
  return ev.total;
}
