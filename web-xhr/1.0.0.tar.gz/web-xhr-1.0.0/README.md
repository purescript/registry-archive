# purescript-web-xhr

Low-level bindings for `XMLHttpRequest`.
