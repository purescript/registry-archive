export const _parseJSON = JSON.parse;

export const _undefined = undefined;

export const _unsafeStringify = JSON.stringify;
