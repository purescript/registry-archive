# purescript-markdown-it

[![purescript-markdown-it on Pursuit](https://pursuit.purescript.org/packages/purescript-markdown-it/badge)](https://pursuit.purescript.org/packages/purescript-markdown-it)

A PureScript wrapper of [markdown-it](https://www.npmjs.org/package/markdown-it).
