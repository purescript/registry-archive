
// module Data.HObject.Record

exports.structName = function(type) {
  return type.constructor.name;
}
