// use https://github.com/niftylettuce/url-regex-safe
//
// to install
//
// npm install url-regex-safe
export { default as urlRegexSafe } from 'url-regex-safe'
