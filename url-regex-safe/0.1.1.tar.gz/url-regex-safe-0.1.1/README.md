# purescript-url-regex-safe

wrapper around https://www.npmjs.com/package/url-regex-safe
