// use https://github.com/niftylettuce/url-regex-safe
//
// to install
//
// npm install url-regex-safe
exports.urlRegexSafe = require('url-regex-safe');
