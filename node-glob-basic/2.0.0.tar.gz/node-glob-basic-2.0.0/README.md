# purescript-node-glob-basic

A very basic glob library. Only supports `*` and `**`. Who could ask for anything more?
