# purescript-rwse-free

A library modeling a basic monad transformer stack for reading, writing,
state modification, and error handling.

## Installation

```bash
bower install --save purescript-rwse-free
```
