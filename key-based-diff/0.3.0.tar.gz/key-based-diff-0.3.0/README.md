# purescript-key-based-diff

[![Latest release](http://img.shields.io/github/release/oreshinya/purescript-key-based-diff.svg)](https://github.com/oreshinya/purescript-key-based-diff/releases)

A list diff algorightm with key for virtual dom reconciliation.

## Installation
```
bower install purescript-key-based-diff
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-key-based-diff).

## LICENSE

MIT
