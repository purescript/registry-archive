# purescript-eff

[![Latest release](http://img.shields.io/github/release/purescript/purescript-eff.svg)](https://github.com/purescript/purescript-eff/releases)
[![Build status](https://travis-ci.org/purescript/purescript-eff.svg?branch=master)](https://travis-ci.org/purescript/purescript-eff)

The `Eff` monad, for handling native side effects.

## Installation

```
bower install purescript-eff
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-eff).
