# purescript-eff

[![Latest release](http://img.shields.io/bower/v/purescript-eff.svg)](https://github.com/purescript/purescript-eff/releases)
[![Build Status](https://travis-ci.org/purescript/purescript-eff.svg?branch=master)](https://travis-ci.org/purescript/purescript-eff)
[![Dependency Status](https://www.versioneye.com/user/projects/55848cde3638610015000408/badge.svg?style=flat)](https://www.versioneye.com/user/projects/55848cde3638610015000408)

The `Eff` monad, for handling native side effects.

## Installation

```
bower install purescript-eff
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-eff).
