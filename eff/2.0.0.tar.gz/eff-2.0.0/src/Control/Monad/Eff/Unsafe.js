"use strict";

exports.unsafeCoerceEff = function (f) {
  return f;
};
