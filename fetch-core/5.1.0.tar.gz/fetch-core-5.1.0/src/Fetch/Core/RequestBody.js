export function fromArrayBuffer(a) { return a }
export function fromArrayView(a) { return a }
export function fromString(a) { return a }
export function fromReadableStream(a) { return a }
export const empty = null;
