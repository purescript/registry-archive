# DEPRECATED

`purescript-node-streams-aff` is deprecated. Functions and values from this library were merged as-is into the [`purescript-node-streams`](https://github.com/purescript/purescript-node-streams) library.

The [original releases up to v5.0.0](https://github.com/purescript-deprecated/purescript-node-streams-aff/releases) of this library are still available and will work with compiler versions prior to PureScript v0.16.x.

