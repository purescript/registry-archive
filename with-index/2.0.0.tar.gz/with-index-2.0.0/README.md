# `purescript-with-index`

A tiny library for composing indexed traversals

- [Module Documentation](generated-docs/Data/WithIndex.md)
