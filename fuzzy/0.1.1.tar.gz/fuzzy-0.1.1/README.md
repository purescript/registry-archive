# Purescript Fuzzy [![CircleCI](https://circleci.com/gh/citizennet/purescript-fuzzy.svg?style=badge)](https://circleci.com/gh/citizennet/purescript-fuzzy)
This library provides a way of approximately matching values to an input.
