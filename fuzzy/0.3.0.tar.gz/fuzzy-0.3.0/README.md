# Purescript Fuzzy ![CircleCI](https://img.shields.io/circleci/project/github/citizennet/purescript-fuzzy.svg) [![Maintainer: whoadave](https://img.shields.io/badge/maintainer-whoadave-lightgrey.svg)](http://github.com/davezuch)
This library provides a way of approximately matching values to an input.
