# purescript-tree-sitter
Purescript wrapper around node tree sitter
