# purescript-amqp

A PureScript wrapper for [amqplib](https://github.com/squaremo/amqp.node).

Documentation can be found at `docs/Node.AMQP.md`.

An example can be found at `src/Node/AMQP/Main.purs`.
