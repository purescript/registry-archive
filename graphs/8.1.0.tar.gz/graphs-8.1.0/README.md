# purescript-graphs

[![Latest release](http://img.shields.io/github/release/purescript/purescript-graphs.svg)](https://github.com/purescript/purescript-graphs/releases)
[![Build status](https://github.com/purescript/purescript-graphs/workflows/CI/badge.svg?branch=master)](https://github.com/purescript/purescript-graphs/actions?query=workflow%3ACI+branch%3Amaster)
[![Pursuit](https://pursuit.purescript.org/packages/purescript-graphs/badge)](https://pursuit.purescript.org/packages/purescript-graphs)

A data structure and functions for graphs.

## Installation

```
spago install graphs
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-graphs).
