# purescript-graphs

[![Latest release](http://img.shields.io/bower/v/purescript-graphs.svg)](https://github.com/purescript/purescript-graphs/releases)
[![Build Status](https://travis-ci.org/purescript/purescript-graphs.svg?branch=master)](https://travis-ci.org/purescript/purescript-graphs)
[![Dependency Status](https://www.versioneye.com/user/projects/55848ca2363861001d000343/badge.svg?style=flat)](https://www.versioneye.com/user/projects/55848ca2363861001d000343)

A data structure and functions for graphs.

## Installation

```
bower install purescript-graphs
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-graphs).
