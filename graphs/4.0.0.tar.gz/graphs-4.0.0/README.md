# purescript-graphs

[![Latest release](http://img.shields.io/github/release/purescript/purescript-graphs.svg)](https://github.com/purescript/purescript-graphs/releases)
[![Build status](https://travis-ci.org/purescript/purescript-graphs.svg?branch=master)](https://travis-ci.org/purescript/purescript-graphs)

A data structure and functions for graphs.

## Installation

```
bower install purescript-graphs
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-graphs).
