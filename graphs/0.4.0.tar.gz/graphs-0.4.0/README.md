# purescript-graphs

A data structure and functions for graphs

## Installation

```
bower install purescript-graphs
```

## Module documentation

- [Data.Graph](docs/Data/Graph.md)
