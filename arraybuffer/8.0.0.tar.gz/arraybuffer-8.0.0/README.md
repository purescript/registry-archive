# purescript-arraybuffer

ArrayBuffer bindings for PureScript.


## Installation

```
	bower install purescript-arraybuffer
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-arraybuffer).


## Important Usage Notes

- Usage of the ArrayBuffer<->String conversion functions requires the import of the NPM package 'text-encoding'.
