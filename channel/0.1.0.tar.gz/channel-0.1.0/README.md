# Channel

A concurrent channel inspired by the Haskell package pipes-concurrency written by Gabriel Gonzalez: https://hackage.haskell.org/package/pipes-concurrency
