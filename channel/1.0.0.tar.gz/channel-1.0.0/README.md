# Channel

A concurrent channel inspired by the Haskell package [pipes-concurrency](https://hackage.haskell.org/package/pipes-concurrency) written by Gabriel Gonzalez.

A `Channel` is an abstraction over a var, queue or stream backend and can be used as a communication channel between async threads.
