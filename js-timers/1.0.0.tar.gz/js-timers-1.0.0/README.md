# purescript-js-timers

[![Latest release](http://img.shields.io/bower/v/purescript-js-timers.svg)](https://github.com/purescript-contrib/purescript-js-timers/releases)
[![Build Status](https://travis-ci.org/purescript-contrib/purescript-js-timers.svg?branch=master)](https://travis-ci.org/purescript-contrib/purescript-js-timers)
[![Dependency Status](https://www.versioneye.com/user/projects/5796030108356c003c23db10/badge.svg?style=flat)](https://www.versioneye.com/user/projects/5796030108356c003c23db10)
[![Maintainer: garyb](https://img.shields.io/badge/maintainer-garyb-lightgrey.svg)](http://github.com/garyb)

Low level bindings for JavaScript's timers API.

## Installation

```
bower install purescript-js-timers
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-js-timers).
