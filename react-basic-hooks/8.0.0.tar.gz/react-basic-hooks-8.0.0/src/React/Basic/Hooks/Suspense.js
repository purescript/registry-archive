import React from "react";

export const suspense_ = React.Suspense;
