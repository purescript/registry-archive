"use strict";

const React = require("react");

exports.strictMode_ = React.StrictMode;
