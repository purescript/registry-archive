"use strict";

const React = require("react");

exports.suspense_ = React.Suspense;
