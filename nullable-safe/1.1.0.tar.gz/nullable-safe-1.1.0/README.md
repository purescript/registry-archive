# purescript-nullable-safe

`Maybe` without the constructor overhead, but no parametricity violations.
