purescript-geometry
===================

Some basic geometric types and instances
