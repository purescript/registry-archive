## Module Data.Base64

Provides utility functions for converting between ArrayBuffers, Strings, and a Base64 wrapper type that exists to prevent error.

Documentation published on [pursuit](https://pursuit.purescript.org/packages/purescript-base64-codec)