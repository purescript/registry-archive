# purescript-fork

[![Latest release](http://img.shields.io/github/release/slamdata/purescript-fork.svg)](https://github.com/slamdata/purescript-fork/releases)
[![Build status](https://travis-ci.org/slamdata/purescript-fork.svg?branch=master)](https://travis-ci.org/slamdata/purescript-fork)

Forkable monads.

## Installation

```
bower install purescript-fork
```

## Documentation

- Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-fork).
