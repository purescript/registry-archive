# purescript-geojson

### A Purescript implemenation of the GeoJson format
