# purescript-geojson

### A Purescript implemenation of the [GeoJson format](https://www.rfc-editor.org/rfc/rfc7946)
