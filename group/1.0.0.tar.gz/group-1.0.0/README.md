Group algebraic structure.

## Installation

```
bower install purescript-group
```
