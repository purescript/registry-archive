Group algebraic structure.

## Installation

```
bower install purescript-group
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-group).