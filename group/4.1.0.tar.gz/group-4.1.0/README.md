# purescript-group

[![Latest release](http://img.shields.io/github/release/morganthomas/purescript-group.svg)](https://github.com/morganthomas/purescript-group/releases) [![Build status](https://travis-ci.org/morganthomas/purescript-group.svg?branch=master)](https://travis-ci.org/morganthomas/purescript-group)

Group algebraic structure.

## Installation

```
$ bower install purescript-group

     -- OR --

$ psc-package install

```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-group).
