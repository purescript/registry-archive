# purescript-debug

[![Latest release](http://img.shields.io/bower/v/purescript-debug.svg)](https://github.com/garyb/purescript-debug/releases)
[![Build Status](https://travis-ci.org/garyb/purescript-debug.svg?branch=master)](https://travis-ci.org/garyb/purescript-debug)
[![Dependency Status](https://www.versioneye.com/user/projects/55b50478643533001c000639/badge.svg?style=flat)](https://www.versioneye.com/user/projects/55b50478643533001c000639)

Console based debugging functions.

## Installation

```
bower install purescript-debug
```

## Module documentation

- [Debug.Trace](docs/Debug/Trace.md)
