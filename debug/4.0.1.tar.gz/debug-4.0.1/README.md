# purescript-debug

[![Latest release](http://img.shields.io/github/release/garyb/purescript-debug.svg)](https://github.com/garyb/purescript-debug/releases)
[![Build Status](https://travis-ci.org/garyb/purescript-debug.svg?branch=master)](https://travis-ci.org/garyb/purescript-debug)

Console based debugging functions.

## Installation

```
bower install purescript-debug
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-debug).
