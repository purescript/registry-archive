# purescript-debug

[![Latest release](http://img.shields.io/github/release/garyb/purescript-debug.svg)](https://github.com/garyb/purescript-debug/releases)
![Build Status](https://github.com/garyb/purescript-debug/actions/workflows/ci.yml/badge.svg)

Console based debugging functions.

## Installation

```
bower install purescript-debug
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-debug).
