# purescript-records

Utility functions for purescript `Record` type.
