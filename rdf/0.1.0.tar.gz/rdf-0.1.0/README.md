# RDF for Purescript

A PureScript implementation of the [RDF/JS](https://rdf.js.org/data-model-spec/) data model.

## Acknowledgments

This work has been partially funded by the German Federal Ministry of Education and Research through the MOSAIK project (grant no. 01IS18070A) and the MANDAT project (grant no. 16DTM107A).
