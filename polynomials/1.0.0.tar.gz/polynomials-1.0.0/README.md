# purescript-polynomials

This library is chiefly a tool for pushing the limits of the numerical
hierarchy defined in the Prelude. I don't expect anyone to find it useful for
anything - but if you do, please let me know!
