# purescript-monadic-streams

## Purpose
Monadic streams offers an interface for processing streams in a monadic context.

## Documentaion
[Published on Pursuit](https://pursuit.purescript.org/packages/purescript-monadic-streams/0.0.1)
