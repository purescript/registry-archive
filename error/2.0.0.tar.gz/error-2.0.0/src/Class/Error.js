export const defaultName = function (error) {
    return error.name
}

export const defaultMessage = function (error) {
    return error.message
}
