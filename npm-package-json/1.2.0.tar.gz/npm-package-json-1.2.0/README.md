# purescript-npm-package-json

[![Pursuit](https://pursuit.purescript.org/packages/purescript-npm-package-json/badge)](https://pursuit.purescript.org/packages/purescript-npm-package-json)
