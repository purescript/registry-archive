# purescript-prng

Pseudo-random number generators. Currently only Xorshift is available.

## Installation
```
bower install purescript-prng
```

## Documentation
Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-prng).
