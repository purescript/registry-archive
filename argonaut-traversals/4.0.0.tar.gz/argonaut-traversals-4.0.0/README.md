# purescript-argonaut-traversals

[![Latest release](http://img.shields.io/github/release/purescript-contrib/purescript-argonaut-traversals.svg)](https://github.com/purescript-contrib/purescript-argonaut-traversals/releases)
[![Build Status](https://travis-ci.org/purescript-contrib/purescript-argonaut-traversals.svg?branch=master)](https://travis-ci.org/purescript-contrib/purescript-argonaut-traversals)
[![Maintainer: slamdata](https://img.shields.io/badge/maintainer-slamdata-lightgrey.svg)](http://github.com/slamdata)

Prisms, traversals, and zipper for the Argonaut `Json` type.

## Installation

```
bower install purescript-argonaut-traversals
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-argonaut-traversals).
