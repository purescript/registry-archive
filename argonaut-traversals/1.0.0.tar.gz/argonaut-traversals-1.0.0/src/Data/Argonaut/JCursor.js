"use strict";

exports.exactNull = null;
