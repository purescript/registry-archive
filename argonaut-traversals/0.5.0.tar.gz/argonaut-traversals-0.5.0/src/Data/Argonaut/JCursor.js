// module Data.Argonaut.JCursor

exports.exactNull = null;
