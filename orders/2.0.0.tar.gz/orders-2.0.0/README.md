# purescript-orders

[![Latest release](http://img.shields.io/bower/v/purescript-orders.svg)](https://github.com/purescript/purescript-orders/releases)
[![Build Status](https://travis-ci.org/purescript/purescript-orders.svg?branch=master)](https://travis-ci.org/purescript/purescript-orders)
[![Dependency Status](https://www.versioneye.com/user/projects/56ae473f7e03c700377e01a2/badge.svg?style=flat)](https://www.versioneye.com/user/projects/56ae473f7e03c700377e01a2)

Utility `newtype`s for the `Ord` type class.

## Installation

```
bower install purescript-orders
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-orders).
