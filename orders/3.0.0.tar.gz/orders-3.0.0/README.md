# purescript-orders

[![Latest release](http://img.shields.io/github/release/purescript/purescript-orders.svg)](https://github.com/purescript/purescript-orders/releases)
[![Build status](https://travis-ci.org/purescript/purescript-orders.svg?branch=master)](https://travis-ci.org/purescript/purescript-orders)
[![Dependency status](https://img.shields.io/librariesio/github/purescript/purescript-orders.svg)](https://libraries.io/github/purescript/purescript-orders)

Utility `newtype`s for the `Ord` type class.

## Installation

```
bower install purescript-orders
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-orders).
