# purescript-orders

[![Latest release](http://img.shields.io/github/release/purescript/purescript-orders.svg)](https://github.com/purescript/purescript-orders/releases)
[![Build status](https://github.com/purescript/purescript-orders/workflows/CI/badge.svg?branch=master)](https://github.com/purescript/purescript-orders/actions?query=workflow%3ACI+branch%3Amaster)
[![Pursuit](https://pursuit.purescript.org/packages/purescript-orders/badge)](https://pursuit.purescript.org/packages/purescript-orders)

Utility `newtype`s for the `Ord` type class.

## Installation

```
spago install orders
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-orders).
