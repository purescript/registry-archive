# purescript-orders

[![Latest release](http://img.shields.io/bower/v/purescript-orders.svg)](https://github.com/purescript/purescript-orders/releases)
[![Build Status](https://travis-ci.org/purescript/purescript-orders.svg?branch=master)](https://travis-ci.org/purescript/purescript-orders)

A handful of utility functions and types surrounding the `Ord` type class.

## Documentation

* [Data.Ord](docs/Data/Ord.md)
