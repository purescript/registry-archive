# purescript-postgresql-client

purescript-postgresql-client is a PostgreSQL client library for PureScript.

To use this library, you need to add `pg` as an npm dependency.
