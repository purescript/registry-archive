# purescript-filterable

Classes for filterable and witherable data structures.

Inspired by https://hackage.haskell.org/package/witherable

## Installation

`bower install purescript-filterable`

## Documentation

Not yet on Pursuit.

Build docs with `npm run build:docs`.

