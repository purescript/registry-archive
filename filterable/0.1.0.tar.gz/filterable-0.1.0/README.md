# purescript-filterable

Classes for filterable and witherable data structures.

Inspired by https://hackage.haskell.org/package/witherable

## Installation

Not yet released.

## Documentation

Not yet on Pursuit.
