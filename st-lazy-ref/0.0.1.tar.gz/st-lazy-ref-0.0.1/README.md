# purescript-st-lazy-ref

[![Latest release](https://img.shields.io/github/release/matthewleon/purescript-st-lazy-ref.svg)](https://github.com/matthewleon/purescript-st-lazy-ref/releases)
[![Build status](https://travis-ci.org/matthewleon/purescript-st-lazy-ref.svg?branch=master)](https://travis-ci.org/matthewleon/purescript-st-lazy-ref)

Platform independent, Lazy references in the ST monad.

## Installation

bower install purescript-st-lazy-ref
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-st-lazy-ref/).
