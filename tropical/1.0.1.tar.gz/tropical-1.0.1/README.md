# purescript-tropical

The tropical semiring.

- [Module Documentation](src/Data/Semiring/Tropical.md)
