# purescript-jquery

[![Latest release](http://img.shields.io/bower/v/purescript-jquery.svg)](https://github.com/purescript-contrib/purescript-jquery/releases)
[![Maintainer: paf31](https://img.shields.io/badge/maintainer-paf31-lightgrey.svg)](http://github.com/paf31)

PureScript type declarations for jQuery.

- [Module Documentation](generated-docs/Control/Monad/Eff/JQuery.md)
- [Example](test/Main.purs)

## Installation

    bower i purescript-jquery
