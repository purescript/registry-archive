# purescript-jquery

PureScript type declarations for jQuery.

- [Module Documentation](docs/Control/Monad/Eff/JQuery.md)
- [Example](test/Main.purs)

## Installation

    bower i purescript-jquery
