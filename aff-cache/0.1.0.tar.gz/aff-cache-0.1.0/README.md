# AffCache

An in-memory cache for Aff.
