/* global exports, window */
"use strict";

// module Data.DOM.Simple.Window

exports.globalWindow = window;
