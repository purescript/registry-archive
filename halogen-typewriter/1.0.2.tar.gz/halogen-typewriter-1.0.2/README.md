# halogen-typewriter

[![build](https://github.com/qwbarch/halogen-typewriter/actions/workflows/build.yml/badge.svg)](https://github.com/qwbarch/halogen-typewriter/actions/workflows/build.yml)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](https://opensource.org/licenses/MIT)
[![Pursuit](http://img.shields.io/github/release/qwbarch/halogen-typewriter.svg)](https://pursuit.purescript.org/packages/purescript-halogen-typewriter)

A simple typewriter effect for halogen. Visit the [microsite](https://qwbarch.github.io/halogen-typewriter/) for more information.

## Quickstart

```
spago install halogen-typewriter
```
