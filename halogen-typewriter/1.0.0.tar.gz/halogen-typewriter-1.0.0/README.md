# halogen-typewriter
A simple typewriter effect for halogen
