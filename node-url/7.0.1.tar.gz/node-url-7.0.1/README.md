# purescript-node-url

[![Latest release](http://img.shields.io/github/release/purescript-node/purescript-node-url.svg)](https://github.com/purescript-node/purescript-node-url/releases)
[![Build status](https://github.com/purescript-node/purescript-node-url/workflows/CI/badge.svg?branch=master)](https://github.com/purescript-node/purescript-node-url/actions?query=workflow%3ACI+branch%3Amaster)
[![Pursuit](https://pursuit.purescript.org/packages/purescript-node-url/badge)](https://pursuit.purescript.org/packages/purescript-node-url)

A wrapper for Node's `URL` and `QueryString` APIs

## Installation

```
spago install node-url
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-node-url).
