"use strict";

exports.typeof = function(x) {
  return (typeof x);
};
