"use strict";

exports.parse_ = JSON.parse;

exports.stringify = JSON.stringify;
