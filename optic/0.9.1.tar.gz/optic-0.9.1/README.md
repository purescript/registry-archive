# purescript-optic

[![Build Status](https://travis-ci.org/joneshf/purescript-optic.svg?branch=master)](https://travis-ci.org/joneshf/purescript-optic)
[![Latest release](http://img.shields.io/bower/v/purescript-optic.svg)](https://github.com/purescript-contrib/purescript-optic/releases)

Abstractions based on van Laarhoven lenses

- [Module Documentation](docs/)
