# purescript-optic

Abstractions based on van Laarhoven lenses

- [Module Documentation](docs/)
