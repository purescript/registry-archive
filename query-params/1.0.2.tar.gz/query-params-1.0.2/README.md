# purescript-query-params

[![Build Status](https://travis-ci.org/dgendill/purescript-query-params.svg?branch=master)](https://travis-ci.org/dgendill/purescript-query-params)

A PureScript library for reading query parameters from urls. See the [docs](./docs/QueryParams.md).

# Quick Start

See the [Example](./example/Example.purs) for some sample code.  To see it in action, you can build the example by running `npm run example` and then viewing `example/index.html`.
