# purescript-console

[![Build Status](https://travis-ci.org/purescript/purescript-console.svg?branch=master)](https://travis-ci.org/purescript/purescript-console)

Console-related functions and effect type.

## Installation

```
bower install purescript-console
```

This library requires PureScript 0.7 or later.

## Module documentation

- [Control.Monad.Eff.Console](docs/Control.Monad.Eff.Console.md)
