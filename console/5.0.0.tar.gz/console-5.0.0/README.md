# purescript-console

[![Latest release](http://img.shields.io/github/release/purescript/purescript-console.svg)](https://github.com/purescript/purescript-console/releases)
[![Build status](https://github.com/purescript/purescript-console/workflows/CI/badge.svg?branch=master)](https://github.com/purescript/purescript-console/actions?query=workflow%3ACI+branch%3Amaster)
[![Pursuit](https://pursuit.purescript.org/packages/purescript-console/badge)](https://pursuit.purescript.org/packages/purescript-console)

Console-related functions and effect type.

## Installation

```
spago install console
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-console).
