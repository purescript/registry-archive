# purescript-aff-coroutines

Helper functions for creating coroutines with the Aff monad

- [Module Documentation](docs/Control/Coroutine/Aff.md)
- [Example](test/Main.purs)

## Usage

    bower i purescript-aff-coroutines
