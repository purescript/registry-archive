# purescript-web-resize-observer

[![Latest release](http://img.shields.io/github/release/nsaunders/purescript-web-resize-observer.svg)](https://github.com/nsaunders/purescript-web-resize-observer/releases)
[![Build status](https://github.com/nsaunders/purescript-web-resize-observer/workflows/CI/badge.svg?branch=master)](https://github.com/nsaunders/purescript-web-resize-observer/actions?query=workflow%3ACI+branch%3Amaster)
[![Pursuit](https://pursuit.purescript.org/packages/purescript-web-resize-observer/badge)](https://pursuit.purescript.org/packages/purescript-web-resize-observer)

Type definitions and low level interface implementations for the [CSSWG Resize Observer Editor's Draft](https://drafts.csswg.org/resize-observer/).

## Installation

Coming soon

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-web-resize-observer).

## Example

You can see a simple example
[here](https://nsaunders.dev/purescript-web-resize-observer/example). Or, to
build it yourself, just run `npm run-script example`.
