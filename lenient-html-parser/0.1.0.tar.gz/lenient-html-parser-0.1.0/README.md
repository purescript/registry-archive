# purescript-lenient-html-parser

A reaaaaaally lenient HTML parser for purescript inspired by ndmitchell's [TagSoup](https://github.com/ndmitchell/tagsoup/).

Currently very alpha as tested for my own purposes only. Please raise issues and submit PRs!!!

## Installation

`bower i purescript-lenient-html-parser`

## Documentation

Documentation available on [Pursuit](https://pursuit.purescript.org/packages/purescript-lenient-html-parser)
