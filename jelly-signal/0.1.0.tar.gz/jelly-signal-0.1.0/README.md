# Jelly Signal

Simple Signal is a minimalistic signal library

This is not intended to manage the entire application, but only to make it easier to manage the status of a part of the application.
