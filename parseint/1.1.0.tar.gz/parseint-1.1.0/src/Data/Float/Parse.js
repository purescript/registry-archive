"use strict";

exports.unsafeParseFloat = function unsafeParseFloat(input) {
    return parseFloat(input);
};
