# parseint

Yeah so I wrote bindings to javascript's global `parseInt()` function a long while back, before realizing I
should also have added `parseFloat()` in here too... so now it's just named `purescript-parseint` :)

They're really trivial bindings - use `Radix` where applicable (i.e. hexadecimal encoding).
