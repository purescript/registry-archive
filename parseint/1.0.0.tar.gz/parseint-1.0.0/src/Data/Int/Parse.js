"use strict";

exports.unsafeParseInt = function unsafeParseInt(input,base) {
    return parseInt(input,base);
};
