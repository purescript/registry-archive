# purescript-search-trie


[![](https://img.shields.io/librariesio/github/klntsky/purescript-search-trie.svg)](https://libraries.io/github/klntsky/purescript-search-trie)
[![Build status](https://travis-ci.org/klntsky/purescript-search-trie.svg?branch=master)](https://travis-ci.org/klntsky/purescript-search-trie)

A `Map`-based `Trie` implemented using zipper.
