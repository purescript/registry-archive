# purescript-isomorphisms

A category of isomorphisms, and some standard isomorphisms 
