# purescript-snabbdom

[![Latest release](http://img.shields.io/github/release/LukaJCB/purescript-snabbdom.svg)](https://github.com/LukaJCB/purescript-snabbdom/releases) [![Build Status](https://travis-ci.org/LukaJCB/purescript-snabbdom.svg?branch=master)](https://travis-ci.org/LukaJCB/purescript-snabbdom)


A small type safe wrapper around Snabbdom.

## Installation

```
npm install snabbdom
bower install purescript-snabbdom
```

## Documentation

Module documentation is [published on Pursuit](https://pursuit.purescript.org/packages/purescript-snabbdom/).
