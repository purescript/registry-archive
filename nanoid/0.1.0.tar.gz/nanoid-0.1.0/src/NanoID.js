import {nanoid} from 'nanoid'

export const newNanoIDImpl = (length) => nanoid(length)