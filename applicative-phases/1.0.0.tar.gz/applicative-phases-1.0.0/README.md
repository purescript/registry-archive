# purescript-applicative-phases

This is a purescript implementation of Applicative Phases and `Day`, as
described in
[this paper](https://www.cs.ox.ac.uk/jeremy.gibbons/publications/phases.pdf).
