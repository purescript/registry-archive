purescript-dom-delegator
===

* [Module documentation](docs/DOM/Delegator.md)
* [examples](examples)
