# xterm

Bindings to [xterm.js](https://github.com/xtermjs/xterm.js)
