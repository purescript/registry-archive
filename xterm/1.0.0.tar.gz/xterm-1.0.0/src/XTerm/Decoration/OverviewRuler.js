export const _setColor = o => c => () => o.color = c;
export const _setPosition = o => p => () => o.position = p;
