export const id = marker => marker.id;
export const line = marker => () => marker.line;
