export const _onDispose = d => e => () => d.onDispose(e);
export const _isDisposed = d => () => d.isDisposed;
