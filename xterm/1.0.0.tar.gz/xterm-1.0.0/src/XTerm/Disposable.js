export const _dispose = disposable => () => disposable.dispose();

