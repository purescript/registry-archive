export const getCursorBlink = o => () => o.cursorBlink;
export const setCursorBlink = o => b => () => o.cursorBlink = b;
export const getFontFamily = o => () => o.fontFamily;
export const setFontFamily = o => b => () => o.fontFamily = b;

