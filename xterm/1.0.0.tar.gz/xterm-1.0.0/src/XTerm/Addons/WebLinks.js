import { WebLinksAddon } from 'xterm-addon-web-links';
export const webLinksAddon = () => new WebLinksAddon();


