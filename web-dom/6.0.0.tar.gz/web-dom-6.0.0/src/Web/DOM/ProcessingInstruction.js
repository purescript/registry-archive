export function target(pi) {
  return function () {
    return pi.target;
  };
}
