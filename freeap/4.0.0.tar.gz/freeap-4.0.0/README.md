# purescript-freeap

Free applicative functors for PureScript.

See the following reference for further information.
* [Free Applicative Functors](http://arxiv.org/abs/1403.0749) (Capriotti and Kaposi 2014)

## Installation

```
bower install purescript-freeap
```

## Documentation

* Module documentation is [published on Pursuit](https://pursuit.purescript.org/packages/purescript-freeap).
