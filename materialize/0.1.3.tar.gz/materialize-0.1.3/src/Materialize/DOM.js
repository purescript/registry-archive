exports.getInstanceImpl = function (c, element) {
    return c.getInstance(element);
};
