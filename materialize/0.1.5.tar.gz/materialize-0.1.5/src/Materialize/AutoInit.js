exports.autoInitImpl = function (parentNode) {
    M.AutoInit(parentNode);
};
