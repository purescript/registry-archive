"use strict";

exports.offsetX = function (e) {
  return e.offsetX;
};

exports.offsetY = function (e) {
  return e.offsetY;
};
