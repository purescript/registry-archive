export function offsetX(e) {
  return e.offsetX;
}

export function offsetY(e) {
  return e.offsetY;
}
