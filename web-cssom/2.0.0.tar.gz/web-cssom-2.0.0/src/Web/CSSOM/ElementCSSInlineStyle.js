export function style(el) {
  return function () {
    return el.style;
  };
}
