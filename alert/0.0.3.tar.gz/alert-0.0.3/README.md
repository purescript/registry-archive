
purescript-alert
================

[![Build
Status](https://travis-ci.org/cdepillabout/purescript-alert.svg)](https://travis-ci.org/cdepillabout/purescript-alert)

This library provides access to the alert() function from JavaScript.

### Installing

```sh
$ npm install bower
$ ./node_modules/.bin/bower install --save purescript-alert
```

### Building / Testing

```sh
$ pulp build
$ pulp test
```
