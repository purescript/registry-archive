"use strict";

var module = require('react-event-listener');

var EventListener = module.default;
var withOptions = module.withOptions;

exports.eventListenerImpl = EventListener;
exports.withOptionsImpl = withOptions;
