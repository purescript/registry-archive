# purescript-run-halogen
Work with halogen as an effect in Run
