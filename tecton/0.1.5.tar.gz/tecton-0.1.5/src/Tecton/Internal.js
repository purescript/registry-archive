export function quote(s) {
  return JSON.stringify(s);
}
