# Purescript pipes

> Port of the haskell pipes library by Gabriel Gonzalez to purescript:
> https://hackage.haskell.org/package/pipes

## Thanks to

* @scott-christopher for porting `ListT` and writing the `MonadError`,
  `MonadWriter`, `MonadPlus` and `Alternative` instances for `Proxy`!
