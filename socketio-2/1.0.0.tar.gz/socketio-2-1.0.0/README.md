Socket.io
==========


This was blatantly ripped off from [boothead's past binding](https://github.com/boothead/purescript-socketio)
