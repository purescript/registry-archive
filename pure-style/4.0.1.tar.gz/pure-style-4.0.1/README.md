# purescript-pure-style

[![Latest release](http://img.shields.io/github/release/oreshinya/purescript-pure-style.svg)](https://github.com/oreshinya/purescript-pure-style/releases)

Write scoped CSS with auto name generation in PureScript.

See [test](https://github.com/oreshinya/purescript-pure-style/blob/master/test/Main.purs).

## Installation

```
bower install purescript-pure-style
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-pure-style).

## LICENSE

MIT
