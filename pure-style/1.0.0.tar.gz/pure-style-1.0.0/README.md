# purescript-pure-style

[![Latest release](http://img.shields.io/github/release/oreshinya/purescript-pure-style.svg)](https://github.com/oreshinya/purescript-pure-style/releases)

Write CSS with PureScript.

see [example](https://github.com/oreshinya/purescript-cherry/blob/master/example/Main.purs).
see [test](https://github.com/oreshinya/purescript-pure-style/blob/master/test/Main.purs).

## Installation

```
bower install purescript-pure-style
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-pure-style).

## LICENSE

MIT
