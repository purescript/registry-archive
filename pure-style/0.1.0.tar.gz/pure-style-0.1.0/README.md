# purescript-pure-style

[![Latest release](http://img.shields.io/github/release/oreshinya/purescript-pure-style.svg)](https://github.com/oreshinya/purescript-pure-style/releases)

Write CSS with PureScript.

## Installation

```
bower install purescript-pure-style
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-pure-style).

## LICENSE

MIT
