# purescript-semirings

[![Latest release](http://img.shields.io/github/release/purescript/purescript-semirings.svg)](https://github.com/purescript/purescript-semirings/releases)
[![Build status](https://travis-ci.org/purescript/purescript-semirings.svg?branch=master)](https://travis-ci.org/purescript/purescript-semirings)

Semiring instances and functions

## Installation

```
bower install purescript-semirings
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-semirings).
