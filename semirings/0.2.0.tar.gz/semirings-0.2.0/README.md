# purescript-semirings

[![Build Status](https://travis-ci.org/purescript/purescript-semirings.svg?branch=master)](https://travis-ci.org/purescript/purescript-semirings)

Semiring instances and functions

## Installation

```
bower install purescript-semirings
```

## Module documentation

- [Data.Semiring.Free](docs/Data/Semiring/Free.md)
