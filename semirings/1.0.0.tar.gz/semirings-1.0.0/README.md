# purescript-semirings

[![Latest release](http://img.shields.io/bower/v/purescript-semirings.svg)](https://github.com/purescript/purescript-semirings/releases)
[![Build Status](https://travis-ci.org/purescript/purescript-semirings.svg?branch=master)](https://travis-ci.org/purescript/purescript-semirings)
[![Dependency Status](https://www.versioneye.com/user/projects/55848cc7363861001d000352/badge.svg?style=flat)](https://www.versioneye.com/user/projects/55848cc7363861001d000352)

Semiring instances and functions

## Installation

```
bower install purescript-semirings
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-semirings).
