# purescript-semirings

[![Latest release](http://img.shields.io/github/release/purescript/purescript-semirings.svg)](https://github.com/purescript/purescript-semirings/releases)
[![Build Status](https://github.com/purescript/purescript-semirings/workflows/CI/badge.svg?branch=master)](https://github.com/purescript/purescript-semirings/actions?query=workflow%3ACI+branch%3Amaster)
[![Pursuit](https://pursuit.purescript.org/packages/purescript-semirings/badge)](https://pursuit.purescript.org/packages/purescript-semirings)

Semiring instances and functions

## Installation

```
spago install semirings
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-semirings).
