'use strict';

// module Neon.Types.HasFromArray

module.exports = {
  nativeFromArrayString: function (x) {
    return x.join('');
  }
};
