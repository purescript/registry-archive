'use strict';

// module Neon.Bounded

module.exports = {
  jsBottomChar: String.fromCharCode(0),

  jsBottomInt: -2147483648,

  jstopChar: String.fromCharCode(65535),

  jsTopInt: 2147483647
};
