'use strict';

// module Neon.Types.HasBottom

module.exports = {
  nativeBottomChar: String.fromCharCode(0),

  nativeBottomInt: -2147483648
};
