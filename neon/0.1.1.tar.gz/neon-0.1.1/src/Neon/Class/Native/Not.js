'use strict';

// module Neon.Class.Not

module.exports = {
  nativeNot: function (x) {
    return !x;
  }
};
