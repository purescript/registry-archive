'use strict';

// module Neon.Class.FromInt

module.exports = {
  nativeFromIntChar: function (x) {
    return String.fromCharCode(x);
  }
};
