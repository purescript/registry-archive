'ues strict';

// module Neon.Class.FromArray

module.exports = {
  nativeFromArrayString: function (x) {
    return x.join('');
  }
};
