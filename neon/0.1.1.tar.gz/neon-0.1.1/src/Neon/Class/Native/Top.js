'use strict';

// module Neon.Class.Top

module.exports = {
  nativeTopInt: 2147483647,

  nativeTopNumber: Number.POSITIVE_INFINITY
};
