'use strict';

// module Neon.Primitive.Int

module.exports = {
  nativeToNumber: function (x) {
    return x;
  }
};
