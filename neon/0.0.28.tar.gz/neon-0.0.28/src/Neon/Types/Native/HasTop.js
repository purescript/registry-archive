'use strict';

// module Neon.Types.HasTop

module.exports = {
  nativeTopChar: String.fromCharCode(65535),

  nativeTopInt: 2147483647
};
