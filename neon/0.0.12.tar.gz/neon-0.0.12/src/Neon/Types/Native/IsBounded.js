'use strict';

// module Neon.Types.IsBounded

module.exports = {
  nativeBottomChar: String.fromCharCode(0),

  nativeBottomInt: -2147483648,

  nativeTopChar: String.fromCharCode(65535),

  nativeTopInt: 2147483647
};
