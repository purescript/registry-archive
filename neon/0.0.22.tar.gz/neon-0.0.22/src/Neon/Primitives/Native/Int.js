'use strict';

// module Neon.Primitives.Int

module.exports = {
  toNumber: function (x) {
    return x;
  }
};
