# [Neon][]

[![Package version][]][version]
[![Build status][]][build]

:zap: Neon is an experimental PureScript prelude.

[neon]: https://github.com/tfausak/purescript-neon
[package version]: https://img.shields.io/bower/v/purescript-neon.svg?label=version
[version]: https://github.com/tfausak/purescript-neon/releases
[build status]: https://img.shields.io/travis/tfausak/purescript-neon/master.svg
[build]: https://travis-ci.org/tfausak/purescript-neon
