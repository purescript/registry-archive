'use strict';

// module Neon.Class.ToInt

module.exports = {
  nativeToIntChar: function (x) {
    return x.charCodeAt(0);
  }
};
