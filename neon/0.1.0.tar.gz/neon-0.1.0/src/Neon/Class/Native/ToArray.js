'ues strict';

// module Neon.Class.ToArray

module.exports = {
  nativeToArrayString: function (x) {
    return x.split('');
  }
};
