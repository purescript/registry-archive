'use strict';

// module Neon.Class.Bottom

module.exports = {
  nativeBottomInt: -2147483648,

  nativeBottomNumber: Number.NEGATIVE_INFINITY
};
