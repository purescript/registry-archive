'use strict';

// module Neon.Effects.Random

module.exports = {
  randomNumber: function () {
    return Math.random();
  }
};
