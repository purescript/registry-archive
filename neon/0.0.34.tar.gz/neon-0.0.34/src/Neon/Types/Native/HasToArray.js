'use strict';

// module Neon.Types.HasToArray

module.exports = {
  nativeToArrayString: function (x) {
    return x.split('');
  }
};
