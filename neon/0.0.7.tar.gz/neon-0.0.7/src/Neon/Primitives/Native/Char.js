'use strict';

// module Neon.Primitives.Char

module.exports = {
  toLower: function (x) {
    return x.toLowerCase();
  },

  toUpper: function (x) {
    return x.toUpperCase();
  }
};
