# purescript-most

[![Latest release](http://img.shields.io/github/release/Risto-Stevcev/purescript-most.svg)](https://github.com/Risto-Stevcev/purescript-most/releases)
[![Build Status](https://travis-ci.org/Risto-Stevcev/purescript-most.svg?branch=master)](https://travis-ci.org/Risto-Stevcev/purescript-most)

Most.js bindings for purescript

## Installation

```
bower install purescript-most
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-most).
