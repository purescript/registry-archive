# purescript-metric

Metric spaces.
