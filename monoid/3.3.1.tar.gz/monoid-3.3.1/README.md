# DEPRECATED

The library is no longer maintained under this repository, it has been merged into to [`purescript-prelude`](https://github.com/purescript/purescript-prelude).

[The previous releases](https://github.com/purescript-deprecated/purescript-monoid/releases) will continue to work for older libraries that still depend on them.
