# purescript-monoid

[![Latest release](http://img.shields.io/github/release/purescript/purescript-monoid.svg)](https://github.com/purescript/purescript-monoid/releases)
[![Build status](https://travis-ci.org/purescript/purescript-monoid.svg?branch=master)](https://travis-ci.org/purescript/purescript-monoid)

Monoid algebraic structure.

## Installation

```
bower install purescript-monoid
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-monoid).
