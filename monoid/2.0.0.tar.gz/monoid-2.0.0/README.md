# purescript-monoid

[![Latest release](http://img.shields.io/bower/v/purescript-monoid.svg)](https://github.com/purescript/purescript-monoid/releases)
[![Build Status](https://travis-ci.org/purescript/purescript-monoid.svg?branch=master)](https://travis-ci.org/purescript/purescript-monoid)
[![Dependency Status](https://www.versioneye.com/user/projects/55848c2b36386100150003e1/badge.svg?style=flat)](https://www.versioneye.com/user/projects/55848c2b36386100150003e1)

Monoid algebraic structure.

## Installation

```
bower install purescript-monoid
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-monoid).
