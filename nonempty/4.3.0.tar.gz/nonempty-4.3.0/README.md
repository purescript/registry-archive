# purescript-nonempty

[![Latest release](http://img.shields.io/bower/v/purescript-nonempty.svg)](https://github.com/purescript/purescript-nonempty/releases)
[![Build Status](https://travis-ci.org/purescript/purescript-nonempty.svg?branch=master)](https://travis-ci.org/purescript/purescript-nonempty)

A generic non-empty data structure.

## Installation

```
bower install purescript-nonempty
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-nonempty).
