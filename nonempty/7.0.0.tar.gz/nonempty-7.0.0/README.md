# purescript-nonempty

[![Latest release](http://img.shields.io/github/release/purescript/purescript-nonempty.svg)](https://github.com/purescript/purescript-nonempty/releases)
[![Build status](https://github.com/purescript/purescript-nonempty/workflows/CI/badge.svg?branch=master)](https://github.com/purescript/purescript-nonempty/actions?query=workflow%3ACI+branch%3Amaster)
[![Pursuit](https://pursuit.purescript.org/packages/purescript-nonempty/badge)](https://pursuit.purescript.org/packages/purescript-nonempty)

A generic non-empty data structure.

## Installation

```
spago install nonempty
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-nonempty).
