# purescript-nonempty

[![Latest release](http://img.shields.io/bower/v/purescript-nonempty.svg)](https://github.com/purescript-contrib/purescript-nonempty/releases)
[![Maintainer: paf31](https://img.shields.io/badge/maintainer-paf31-lightgrey.svg)](http://github.com/paf31)

A generic non-empty data structure
