# purescript-cartesian 

A simple package to handle complex numbers

## Documentation

https://pursuit.purescript.org/packages/purescript-cartesian/1.0.2
