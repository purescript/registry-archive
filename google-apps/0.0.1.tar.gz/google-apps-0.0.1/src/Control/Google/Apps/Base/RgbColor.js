
exports.asHexStringImpl = (p_) => () => {
  return p_.asHexString();
}

exports.getBlueImpl = (p_) => () => {
  return p_.getBlue();
}

exports.getColorTypeImpl = (p_) => () => {
  return p_.getColorType();
}

exports.getGreenImpl = (p_) => () => {
  return p_.getGreen();
}

exports.getRedImpl = (p_) => () => {
  return p_.getRed();
}
