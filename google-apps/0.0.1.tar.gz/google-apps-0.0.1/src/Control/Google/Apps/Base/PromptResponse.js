
exports.getResponseTextImpl = (p_) => () => {
  return p_.getResponseText();
}

exports.getSelectedButtonImpl = (p_) => () => {
  return p_.getSelectedButton();
}
