
exports.getListIdImpl = (p_) => () => {
  return p_.getListId();
}

exports.getListParagraphsImpl = (p_) => () => {
  return p_.getListParagraphs();
}
