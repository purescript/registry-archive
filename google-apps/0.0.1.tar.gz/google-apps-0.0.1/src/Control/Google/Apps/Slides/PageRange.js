
exports.getPagesImpl = (p_) => () => {
  return p_.getPages();
}
