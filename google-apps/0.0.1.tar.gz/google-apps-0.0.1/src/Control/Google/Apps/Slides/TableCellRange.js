
exports.getTableCellsImpl = (p_) => () => {
  return p_.getTableCells();
}
