
exports.asRgbColorImpl = (p_) => () => {
  return p_.asRgbColor();
}

exports.asThemeColorImpl = (p_) => () => {
  return p_.asThemeColor();
}

exports.getColorTypeImpl = (p_) => () => {
  return p_.getColorType();
}
