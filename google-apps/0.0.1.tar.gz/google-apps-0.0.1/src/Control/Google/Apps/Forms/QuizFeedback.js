
exports.getLinkUrlsImpl = (p_) => () => {
  return p_.getLinkUrls();
}

exports.getTextImpl = (p_) => () => {
  return p_.getText();
}
