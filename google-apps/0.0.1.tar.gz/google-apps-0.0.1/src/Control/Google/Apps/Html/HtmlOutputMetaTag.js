
exports.getContentImpl = (p_) => () => {
  return p_.getContent();
}

exports.getNameImpl = (p_) => () => {
  return p_.getName();
}
