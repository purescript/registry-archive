
exports.getSavepointIdImpl = (p_) => () => {
  return p_.getSavepointId();
}

exports.getSavepointNameImpl = (p_) => () => {
  return p_.getSavepointName();
}
