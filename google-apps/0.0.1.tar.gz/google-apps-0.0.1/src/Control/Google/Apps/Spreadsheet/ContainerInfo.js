
exports.getAnchorColumnImpl = (p_) => () => {
  return p_.getAnchorColumn();
}

exports.getAnchorRowImpl = (p_) => () => {
  return p_.getAnchorRow();
}

exports.getOffsetXImpl = (p_) => () => {
  return p_.getOffsetX();
}

exports.getOffsetYImpl = (p_) => () => {
  return p_.getOffsetY();
}
