
exports.getDegreesImpl = (p_) => () => {
  return p_.getDegrees();
}

exports.isVerticalImpl = (p_) => () => {
  return p_.isVertical();
}
