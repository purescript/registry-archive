
exports.getDataTableImpl = (p_) => () => {
  return p_.getDataTable();
}
