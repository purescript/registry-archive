
exports.addUpdateSubjectImpl = (subject) => (p_) => () => {
  return p_.addUpdateSubject(subject);
}
