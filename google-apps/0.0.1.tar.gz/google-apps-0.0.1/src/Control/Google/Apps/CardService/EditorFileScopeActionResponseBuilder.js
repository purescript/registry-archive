
exports.buildImpl = (p_) => () => {
  return p_.build();
}

exports.requestFileScopeForActiveDocumentImpl = (p_) => () => {
  return p_.requestFileScopeForActiveDocument();
}
