
exports.charts = function () {
  return Charts;
}
