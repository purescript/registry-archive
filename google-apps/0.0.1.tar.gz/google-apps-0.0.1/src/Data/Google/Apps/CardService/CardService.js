
exports.cardService = function () {
  return CardService;
}
