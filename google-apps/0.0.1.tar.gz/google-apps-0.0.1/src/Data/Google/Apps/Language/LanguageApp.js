
exports.languageApp = function () {
  return LanguageApp;
}
