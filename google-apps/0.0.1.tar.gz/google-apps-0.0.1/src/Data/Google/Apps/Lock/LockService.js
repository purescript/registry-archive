
exports.lockService = function () {
  return LockService;
}
