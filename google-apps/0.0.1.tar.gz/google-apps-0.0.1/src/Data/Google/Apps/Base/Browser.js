
exports.browser = function () {
  return Browser;
}
