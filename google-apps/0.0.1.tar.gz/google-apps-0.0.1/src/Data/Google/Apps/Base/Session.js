
exports.session = function () {
  return Session;
}
