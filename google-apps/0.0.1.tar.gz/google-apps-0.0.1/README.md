# purescript-google-apps
Purescript bindings for Google Apps Script
