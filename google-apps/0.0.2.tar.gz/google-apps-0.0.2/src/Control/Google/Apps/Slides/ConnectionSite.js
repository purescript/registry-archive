
exports.getIndexImpl = (p_) => () => {
  return p_.getIndex();
}

exports.getPageElementImpl = (p_) => () => {
  return p_.getPageElement();
}
