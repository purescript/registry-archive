
exports.getColorTypeImpl = (p_) => () => {
  return p_.getColorType();
}

exports.getThemeColorTypeImpl = (p_) => () => {
  return p_.getThemeColorType();
}
