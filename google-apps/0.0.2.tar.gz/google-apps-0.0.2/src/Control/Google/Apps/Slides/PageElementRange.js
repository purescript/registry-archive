
exports.getPageElementsImpl = (p_) => () => {
  return p_.getPageElements();
}
