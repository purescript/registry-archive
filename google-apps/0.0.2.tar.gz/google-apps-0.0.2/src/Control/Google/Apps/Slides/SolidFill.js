
exports.getAlphaImpl = (p_) => () => {
  return p_.getAlpha();
}

exports.getColorImpl = (p_) => () => {
  return p_.getColor();
}
