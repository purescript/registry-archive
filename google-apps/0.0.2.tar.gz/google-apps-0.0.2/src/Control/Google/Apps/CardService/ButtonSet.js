
exports.addButtonImpl = (button) => (p_) => () => {
  return p_.addButton(button);
}
