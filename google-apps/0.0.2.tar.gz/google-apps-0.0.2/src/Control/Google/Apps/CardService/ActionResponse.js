
exports.printJsonImpl = (p_) => () => {
  return p_.printJson();
}
