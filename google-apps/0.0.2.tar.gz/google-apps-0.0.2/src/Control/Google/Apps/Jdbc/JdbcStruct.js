
exports.getAttributesImpl = (p_) => () => {
  return p_.getAttributes();
}

exports.getSqlTypeNameImpl = (p_) => () => {
  return p_.getSQLTypeName();
}
