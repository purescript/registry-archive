
exports.getDaysOfTheMonthImpl = (p_) => () => {
  return p_.getDaysOfTheMonth();
}

exports.getDaysOfTheWeekImpl = (p_) => () => {
  return p_.getDaysOfTheWeek();
}

exports.getFrequencyTypeImpl = (p_) => () => {
  return p_.getFrequencyType();
}

exports.getStartHourImpl = (p_) => () => {
  return p_.getStartHour();
}
