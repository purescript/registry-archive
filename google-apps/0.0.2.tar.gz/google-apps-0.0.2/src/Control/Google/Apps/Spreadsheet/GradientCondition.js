
exports.getMaxColorImpl = (p_) => () => {
  return p_.getMaxColor();
}

exports.getMaxColorObjectImpl = (p_) => () => {
  return p_.getMaxColorObject();
}

exports.getMaxTypeImpl = (p_) => () => {
  return p_.getMaxType();
}

exports.getMaxValueImpl = (p_) => () => {
  return p_.getMaxValue();
}

exports.getMidColorImpl = (p_) => () => {
  return p_.getMidColor();
}

exports.getMidColorObjectImpl = (p_) => () => {
  return p_.getMidColorObject();
}

exports.getMidTypeImpl = (p_) => () => {
  return p_.getMidType();
}

exports.getMidValueImpl = (p_) => () => {
  return p_.getMidValue();
}

exports.getMinColorImpl = (p_) => () => {
  return p_.getMinColor();
}

exports.getMinColorObjectImpl = (p_) => () => {
  return p_.getMinColorObject();
}

exports.getMinTypeImpl = (p_) => () => {
  return p_.getMinType();
}

exports.getMinValueImpl = (p_) => () => {
  return p_.getMinValue();
}
