
exports.getEmailImpl = (p_) => () => {
  return p_.getEmail();
}
