
exports.newConferenceDataBuilderImpl = (p_) => () => {
  return p_.newConferenceDataBuilder();
}

exports.newConferenceErrorImpl = (p_) => () => {
  return p_.newConferenceError();
}

exports.newConferenceParameterImpl = (p_) => () => {
  return p_.newConferenceParameter();
}

exports.newEntryPointImpl = (p_) => () => {
  return p_.newEntryPoint();
}
