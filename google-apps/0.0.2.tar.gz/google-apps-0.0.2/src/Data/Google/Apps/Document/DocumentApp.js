
exports.documentApp = function () {
  return DocumentApp;
}
