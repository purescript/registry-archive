
exports.service = function () {
  return Service;
}
