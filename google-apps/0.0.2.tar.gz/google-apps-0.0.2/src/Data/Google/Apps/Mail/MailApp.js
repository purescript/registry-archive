
exports.mailApp = function () {
  return MailApp;
}
