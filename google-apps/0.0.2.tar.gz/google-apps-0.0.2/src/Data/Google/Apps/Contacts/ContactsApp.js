
exports.contactsApp = function () {
  return ContactsApp;
}
