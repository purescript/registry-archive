
exports.gmailApp = function () {
  return GmailApp;
}
