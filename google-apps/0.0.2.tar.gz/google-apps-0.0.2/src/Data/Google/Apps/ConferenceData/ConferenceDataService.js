
exports.conferenceDataService = function () {
  return ConferenceDataService;
}
