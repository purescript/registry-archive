
exports.groupsApp = function () {
  return GroupsApp;
}
