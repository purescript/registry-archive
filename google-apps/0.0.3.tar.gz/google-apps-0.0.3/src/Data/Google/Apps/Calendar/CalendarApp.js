
exports.calendarApp = function () {
  return CalendarApp;
}
