
exports.htmlService = function () {
  return HtmlService;
}
