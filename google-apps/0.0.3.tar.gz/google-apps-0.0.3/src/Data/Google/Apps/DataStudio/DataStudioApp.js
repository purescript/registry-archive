
exports.dataStudioApp = function () {
  return DataStudioApp;
}
