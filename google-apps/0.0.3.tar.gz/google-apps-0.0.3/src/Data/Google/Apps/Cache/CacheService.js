
exports.cacheService = function () {
  return CacheService;
}
