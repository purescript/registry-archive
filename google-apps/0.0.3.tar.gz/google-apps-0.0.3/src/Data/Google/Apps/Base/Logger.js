
exports.logger = function () {
  return Logger;
}
