
exports.contentService = function () {
  return ContentService;
}
