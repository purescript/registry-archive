
exports.propertiesService = function () {
  return PropertiesService;
}
