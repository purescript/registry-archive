
exports.getRuleTypeImpl = (p_) => () => {
  return p_.getRuleType();
}
