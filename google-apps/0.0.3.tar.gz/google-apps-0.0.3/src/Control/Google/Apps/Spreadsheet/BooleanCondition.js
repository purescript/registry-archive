
exports.getBackgroundImpl = (p_) => () => {
  return p_.getBackground();
}

exports.getBackgroundObjectImpl = (p_) => () => {
  return p_.getBackgroundObject();
}

exports.getBoldImpl = (p_) => () => {
  return p_.getBold();
}

exports.getCriteriaTypeImpl = (p_) => () => {
  return p_.getCriteriaType();
}

exports.getCriteriaValuesImpl = (p_) => () => {
  return p_.getCriteriaValues();
}

exports.getFontColorImpl = (p_) => () => {
  return p_.getFontColor();
}

exports.getFontColorObjectImpl = (p_) => () => {
  return p_.getFontColorObject();
}

exports.getItalicImpl = (p_) => () => {
  return p_.getItalic();
}

exports.getStrikethroughImpl = (p_) => () => {
  return p_.getStrikethrough();
}

exports.getUnderlineImpl = (p_) => () => {
  return p_.getUnderline();
}
