
exports.getDataSourceColumnImpl = (p_) => () => {
  return p_.getDataSourceColumn();
}

exports.removeImpl = (p_) => () => {
  return p_.remove();
}
