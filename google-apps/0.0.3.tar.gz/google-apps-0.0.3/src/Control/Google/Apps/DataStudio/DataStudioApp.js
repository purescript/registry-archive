
exports.createCommunityConnectorImpl = (p_) => () => {
  return p_.createCommunityConnector();
}
