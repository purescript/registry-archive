
exports.getAutoTextTypeImpl = (p_) => () => {
  return p_.getAutoTextType();
}

exports.getIndexImpl = (p_) => () => {
  return p_.getIndex();
}

exports.getRangeImpl = (p_) => () => {
  return p_.getRange();
}
