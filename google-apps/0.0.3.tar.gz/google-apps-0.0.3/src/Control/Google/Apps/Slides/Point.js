
exports.getXImpl = (p_) => () => {
  return p_.getX();
}

exports.getYImpl = (p_) => () => {
  return p_.getY();
}
