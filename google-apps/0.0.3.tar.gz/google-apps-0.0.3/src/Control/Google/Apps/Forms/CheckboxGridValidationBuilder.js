
exports.requireLimitOneResponsePerColumnImpl = (p_) => () => {
  return p_.requireLimitOneResponsePerColumn();
}
