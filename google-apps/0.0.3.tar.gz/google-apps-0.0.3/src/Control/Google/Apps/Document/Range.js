
exports.getRangeElementsImpl = (p_) => () => {
  return p_.getRangeElements();
}
