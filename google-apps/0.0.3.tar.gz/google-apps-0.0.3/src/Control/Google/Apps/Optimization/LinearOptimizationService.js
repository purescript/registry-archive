
exports.createEngineImpl = (p_) => () => {
  return p_.createEngine();
}
