
exports.getColorImpl = (p_) => () => {
  return p_.getColor();
}

exports.getFontNameImpl = (p_) => () => {
  return p_.getFontName();
}

exports.getFontSizeImpl = (p_) => () => {
  return p_.getFontSize();
}
