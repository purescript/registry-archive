
exports.newAreaChartImpl = (p_) => () => {
  return p_.newAreaChart();
}

exports.newBarChartImpl = (p_) => () => {
  return p_.newBarChart();
}

exports.newColumnChartImpl = (p_) => () => {
  return p_.newColumnChart();
}

exports.newDataTableImpl = (p_) => () => {
  return p_.newDataTable();
}

exports.newDataViewDefinitionImpl = (p_) => () => {
  return p_.newDataViewDefinition();
}

exports.newLineChartImpl = (p_) => () => {
  return p_.newLineChart();
}

exports.newPieChartImpl = (p_) => () => {
  return p_.newPieChart();
}

exports.newScatterChartImpl = (p_) => () => {
  return p_.newScatterChart();
}

exports.newTableChartImpl = (p_) => () => {
  return p_.newTableChart();
}

exports.newTextStyleImpl = (p_) => () => {
  return p_.newTextStyle();
}
