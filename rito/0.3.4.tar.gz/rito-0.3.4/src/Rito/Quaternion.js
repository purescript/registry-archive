export const ctor_ =
	(quaternion) =>
	({ x, y, z, w }) =>
		new quaternion(x, y, z, w);
