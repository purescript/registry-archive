export const ctor_ = (box3) => ({ min, max }) => new box3(min, max);
