export const ctor_ =
	(sphere) =>
	({ center, radius }) =>
		new sphere(center, radius);
