export const ctor_ =
	(euler) =>
	({ x, y, z }) =>
		new euler(x, y, z);
