# purescript-rito

A canvas graphics FRP library backed by [three.js](https://github.com/mrdoob/three.js).

## What does Rito mean?

Rito is short for "Reentrant idempotent three.js objects." It is also a race of flying birds that appears in _The Wind Waker_ and _Breath of the Wild_.
