# purescript-conveyor-health

[![Latest release](http://img.shields.io/github/release/oreshinya/purescript-conveyor-health.svg)](https://github.com/oreshinya/purescript-conveyor-health/releases)

Healthcheck endpoint for [conveyor](https://github.com/oreshinya/purescript-conveyor).

## Installation

```
bower install purescript-conveyor-health
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-conveyor-health).

## LICENSE

MIT
