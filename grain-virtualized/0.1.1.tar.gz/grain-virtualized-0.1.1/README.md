# purescript-grain-virtualized

[![Latest release](http://img.shields.io/github/release/purescript-grain/purescript-grain-virtualized.svg)](https://github.com/purescript-grain/purescript-grain-virtualized/releases)

The virtual list to render huge list efficiently for [purescript-grain](https://github.com/purescript-grain/purescript-grain).

[Demo](https://purescript-grain.github.io/purescript-grain-virtualized/)

## Installation

### Spago

```
$ spago install grain-virtualized
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-grain-virtualized).

## LICENSE

MIT
