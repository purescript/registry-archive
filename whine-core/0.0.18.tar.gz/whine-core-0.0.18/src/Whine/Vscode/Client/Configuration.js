export const get_ = (section, c) => c.get(section)
