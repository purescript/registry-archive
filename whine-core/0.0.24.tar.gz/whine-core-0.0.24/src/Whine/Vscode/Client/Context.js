export const asAbsolutePath = path => ctx => ctx.asAbsolutePath(path)
