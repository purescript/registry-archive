# puriscript-base58

A simple [bs58](https://github.com/cryptocoinjs/bs58) wrapper for
[purescript](https://github.com/purescript/purescript)
