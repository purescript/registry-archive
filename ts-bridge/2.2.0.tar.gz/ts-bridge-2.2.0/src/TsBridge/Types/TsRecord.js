export const getKeyImpl = (k) => (r) => r[k]
