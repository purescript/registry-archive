# purescript-facebook
Idiomatic Purescript bindings for the Facebook SDK
