# Purescript bindings for passportjs library

[![Documentation](http://pursuit.purescript.org/packages/purescript-express-passport/badge)](http://pursuit.purescript.org/packages/purescript-express-passport)

## Installation

```
bower install purescript-express-passport

npm install passport
npm install passport-local
```

