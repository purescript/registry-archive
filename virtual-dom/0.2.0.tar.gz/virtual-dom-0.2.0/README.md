# purescript-virtual-dom

[virtual-dom](https://github.com/Matt-Esch/virtual-dom) bindings for PureScript
