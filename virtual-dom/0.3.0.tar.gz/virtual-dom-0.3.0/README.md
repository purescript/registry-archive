# purescript-virtual-dom

[virtual-dom](https://github.com/Matt-Esch/virtual-dom) bindings for PureScript.

This library is only aiming to provide basic `virtual-dom` functionality, with the intention that user-friendly libraries will be built on top of it to provide stronger typing, a `VTree` DSL, etc.

- [Module documentation](docs/Module.md)
