# purescript-applicative-lists

See the following reference for further information.
* [Free Applicative Functors in Haskell](https://www.eyrie.org/~zednenem/2013/05/27/freeapp) (Menendez 2013)

## Installation

```
bower install purescript-applicative-lists
```
