# purescript-cookie

[![Latest release](http://img.shields.io/github/release/oreshinya/purescript-cookie.svg)](https://github.com/oreshinya/purescript-cookie/releases)

PureScript Cookie manager.

## Installation

```
bower install purescript-cookie
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-cookie).

## LICENSE

MIT
