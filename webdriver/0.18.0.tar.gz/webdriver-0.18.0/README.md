# purescript-webdriver

[![Latest release](http://img.shields.io/bower/v/purescript-webdriver.svg)](https://github.com/slamdata/purescript-webdriver/releases)
[![Build Status](https://travis-ci.org/slamdata/purescript-webdriver.svg?branch=master)](https://travis-ci.org/slamdata/purescript-webdriver)
[![Dependency Status](https://www.versioneye.com/user/projects/56e75a7696f80c0054234ffd/badge.svg?style=flat)](https://www.versioneye.com/user/projects/56e75a7696f80c0054234ffd)

A PureScript interface to Selenium's Node Webdriver.

## Installation

``` purescript
bower install purescript-webdriver
```

## Module documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-webdriver).
