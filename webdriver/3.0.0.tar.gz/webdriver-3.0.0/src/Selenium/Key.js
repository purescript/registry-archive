// module Selenium.Key

var k = require("selenium-webdriver").Key;

exports.altKey = k.ALT;
exports.controlKey = k.CONTROL;
exports.shiftKey = k.SHIFT;
exports.commandKey = k.COMMAND;
exports.metaKey = k.META;
