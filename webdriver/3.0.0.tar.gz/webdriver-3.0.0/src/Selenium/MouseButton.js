// module Selenium.MouseButton

var b = require("selenium-webdriver").Button;

exports.leftButton = b.LEFT;
exports.rightButton = b.RIGHT;
exports.middleButton = b.MIDDLE;
