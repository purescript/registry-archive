// module Selenium.ScrollBehaviour

exports.top = 0;
exports.bottom = 1;
