# purescript-webdriver
A PureScript interface to Selenium's Node Webdriver.
