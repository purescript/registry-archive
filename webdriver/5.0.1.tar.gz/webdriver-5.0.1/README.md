# purescript-webdriver

[![Latest release](http://img.shields.io/github/release/slamdata/purescript-webdriver.svg)](https://github.com/slamdata/purescript-webdriver/releases)
[![Build status](https://travis-ci.org/slamdata/purescript-webdriver.svg?branch=master)](https://travis-ci.org/slamdata/purescript-webdriver)

A PureScript interface to Selenium's Node Webdriver.

## Installation

``` purescript
bower install purescript-webdriver
```

## Module documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-webdriver).
