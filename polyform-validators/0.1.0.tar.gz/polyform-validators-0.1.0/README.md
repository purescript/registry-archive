# DEPRECATED

The library is no longer maintained under this repository. It has been splitted into several batteries-* libs under https://github.com/purescript-polyform org.

The previous releases will continue to work for older libraries that still depend on them.
