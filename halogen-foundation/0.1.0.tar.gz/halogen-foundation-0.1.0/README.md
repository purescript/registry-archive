# purescript-halogen-foundation

A Foundation 5 theme for `purescript-halogen`.
