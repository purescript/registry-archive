purescript-psc-ide
===

A PureScript client for `purs ide server` (previously `psc-ide`). Information about the IDE server and protocol
can be found in the [compiler repository](https://github.com/purescript/purescript/tree/master/psc-ide).

Dependencies
====

The npm dependency `which` is required for certain functionality.

```
npm install -S which
```
