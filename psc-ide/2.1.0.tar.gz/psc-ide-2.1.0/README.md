purescript-psc-ide
===

A PureScript client for the psc-ide tool.

Dependencies
====

The npm dependency `which` is required for certain functionality.

```
npm install -S which
```
