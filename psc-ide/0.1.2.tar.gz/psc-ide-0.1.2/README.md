purescript-psc-ide
===

A PureScript client for the psc-ide tool.
