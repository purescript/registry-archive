# purescript-nextui

Bindings for [NextUI](https://nextui.org/).

