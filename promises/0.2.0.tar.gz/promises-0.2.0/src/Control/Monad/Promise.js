exports.thenImpl = function (promise, onFulfilled, onRejected) {
  return promise.then(onFulfilled, onRejected);
};

exports.catchImpl = function (promise, f) {
  return promise.catch(f);
}

exports.resolve = function (a) {
  return Promise.resolve(a);
}

exports.rejectImpl = function (a) {
  return Promise.reject(a);
}

exports.promiseToEffImpl = function (promise, onFulfilled, onRejected) {
  return function () {
    promise.then(onFulfilled(), onRejected());
    return null;
  }
}

exports.allImpl = function (arr) {
  return Promise.all(arr);
}

exports.raceImpl = function (arr) {
  return Promise.race(arr);
}

exports.delayImpl = function (a, ms) {
  return new Promise(function (resolve, reject) {
    setTimeout(resolve, ms, a);
  });
}
