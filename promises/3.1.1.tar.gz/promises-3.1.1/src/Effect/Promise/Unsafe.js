exports.undefer = function (f) {
  return f();
};
