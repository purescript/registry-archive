# purescript-quotient

Quotient type approximation in PureScript.
