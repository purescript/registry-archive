[![Build Status](https://travis-ci.org/jutaro/purescript-typedarray.svg?branch=master)](https://travis-ci.org/jutaro/purescript-typedarray)


Binding to  of Javascript TypedArrays (I guess only useful for FFI interfaces)

This module should be imported qualified, like 'import qualified Data.TypedArray as T'.

## Module documentation

- [Data.TypedArray](docs/Data/TypedArray.md)

Build with:
~~~
npm install
pulp dep install
pulp build
~~~
