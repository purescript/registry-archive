# purescript-options

[![Latest release](http://img.shields.io/bower/v/purescript-options.svg)](https://github.com/purescript-contrib/purescript-options/releases)
[![Maintainer: ethul](https://img.shields.io/badge/maintainer-ethul-lightgrey.svg)](http://github.com/ethul)

## Documentation

* [Data.Options](docs/Data/Options.md)
