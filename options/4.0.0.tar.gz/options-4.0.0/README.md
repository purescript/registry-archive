# purescript-options

[![Latest release](http://img.shields.io/github/release/purescript-contrib/purescript-options.svg)](https://github.com/purescript-contrib/purescript-options/releases)
[![Build Status](https://travis-ci.org/purescript-contrib/purescript-options.svg?branch=master)](https://travis-ci.org/purescript-contrib/purescript-options)
[![Maintainer: ethul](https://img.shields.io/badge/maintainer-ethul-lightgrey.svg)](http://github.com/ethul)

Types and functions for dealing with JavaScript options objects.

## Installation

```
bower install purescript-options
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-options).
