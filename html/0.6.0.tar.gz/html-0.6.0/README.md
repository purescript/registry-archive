purescript-html
===
[![Build Status](https://travis-ci.org/philopon/purescript-html.svg?branch=master)](https://travis-ci.org/philopon/purescript-html)
[![Bower version](https://badge.fury.io/bo/purescript-html.svg)](http://badge.fury.io/bo/purescript-html)
[![devDependency Status](https://david-dm.org/philopon/purescript-html/dev-status.svg)](https://david-dm.org/philopon/purescript-html#info=devDependencies)

middle level virtual-dom binding for purescript.

* [Module documentation](docs)
* [examples](examples)
