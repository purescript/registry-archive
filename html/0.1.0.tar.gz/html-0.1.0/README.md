purescript-html
===
[![devDependency Status](https://david-dm.org/philopon/purescript-html/dev-status.svg)](https://david-dm.org/philopon/purescript-html#info=devDependencies)

middle level virtual-dom binding for purescript.

* [Module documentation](docs)
* [examples](examples)
