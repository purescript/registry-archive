# purescript-struct

Utilities for generalizing rowtype encapsulations of kind Type

## Installation

```
bower install purescript-struct
```
