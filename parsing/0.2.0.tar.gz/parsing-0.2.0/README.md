purescript-parsing
==================

[![Build Status](https://travis-ci.org/purescript-contrib/purescript-parsing.svg?branch=master)](https://travis-ci.org/purescript-contrib/purescript-parsing)

A work-in-progress parser combinator library written in PureScript.

- [Module documentation](docs/Module.md)
- [Example usage](examples/Test.purs)
