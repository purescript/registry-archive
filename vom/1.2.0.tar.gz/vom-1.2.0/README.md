# purescript-vom

[![Latest release](http://img.shields.io/github/release/oreshinya/purescript-vom.svg)](https://github.com/oreshinya/purescript-vom/releases)

PureScript virtual dom implementation.
See [example](https://github.com/oreshinya/purescript-cherry/blob/master/example/Main.purs).

## Installation

```
bower install purescript-vom
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-vom).

## LICENSE

MIT
