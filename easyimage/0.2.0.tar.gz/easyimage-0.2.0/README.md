# purescript-easyimage
A purescript interface to easyimage library
