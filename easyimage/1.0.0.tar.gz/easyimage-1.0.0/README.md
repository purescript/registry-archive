# purescript-easyimage

[![Latest release](http://img.shields.io/bower/v/purescript-easyimage.svg)](https://github.com/slamdata/purescript-easyimage/releases)
[![Build Status](https://travis-ci.org/slamdata/purescript-easyimage.svg?branch=master)](https://travis-ci.org/slamdata/purescript-easyimage)
[![Dependency Status](https://www.versioneye.com/user/projects/56e75dff96f80c003cade740/badge.svg?style=flat)](https://www.versioneye.com/user/projects/56e75dff96f80c003cade740)

A purescript interface to the easyimage library.

## Installation

``` purescript
bower install purescript-easyimage
```

## Module documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-easyimage).
