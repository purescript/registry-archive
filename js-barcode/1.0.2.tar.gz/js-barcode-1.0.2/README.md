# purescript-js-barcode
Purescript bindings for the [JsBarcode](https://github.com/lindell/JsBarcode)
