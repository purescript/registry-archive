# purescript-react-redux

A library for using [Redux with React](http://redux.js.org/docs/basics/UsageWithReact.html).

## Installation

```bash
bower install --save purescript-react-redux
```

## Example

Refer to the [purescript-react-redux-example](https://github.com/ethul/purescript-react-redux-example) for an example.
