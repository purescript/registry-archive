# purescript-svgo

[![purescript-svgo on Pursuit](https://pursuit.purescript.org/packages/purescript-svgo/badge)](https://pursuit.purescript.org/packages/purescript-svgo)
[![CircleCI](https://circleci.com/gh/nonbili/purescript-svgo.svg?style=svg)](https://circleci.com/gh/nonbili/purescript-svgo)

A PureScript wrapper of [SVGO](https://github.com/svg/svgo).

Check `test` folder to see how to use.
