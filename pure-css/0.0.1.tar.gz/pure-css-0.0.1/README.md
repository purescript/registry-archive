# purescript-pure-css

Simple bindings to the class names dictated by the [Pure.css](https://purecss.io) project.
