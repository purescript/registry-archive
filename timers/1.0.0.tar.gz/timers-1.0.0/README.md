# purescript-timers

[![Build Status](https://travis-ci.org/CapillarySoftware/purescript-timers.svg?branch=master)](https://travis-ci.org/CapillarySoftware/purescript-timers)
[![Bower version](https://badge.fury.io/bo/purescript-timers.svg)](http://badge.fury.io/bo/purescript-timers)
[![Dependency Status](https://www.versioneye.com/user/projects/54722c968101065aaf000981/badge.svg?style=flat)](https://www.versioneye.com/user/projects/54722c968101065aaf000981)

## Installation

```
bower install purescript-timers
```

## Module documentation

- [Control.Timer](docs/Control/Timer.md)

## Build

```
pulp build
pulp test
pulp docs
```
