# purescript-text 

A library for generating text layouts.