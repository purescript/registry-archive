# purescript-bf-gun

Gun DB in purescript.
