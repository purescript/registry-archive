# purescript-freedom-window-resize

[![Latest release](http://img.shields.io/github/release/purescript-freedom/purescript-freedom-window-resize.svg)](https://github.com/purescript-freedom/purescript-freedom-window-resize/releases)

`Subscription` of resizing window for [purescript-freedom](https://github.com/purescript-freedom/purescript-freedom).

[Demo](https://purescript-freedom.github.io/purescript-freedom-window-resize/)

## Installation

```
bower install purescript-freedom-window-resize
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-freedom-window-resize).

## LICENSE

MIT
