# purescript-es6-symbols

[![Latest release](http://img.shields.io/bower/v/purescript-es6-symbols.svg)](https://github.com/Risto-Stevcev/purescript-es6-symbols/releases)
[![Build Status](https://travis-ci.org/Risto-Stevcev/purescript-es6-symbols.svg?branch=master)](https://travis-ci.org/Risto-Stevcev/purescript-es6-symbols)

ES6 symbols for purescript


## Installation

```
bower install purescript-es6-symbols
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-es6-symbols).

