# purescript-signal-loop

A [Halogen](https://github.com/slamdata/purescript-halogen)-style abstraction on top of [`purescript-signal`](https://github.com/bodil/purescript-signal).

- [Module Documentation](docs/Signal/Loop.md)
- [Console Example](test/Main.purs)

## Usage

    bower i purescript-signal-loop
