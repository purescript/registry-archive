PureScript wrapper around [CodeSlide](https://github.com/thejameskyle/spectacle-code-slide), a [Spectacle](https://github.com/FormidableLabs/spectacle) plugin.
You will need to also `npm install -S react react-dom spectacle spectacle-code-slide` for this to work.

Example [here](https://github.com/spicydonuts/purescript-spectacle-presentation)!