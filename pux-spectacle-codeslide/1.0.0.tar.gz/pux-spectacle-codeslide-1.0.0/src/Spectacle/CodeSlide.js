"use strict";

var Pux = require("purescript-pux");
var CodeSlide = require("spectacle-code-slide");

exports.codeSlide = Pux.fromReact(CodeSlide);
