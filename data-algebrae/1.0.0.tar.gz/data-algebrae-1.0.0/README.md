# purescript-data-algebrae
Reified operations for several common data structures.
