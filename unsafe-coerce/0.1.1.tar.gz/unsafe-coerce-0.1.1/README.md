# purescript-unsafe-coerce

Unsafe coercion of values.

- [Module Documentation](docs/Unsafe/Coerce.md)
