"use strict";

// module Unsafe.Coerce

exports.unsafeCoerce = function (x) {
  return x;
};
