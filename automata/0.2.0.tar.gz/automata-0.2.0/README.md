# purescript-automata

This is a library for representing different levels of automata.
