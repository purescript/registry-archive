# purescript-tree

[![Build status](https://img.shields.io/travis/dmbfm/purescript-tree.svg)](https://travis-ci.org/dmbfm/purescript-tree)

Multi-way trees with Zippers.

## Installation

```
bower install purescript-tree
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-tree).