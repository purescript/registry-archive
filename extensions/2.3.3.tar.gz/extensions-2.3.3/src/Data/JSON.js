"use strict";

exports.stringify = function(x) {
    return JSON.stringify(x);
};
