[![Build Status](https://travis-ci.org/jutaro/purescript-extensions.svg?branch=master)](https://travis-ci.org/jutaro/purescript-extensions)

Extensions for [purescript](http://www.purescript.org)

An ugly bunch and unpure mixture.
