# purescript-aff

An asynchronous effect monad for PureScript.

# Documentation

[MODULES.md](MODULES.md)
