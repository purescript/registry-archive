# purescript-aff
An asynchronous effect monad for PureScript
