# purescript-datetime-parsing

This library aims to provide unopinionated parsing options for ISO 8601 / RFC 3339 datetime strings.

## Unsupported

As of this writing, leap seconds are not supported. This is due to the DateTime library itself not supporting them.
