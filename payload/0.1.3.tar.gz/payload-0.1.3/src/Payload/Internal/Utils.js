exports.toLowerCase = function(str){
  return str.toLowerCase()
}
