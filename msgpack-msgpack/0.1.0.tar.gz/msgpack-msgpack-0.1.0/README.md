# purescript-msgpack-msgpack

[![purescript-msgpack-msgpack on Pursuit](https://pursuit.purescript.org/packages/purescript-msgpack-msgpack/badge)](https://pursuit.purescript.org/packages/purescript-msgpack-msgpack)
[![CircleCI](https://circleci.com/gh/nonbili/purescript-msgpack-msgpack.svg?style=svg)](https://circleci.com/gh/nonbili/purescript-msgpack-msgpack)

A PureScript wrapper of [@msgpack/msgpack](https://www.npmjs.com/package/@msgpack/msgpack).

Check `test` folder to see how to use.
