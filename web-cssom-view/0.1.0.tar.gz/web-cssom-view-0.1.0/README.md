# purescript-web-cssom-view

Type definitions and low level interface implementations for the [W3C CSSOM View Module](https://www.w3.org/TR/cssom-view-1).

## Installation

```
bower install purescript-web-cssom-view
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-web-cssom-view).
