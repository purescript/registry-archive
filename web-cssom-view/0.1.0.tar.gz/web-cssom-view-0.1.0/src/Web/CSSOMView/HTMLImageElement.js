export function x(imageElement) {
  return function () {
    return imageElement.x;
  };
}

export function y(imageElement) {
  return function () {
    return imageElement.y;
  };
}
