export function media(mediaQueryListEvent) {
  return mediaQueryListEvent.media;
}

export function matches(mediaQueryListEvent) {
  return mediaQueryListEvent.matches;
}
