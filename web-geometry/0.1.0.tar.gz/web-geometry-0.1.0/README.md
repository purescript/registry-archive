# purescript-web-geometry

Type definitions and low level interface implementations for the [W3C Geometry Interfaces Module](https://www.w3.org/TR/geometry-1).

## Installation

```
bower install purescript-web-geometry
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-web-geometry).
