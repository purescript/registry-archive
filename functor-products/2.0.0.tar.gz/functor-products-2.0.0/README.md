# purescript-functor-products

[![Latest release](http://img.shields.io/bower/v/purescript-functor-products.svg)](https://github.com/purescript/purescript-functor-products/releases)
[![Build Status](https://travis-ci.org/purescript/purescript-functor-products.svg)](https://travis-ci.org/purescript/purescript-functor-products)
[![Dependency Status](https://www.versioneye.com/user/projects/56f53e0e35630e003888aa14/badge.svg?style=flat)](https://www.versioneye.com/user/projects/56f53e0e35630e003888aa14)

Functor products.

## Installation

```
bower install purescript-functor-products
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-functor-products).
