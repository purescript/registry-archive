# purescript-random-secure

Library for generating secure random data. This only works on Node.js.
