# purescript-complex

## Installation
```
bower install purescript-complex
```

## Module documentation

- [Data.Complex](docs/Data/Complex.md)
