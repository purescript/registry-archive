# purescript-halogen-pure

[![Latest release](http://img.shields.io/github/release/aij/purescript-halogen-pure.svg)](https://github.com/aij/purescript-halogen-pure/releases)

Functions to create pure Halogen components.

## Installation

    bower install purescript-halogen-pure

## Documentation

Module documentation is to be [published on Pursuit](http://pursuit.purescript.org/packages/purescript-halogen-pure).

Example usage can be seen in [`test/Main.purs`](test/Main.purs)
