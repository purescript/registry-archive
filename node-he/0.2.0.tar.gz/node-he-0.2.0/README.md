# purescript-node-he

Wrapper around [he](https://github.com/mathiasbynens/he)

## Installation

You will need to install `he` along with this package.

```
npm i -S he
bower i -S purescript-node-he
```
