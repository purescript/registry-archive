# purescript-string-extra

[![Latest release](http://img.shields.io/github/release/purescript-contrib/purescript-strings-extra.svg)](https://github.com/purescript-contrib/purescript-strings-extra/releases)
[![Build status](https://travis-ci.org/purescript-contrib/purescript-strings-extra.svg?branch=master)](https://travis-ci.org/purescript-contrib/purescript-strings-extra)
[![Pursuit](http://pursuit.purescript.org/packages/purescript-strings-extra/badge)](http://pursuit.purescript.org/packages/purescript-strings-extra/)
[![Maintainer: garyb](https://img.shields.io/badge/maintainer-garyb-lightgrey.svg)](http://github.com/garyb)
[![Maintainer: thomashoneyman](https://img.shields.io/badge/maintainer-thomashoneyman-lightgrey.svg)](http://github.com/thomashoneyman)

Additional utilities for PureScript Strings.

## Installation

```bash
bower install purescript-strings-extra
```

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-strings-extra).

## Contributing

Read the [contribution guidelines](https://github.com/purescript-contrib/purescript-strings-extra/blob/master/.github/contributing.md) to get started and see helpful related resources.
