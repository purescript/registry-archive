# purescript-string-extra

Additional utilities for PureScript Strings.


[![Latest release](http://img.shields.io/github/release/purescript-contrib/purescript-strings-extra.svg)](https://github.com/purescript/purescript-strings-extra/releases)
[![Build status](https://travis-ci.org/purescript-contrib/purescript-strings-extra.svg?branch=master)](https://travis-ci.org/purescript/purescript-strings-extra)


## Installation

```bash
bower install purescript-strings-extra
```

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-strings-extra).
