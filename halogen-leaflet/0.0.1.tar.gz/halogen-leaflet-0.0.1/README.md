# purescript-halogen-leaflet

Use [Leaflet](https://leafletjs.com/) in
[Halogen](https://github.com/slamdata/halogen/).

Unfortunately, I haven't gotten around to writing any documentation
whatsover, so you'll have to figure things out yourself based on the
source code. But hey, type signatures are all the documentation you
could possibly need, right? RIGHT?
