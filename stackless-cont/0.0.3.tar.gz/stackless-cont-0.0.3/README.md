# purescript-stackless-cont
Stack-Safe Continuations for PureScript

![Left Binds Small](Benchmark/graphs/left-bind-small.png)

![Right Binds Small](Benchmark/graphs/right-bind-small.png)

![Left Binds Large](Benchmark/graphs/left-bind-large.png)

![Right Binds Large](Benchmark/graphs/right-bind-large.png)
