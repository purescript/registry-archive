# purescript-uuid

[![Build Status](https://travis-ci.org/spicydonuts/purescript-uuid.svg?branch=master)](https://travis-ci.org/spicydonuts/purescript-uuid)

Wrapper for the `uuid` npm package.
This package is not installed automatically, as it comes from `npm`.
Install it with `npm install -S uuid`.
