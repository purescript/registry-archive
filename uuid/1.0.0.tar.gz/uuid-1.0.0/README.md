#purescript-uuid

Wrapper for the `uuid` npm package.
`uuid` is not installed automatically, as it comes from `npm`.
Install it with `npm install -S uuid`.
