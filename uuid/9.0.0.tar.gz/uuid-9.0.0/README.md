# purescript-uuid

[![Build & Test](https://github.com/megamaddu/purescript-uuid/actions/workflows/node.js.yml/badge.svg)](https://github.com/megamaddu/purescript-uuid/actions/workflows/node.js.yml)

Wrapper for the `uuid` npm package.
This package is not installed automatically, as it comes from `npm`.
Install it with `npm install -S uuid`.
