# purescript-uuid

[![Build Status](https://travis-ci.org/spicydonuts/purescript-uuid.svg?branch=master)](https://travis-ci.org/spicydonuts/purescript-uuid)

Wrapper for the `uuid` and `uuid-validate` npm packages.
These packages are not installed automatically, as they come from `npm`.
Install them with `npm install -S uuid uuid-validate`.
