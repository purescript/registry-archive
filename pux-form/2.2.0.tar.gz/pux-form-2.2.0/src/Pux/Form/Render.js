exports.targetChecked = function(e) {
  return e.target.checked;
};

exports.targetSelectedIndex = function(e) {
  return e.target.selectedIndex;
};
