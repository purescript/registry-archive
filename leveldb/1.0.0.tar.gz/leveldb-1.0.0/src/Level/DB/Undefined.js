
export const isUndefined = value =>
  value === undefined;
