# purescript-eff-object

This package contains declarations and some basic functions to allow you to
give PureScript types to stateful or otherwise effectful JavaScript APIs like
XMLHttpRequest or WebSocket without writing a ton of error-prone and tedious
FFI code.
