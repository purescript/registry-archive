purescript-foreign
==================

[![Build Status](https://travis-ci.org/purescript/purescript-foreign.svg?branch=master)](https://travis-ci.org/purescript/purescript-foreign)

Library for dealing with foreign data (JSON and JavaScript objects).

- [Module documentation](docs/Module.md)
- [Examples](examples/)
