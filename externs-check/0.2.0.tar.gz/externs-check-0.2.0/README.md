# purescript-externs-check

This library gives you a way to reach into an externs file — a file created by
the PureScript compiler and placed alongside the CommonJS output — and check if
a given value exported by a given module is suitable for use as a program's
entry point.

Docs are [on Pursuit](https://pursuit.purescript.org/packages/purescript-externs-check/).
