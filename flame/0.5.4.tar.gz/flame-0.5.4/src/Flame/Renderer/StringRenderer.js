var toHtml = require('snabbdom-to-html');

exports.render_ = toHtml;