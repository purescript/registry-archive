exports.compareReference_ = function (a) {
      return function (b) {
            return a === b;
      };
};