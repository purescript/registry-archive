export function compareReference_(a) {
      return function (b) {
            return a === b;
      };
}