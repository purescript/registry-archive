exports.compareReference_ = function(a, b) {
      return a === b;
}