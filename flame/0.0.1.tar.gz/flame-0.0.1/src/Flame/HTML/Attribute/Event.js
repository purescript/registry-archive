exports.nodeValue = function (event) {
	return event.target.value;
}