"use strict";

var nacl_util = require('tweetnacl-util');

exports.encodeBase64 = nacl_util.encodeBase64;

exports.decodeBase64 = nacl_util.decodeBase64;
