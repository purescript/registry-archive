# purescript-base64

This library wraps dchest's fantastic [tweetnacl-util-js library](https://github.com/dchest/tweetnacl-util-js)
for encoding and decoding for base64, on both the browser & node.
