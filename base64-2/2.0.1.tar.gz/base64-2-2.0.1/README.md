# purescript-base64

[![Build Status](https://travis-ci.org/athanclark/purescript-base64.svg?branch=master)](https://travis-ci.org/athanclark/purescript-base64)
[![Pursuit](https://pursuit.purescript.org/packages/purescript-base64/badge)](https://pursuit.purescript.org/packages/purescript-base64)

This library wraps dchest's fantastic node-based [tweetnacl-util-js library](https://github.com/dchest/tweetnacl-util-js)
for encoding and decoding base64 strings, on both the browser & node.
