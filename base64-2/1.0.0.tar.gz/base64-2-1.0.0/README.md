# purescript-base64

This library wraps dchest's fantastic node-based [tweetnacl-util-js library](https://github.com/dchest/tweetnacl-util-js)
for encoding and decoding base64 strings, on both the browser & node.
