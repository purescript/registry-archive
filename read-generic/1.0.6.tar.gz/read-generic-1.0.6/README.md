<a href="https://pursuit.purescript.org/packages/purescript-read-generic">
  <img src="https://pursuit.purescript.org/packages/purescript-read-generic/badge"
       alt="purescript-read-generic on Pursuit">
  </img>
</a>

# purescript-read-generic
Provide Read and Parse typeclasses along with a way to derive them generically
