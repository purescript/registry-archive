# purescript-read-generic
Provide Read and Parse typeclasses along with a way to derive them generically
