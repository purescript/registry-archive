# purescript-incremental-dom

[Incremental Dom](https://github.com/google/incremental-dom) Bindings for PureScript.


```shell
bower install purescript-incremental-dom
```
