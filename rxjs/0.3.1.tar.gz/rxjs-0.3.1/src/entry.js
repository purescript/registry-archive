var myMain = require('./Main.purs');

myMain.main();
