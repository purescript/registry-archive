# purescript-rxjs
An un-opinionated PureScript wrapper for RxJS.


### Installation

```bash
npm install rxjs
bower install purescript-rxjs
```

### Documentation

- See the `docs` folder.
