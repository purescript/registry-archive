# purescript-halogen-day-picker

<a href="https://pursuit.purescript.org/packages/purescript-halogen-day-picker">
  <img src="https://pursuit.purescript.org/packages/purescript-halogen-day-picker/badge"
       alt="purescript-halogen-day-picker on Pursuit">
  </img>
</a>

A library that provides `DayPicker` and `DayPickerInput` components.

See [Demo](https://rnons.github.io/purescript-halogen-day-picker) for examples.

Inspired by [react-day-picker](https://github.com/gpbl/react-day-picker).
