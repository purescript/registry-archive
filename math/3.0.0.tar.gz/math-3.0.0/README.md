# purescript-math

[![Latest release](http://img.shields.io/github/release/purescript/purescript-math.svg)](https://github.com/purescript/purescript-math/releases)
[![Build status](https://github.com/purescript/purescript-math/workflows/CI/badge.svg?branch=master)](https://github.com/purescript/purescript-math/actions?query=workflow%3ACI+branch%3Amaster)
[![Pursuit](https://pursuit.purescript.org/packages/purescript-math/badge)](https://pursuit.purescript.org/packages/purescript-math)

Standard math functions from JavaScript.

## Installation

```
spago install math
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-math).
