# purescript-math

[![Latest release](http://img.shields.io/bower/v/purescript-math.svg)](https://github.com/purescript/purescript-math/releases)
[![Build Status](https://travis-ci.org/purescript/purescript-math.svg?branch=master)](https://travis-ci.org/purescript/purescript-math)

Standard math functions from JavaScript.

## Installation

```
bower install purescript-math
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-math).
