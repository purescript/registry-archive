# purescript-math

[![Build Status](https://travis-ci.org/purescript/purescript-math.svg?branch=master)](https://travis-ci.org/purescript/purescript-math)

Standard math functions from JavaScript.

## Installation

```
bower install purescript-math
```

## Module documentation

- [Math](docs/Math.md)
