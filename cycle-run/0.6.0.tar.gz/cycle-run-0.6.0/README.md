# purescript-cycle-run

A purescript interface for [Cycle.js](http://cycle.js.org/) using
[@cycle/xstream-run](https://github.com/cyclejs/cyclejs/tree/master/xstream-run).

Requires `purescript-xstream`

## Usage

See tests and examples
