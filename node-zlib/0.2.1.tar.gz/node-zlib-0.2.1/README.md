# purescript-node-zlib

PureScript bindings to the Node.js [zlib](https://nodejs.org/dist/latest-v18.x/docs/api/zlib.html) module.

