# purescript-tritium

# Usage

Tritium is a minimalistic and light-weight virtual DOM
(VDOM) _data representation_.  This library only provides
the basic types which get you started on building your very
own virtual DOM library.
