# N3.js for Purescript

A PureScript wrapper for the [N3.js](https://github.com/rdfjs/N3.js/) RDF library using the data model of [purescript-rdf](https://pursuit.purescript.org/packages/purescript-rdf/).

## Acknowledgments

This work has been partially funded by the German Federal Ministry of Education and Research through the MOSAIK project (grant no. 01IS18070A) and the MANDAT project (grant no. 16DTM107A).

