# purescript-quasar

[![Latest release](http://img.shields.io/github/release/slamdata/purescript-quasar.svg)](https://github.com/slamdata/purescript-quasar/releases)
[![Build Status](https://travis-ci.org/slamdata/purescript-quasar.svg?branch=master)](https://travis-ci.org/slamdata/purescript-quasar)

[Quasar](https://github.com/quasar-analytics/quasar) API library.

## Installation

``` purescript
bower install purescript-quasar
```

## Module documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-quasar).
