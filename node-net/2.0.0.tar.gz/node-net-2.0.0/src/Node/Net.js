"use strict";

var net = require("net");

exports.isIP = net.isIP;

exports.isIPv4 = net.isIPv4;

exports.isIPv6 = net.isIPv6;
