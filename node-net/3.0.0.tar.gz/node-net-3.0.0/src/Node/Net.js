import net from "net";
export const isIP = net.isIP;
export const isIPv4 = net.isIPv4;
export const isIPv6 = net.isIPv6;
