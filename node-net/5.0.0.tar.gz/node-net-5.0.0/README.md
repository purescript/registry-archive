# purescript-node-net

[![Latest release](http://img.shields.io/github/release/purescript-node/purescript-node-net.svg)](https://github.com/purescript-node/purescript-node-net/releases)
[![Build status](https://github.com/purescript-node/purescript-node-net/workflows/CI/badge.svg?branch=master)](https://github.com/purescript-node/purescript-node-net/actions?query=workflow%3ACI+branch%3Amaster)
[![Pursuit](https://pursuit.purescript.org/packages/purescript-node-net/badge)](https://pursuit.purescript.org/packages/purescript-node-net)

A wrapper for Node's net API.

## Installation

```
spago install node-net
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-node-net).
