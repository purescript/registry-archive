export { isIP as isIPImpl, isIPv4, isIPv6 } from "net";
