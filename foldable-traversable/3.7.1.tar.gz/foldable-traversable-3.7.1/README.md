# purescript-foldable-traversable

[![Latest release](http://img.shields.io/github/release/purescript/purescript-foldable-traversable.svg)](https://github.com/purescript/purescript-foldable-traversable/releases)
[![Build status](https://travis-ci.org/purescript/purescript-foldable-traversable.svg?branch=master)](https://travis-ci.org/purescript/purescript-foldable-traversable)

Classes for foldable and traversable data structures.

## Installation

```
bower install purescript-foldable-traversable
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-foldable-traversable).
