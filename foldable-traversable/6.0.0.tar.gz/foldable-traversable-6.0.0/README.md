# purescript-foldable-traversable

[![Latest release](http://img.shields.io/github/release/purescript/purescript-foldable-traversable.svg)](https://github.com/purescript/purescript-foldable-traversable/releases)
[![Build status](https://github.com/purescript/purescript-foldable-traversable/workflows/CI/badge.svg?branch=master)](https://github.com/purescript/purescript-foldable-traversable/actions?query=workflow%3ACI+branch%3Amaster)
[![Pursuit](https://pursuit.purescript.org/packages/purescript-foldable-traversable/badge)](https://pursuit.purescript.org/packages/purescript-foldable-traversable)

Classes for foldable and traversable data structures.

## Installation

```
spago install foldable-traversable
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-foldable-traversable).
