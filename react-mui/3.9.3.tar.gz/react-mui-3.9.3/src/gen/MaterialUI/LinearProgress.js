exports.classLinearProgress =  require('@material-ui/core/LinearProgress').default
