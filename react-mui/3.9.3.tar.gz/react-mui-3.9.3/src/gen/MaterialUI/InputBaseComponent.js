exports.classInputBaseComponent =  require('@material-ui/core/InputBaseComponent').default
