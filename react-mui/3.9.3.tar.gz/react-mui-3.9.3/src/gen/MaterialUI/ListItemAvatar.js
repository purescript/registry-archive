exports.classListItemAvatar =  require('@material-ui/core/ListItemAvatar').default
