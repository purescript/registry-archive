exports.classTabScrollButton =  require('@material-ui/core/TabScrollButton').default
