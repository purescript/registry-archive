exports.classTableFooter =  require('@material-ui/core/TableFooter').default
