exports.classAvatar =  require('@material-ui/core/Avatar').default
