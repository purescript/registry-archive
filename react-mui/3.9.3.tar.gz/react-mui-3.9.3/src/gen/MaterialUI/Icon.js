exports.classIcon =  require('@material-ui/core/Icon').default
