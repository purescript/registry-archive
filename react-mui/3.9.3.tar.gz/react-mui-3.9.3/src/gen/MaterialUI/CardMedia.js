exports.classCardMedia =  require('@material-ui/core/CardMedia').default
