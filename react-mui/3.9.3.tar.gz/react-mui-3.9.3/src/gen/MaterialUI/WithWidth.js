exports.classWithWidth =  require('@material-ui/core/WithWidth').default
