exports.classSlide =  require('@material-ui/core/Slide').default
