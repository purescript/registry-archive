exports.classChip =  require('@material-ui/core/Chip').default
