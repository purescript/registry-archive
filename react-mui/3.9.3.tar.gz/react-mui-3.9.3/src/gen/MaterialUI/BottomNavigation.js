exports.classBottomNavigation =  require('@material-ui/core/BottomNavigation').default
