exports.classBottomNavigationAction =  require('@material-ui/core/BottomNavigationAction').default
