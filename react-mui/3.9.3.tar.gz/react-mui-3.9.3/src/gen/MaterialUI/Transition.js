exports.classTransition =  require('@material-ui/core/Transition').default
