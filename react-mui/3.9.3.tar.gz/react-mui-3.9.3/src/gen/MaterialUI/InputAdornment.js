exports.classInputAdornment =  require('@material-ui/core/InputAdornment').default
