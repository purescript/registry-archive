exports.classTabs =  require('@material-ui/core/Tabs').default
