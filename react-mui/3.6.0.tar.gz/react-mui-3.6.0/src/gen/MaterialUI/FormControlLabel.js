exports.classFormControlLabel =  require('@material-ui/core/FormControlLabel').default
