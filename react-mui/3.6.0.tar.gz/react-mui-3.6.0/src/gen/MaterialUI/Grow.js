exports.classGrow =  require('@material-ui/core/Grow').default
