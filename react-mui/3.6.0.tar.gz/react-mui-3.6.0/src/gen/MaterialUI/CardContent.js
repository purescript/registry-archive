exports.classCardContent =  require('@material-ui/core/CardContent').default
