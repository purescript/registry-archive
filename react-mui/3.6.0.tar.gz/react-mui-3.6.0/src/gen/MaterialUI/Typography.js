exports.classTypography =  require('@material-ui/core/Typography').default
