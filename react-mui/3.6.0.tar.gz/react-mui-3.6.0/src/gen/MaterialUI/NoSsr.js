exports.classNoSsr =  require('@material-ui/core/NoSsr').default
