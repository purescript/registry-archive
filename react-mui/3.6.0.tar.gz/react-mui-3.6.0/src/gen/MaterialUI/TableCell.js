exports.classTableCell =  require('@material-ui/core/TableCell').default
