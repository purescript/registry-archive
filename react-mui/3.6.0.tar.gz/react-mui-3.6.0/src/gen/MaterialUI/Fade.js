exports.classFade =  require('@material-ui/core/Fade').default
