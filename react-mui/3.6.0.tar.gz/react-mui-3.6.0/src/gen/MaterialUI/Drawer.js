exports.classDrawer =  require('@material-ui/core/Drawer').default
