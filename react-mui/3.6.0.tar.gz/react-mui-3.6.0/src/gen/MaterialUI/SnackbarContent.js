exports.classSnackbarContent =  require('@material-ui/core/SnackbarContent').default
