exports.classCheckbox =  require('@material-ui/core/Checkbox').default
