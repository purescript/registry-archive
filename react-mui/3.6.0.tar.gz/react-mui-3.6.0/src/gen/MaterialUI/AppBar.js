exports.classAppBar =  require('@material-ui/core/AppBar').default
