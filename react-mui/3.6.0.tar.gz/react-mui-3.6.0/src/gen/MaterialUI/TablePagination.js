exports.classTablePagination =  require('@material-ui/core/TablePagination').default
