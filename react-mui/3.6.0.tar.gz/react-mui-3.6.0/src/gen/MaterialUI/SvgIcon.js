exports.classSvgIcon =  require('@material-ui/core/SvgIcon').default
