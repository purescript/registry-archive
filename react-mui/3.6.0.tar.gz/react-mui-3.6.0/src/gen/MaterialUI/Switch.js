exports.classSwitch =  require('@material-ui/core/Switch').default
