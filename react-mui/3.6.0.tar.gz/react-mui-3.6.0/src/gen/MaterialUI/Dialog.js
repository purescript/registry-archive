exports.classDialog =  require('@material-ui/core/Dialog').default
