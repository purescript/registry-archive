exports.classHidden =  require('@material-ui/core/Hidden').default
