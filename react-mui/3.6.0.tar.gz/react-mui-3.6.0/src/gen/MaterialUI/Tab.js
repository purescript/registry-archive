exports.classTab =  require('@material-ui/core/Tab').default
