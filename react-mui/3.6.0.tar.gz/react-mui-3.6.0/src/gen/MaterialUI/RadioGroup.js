exports.classRadioGroup =  require('@material-ui/core/RadioGroup').default
