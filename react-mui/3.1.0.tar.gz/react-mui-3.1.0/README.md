# purescript-react-mui

[![Latest release](https://pursuit.purescript.org/packages/purescript-react-mui/badge)](https://pursuit.purescript.org/packages/purescript-react-mui)
[![Travis Build](https://travis-ci.org/doolse/purescript-react-mui.svg?branch=master)](https://travis-ci.org/doolse/purescript-react-mui)

Purescript bindings for [Material UI](https://material-ui.com/)

The component functions are auto-generated from the Typescript bindings, so it should be easy to keep up with the releases.

These bindings are based on [purescript-tscompat](http://github.com/doolse/purescript-tscompat).