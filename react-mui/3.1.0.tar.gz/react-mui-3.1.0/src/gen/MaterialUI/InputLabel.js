exports.classInputLabel =  require('@material-ui/core/InputLabel').default
