exports.classExpansionPanel =  require('@material-ui/core/ExpansionPanel').default
