exports.classPaper =  require('@material-ui/core/Paper').default
