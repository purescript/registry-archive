exports.classMuiThemeProvider =  require('@material-ui/core/MuiThemeProvider').default
