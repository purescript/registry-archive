exports.classExpansionPanelActions =  require('@material-ui/core/ExpansionPanelActions').default
