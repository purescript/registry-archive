exports.classCircularProgress =  require('@material-ui/core/CircularProgress').default
