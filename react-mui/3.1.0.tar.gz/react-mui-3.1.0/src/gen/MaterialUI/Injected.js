exports.classInjected =  require('@material-ui/core/Injected').default
