exports.classDialogTitle =  require('@material-ui/core/DialogTitle').default
