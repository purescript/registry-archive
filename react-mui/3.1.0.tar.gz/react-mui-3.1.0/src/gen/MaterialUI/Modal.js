exports.classModal =  require('@material-ui/core/Modal').default
