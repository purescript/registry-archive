exports.classSnackbar =  require('@material-ui/core/Snackbar').default
