exports.classDialogContentText =  require('@material-ui/core/DialogContentText').default
