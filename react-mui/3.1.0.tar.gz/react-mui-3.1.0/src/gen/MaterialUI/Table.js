exports.classTable =  require('@material-ui/core/Table').default
