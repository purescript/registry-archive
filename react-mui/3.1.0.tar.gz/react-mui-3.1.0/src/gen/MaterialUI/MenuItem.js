exports.classMenuItem =  require('@material-ui/core/MenuItem').default
