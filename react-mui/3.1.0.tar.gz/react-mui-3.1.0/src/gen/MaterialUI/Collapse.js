exports.classCollapse =  require('@material-ui/core/Collapse').default
