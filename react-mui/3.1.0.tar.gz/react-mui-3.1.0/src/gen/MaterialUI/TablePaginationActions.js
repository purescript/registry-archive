exports.classTablePaginationActions =  require('@material-ui/core/TablePaginationActions').default
