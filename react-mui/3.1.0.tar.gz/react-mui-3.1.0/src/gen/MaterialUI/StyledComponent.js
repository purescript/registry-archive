exports.classStyledComponent =  require('@material-ui/core/StyledComponent').default
