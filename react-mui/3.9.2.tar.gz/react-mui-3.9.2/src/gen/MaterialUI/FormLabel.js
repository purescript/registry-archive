exports.classFormLabel =  require('@material-ui/core/FormLabel').default
