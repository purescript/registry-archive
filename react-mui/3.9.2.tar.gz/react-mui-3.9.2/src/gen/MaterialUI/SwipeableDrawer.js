exports.classSwipeableDrawer =  require('@material-ui/core/SwipeableDrawer').default
