exports.classExpansionPanelSummary =  require('@material-ui/core/ExpansionPanelSummary').default
