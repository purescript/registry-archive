exports.classTabIndicator =  require('@material-ui/core/TabIndicator').default
