exports.classFab =  require('@material-ui/core/Fab').default
