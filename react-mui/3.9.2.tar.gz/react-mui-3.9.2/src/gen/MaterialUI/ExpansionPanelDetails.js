exports.classExpansionPanelDetails =  require('@material-ui/core/ExpansionPanelDetails').default
