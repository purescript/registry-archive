exports.classBadge =  require('@material-ui/core/Badge').default
