exports.classMergeWithListContext =  require('@material-ui/core/MergeWithListContext').default
