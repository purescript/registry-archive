exports.classThemedComponent =  require('@material-ui/core/ThemedComponent').default
