exports.classDialogContent =  require('@material-ui/core/DialogContent').default
