exports.classToolbar =  require('@material-ui/core/Toolbar').default
