# purescript-free-group

[Free groups](https://en.wikipedia.org/wiki/Free_group) in Purescript!