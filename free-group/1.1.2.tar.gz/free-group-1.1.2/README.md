# purescript-free-group

[Free groups](https://en.wikipedia.org/wiki/Free_group) in Purescript!

Inspired by [this podcast episode](https://www.magicreadalong.com/episode/39).

Module documentation is [published on Pursuit](https://pursuit.purescript.org/packages/purescript-free-group/).