# purescript-free-group

NOTE: This library is deprecated, as it has been folded into [purescript-group](https://pursuit.purescript.org/packages/purescript-group/3.2.0). For free groups in Purescript, use that library.

[Free groups](https://en.wikipedia.org/wiki/Free_group) in Purescript, inspired by [this podcast episode](https://www.magicreadalong.com/episode/39).