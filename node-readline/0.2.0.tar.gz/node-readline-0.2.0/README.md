# purescript-node-readline

A low-level PureScript interface to the Node `readline` API.

## Installation

```
bower install purescript-readline
```

## Module documentation

- [Node.ReadLine](docs/Node/ReadLine.md)
