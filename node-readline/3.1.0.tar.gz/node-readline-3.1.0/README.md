# purescript-node-readline

[![Latest release](http://img.shields.io/github/release/purescript-node/purescript-node-readline.svg)](https://github.com/purescript-node/purescript-node-readline/releases)
[![Build Status](https://travis-ci.org/purescript-node/purescript-node-readline.svg?branch=master)](https://travis-ci.org/purescript-node/purescript-node-readline)

A low-level PureScript interface to the Node `readline` API.

## Installation

```
bower install purescript-node-readline
```

Module documentation can be found on [Pursuit](https://pursuit.purescript.org/packages/purescript-node-readline)
