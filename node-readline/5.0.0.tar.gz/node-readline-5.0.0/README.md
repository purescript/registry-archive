# purescript-node-readline

[![Latest release](http://img.shields.io/github/release/purescript-node/purescript-node-readline.svg)](https://github.com/purescript-node/purescript-node-readline/releases)
[![Build status](https://github.com/purescript-node/purescript-node-readline/workflows/CI/badge.svg?branch=master)](https://github.com/purescript-node/purescript-node-readline/actions?query=workflow%3ACI+branch%3Amaster)
[![Pursuit](https://pursuit.purescript.org/packages/purescript-node-readline/badge)](https://pursuit.purescript.org/packages/purescript-node-readline)

A low-level PureScript interface to the Node `readline` API.

## Installation

```
spago install node-readline
```

Module documentation can be found on [Pursuit](https://pursuit.purescript.org/packages/purescript-node-readline)
