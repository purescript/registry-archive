# purescript-node-readline

A low-level PureScript interface to the Node `readline` API.

## Installation

```
bower install purescript-node-readline
```

Module documentation can be found on [Pursuit](https://pursuit.purescript.org/packages/purescript-node-readline)
