# DEPRECATED

The library is no longer maintained under this repository, it has been merged into to [`purescript-ordered-collections`](https://github.com/purescript/purescript-ordered-collections).

[The previous releases](https://github.com/purescript-deprecated/purescript-sets/releases) will continue to work for older libraries that still depend on them.
