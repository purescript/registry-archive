# purescript-sets

Purely-functional set data structure

## Installation

```
bower install purescript-sets
```

## Module documentation

- [Data.Set](docs/Data/Set.md)
