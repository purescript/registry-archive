# purescript-sets

[![Latest release](http://img.shields.io/bower/v/purescript-sets.svg)](https://github.com/purescript/purescript-sets/releases)
[![Build Status](https://travis-ci.org/purescript/purescript-sets.svg?branch=master)](https://travis-ci.org/purescript/purescript-sets)
[![Dependency Status](https://www.versioneye.com/user/projects/55848ca636386100150003f8/badge.svg?style=flat)](https://www.versioneye.com/user/projects/55848ca636386100150003f8)

Purely-functional set data structure

## Installation

```
bower install purescript-sets
```

## Module documentation

- [Data.Set](docs/Data/Set.md)
