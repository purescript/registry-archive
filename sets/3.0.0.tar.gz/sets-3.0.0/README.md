# purescript-sets

[![Latest release](http://img.shields.io/github/release/purescript/purescript-sets.svg)](https://github.com/purescript/purescript-sets/releases)
[![Build status](https://travis-ci.org/purescript/purescript-sets.svg?branch=master)](https://travis-ci.org/purescript/purescript-sets)
[![Dependency status](https://img.shields.io/librariesio/github/purescript/purescript-sets.svg)](https://libraries.io/github/purescript/purescript-sets)

Purely-functional set data structure

## Installation

```
bower install purescript-sets
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-sets).
