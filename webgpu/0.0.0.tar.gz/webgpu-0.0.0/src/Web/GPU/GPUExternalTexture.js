export const expiredImpl = texture => texture.expired;
