export const red = window.GPUColorWrite ? window.GPUColorWrite.RED : 0x0000;
export const green = window.GPUColorWrite ? window.GPUColorWrite.GREEN : 0x0000;
export const blue = window.GPUColorWrite ? window.GPUColorWrite.BLUE : 0x0000;
export const alpha = window.GPUColorWrite ? window.GPUColorWrite.ALPHA : 0x0000;
export const all = window.GPUColorWrite ? window.GPUColorWrite.ALL : 0x0000;
