export const read = window.GPUMapMode ? window.GPUMapMode.READ : 0x0000;
export const write = window.GPUMapMode ? window.GPUMapMode.WRITE : 0x0000;
