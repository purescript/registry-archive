export const unsafeGetBindGroupLayoutImpl = (pipeline, index) =>
  pipeline.getBindGroupLayout(index);
