export const vertex = window.GPUShaderStage
  ? window.GPUShaderStage.VERTEX
  : 0x0000;
export const fragment = window.GPUShaderStage
  ? window.GPUShaderStage.FRAGMENT
  : 0x0000;
export const compute = window.GPUShaderStage
  ? window.GPUShaderStage.COMPUTE
  : 0x0000;
