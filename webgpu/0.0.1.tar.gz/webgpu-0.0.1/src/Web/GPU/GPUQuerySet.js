export const destroyImpl = querySet => querySet.destroy();
export const typeImpl = querySet => querySet.type;
export const countImpl = querySet => querySet.count;
