export const requiredAndOptionalImpl = (required, optional) => ({
  ...required,
  ...optional,
});
