export const compilationInfoImpl = shaderModule =>
  shaderModule.compilationInfo();
