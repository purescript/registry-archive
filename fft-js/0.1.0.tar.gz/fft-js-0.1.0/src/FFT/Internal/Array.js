"use strict"

export const _new = n => () => new Array(n)
