# purescript-codec

[![Latest release](http://img.shields.io/github/release/garyb/purescript-codec.svg)](https://github.com/garyb/purescript-codec/releases)
![Build Status](https://github.com/garyb/purescript-codec/actions/workflows/ci.yml/badge.svg)

General purpose bi-directional codecs.

## Installation

```
bower install purescript-codec
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-codec).
