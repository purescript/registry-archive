# purescript-codec

[![Latest release](http://img.shields.io/github/release/garyb/purescript-codec.svg)](https://github.com/slamdata/purescript-codec/releases)
[![Build Status](https://travis-ci.org/garyb/purescript-codec.svg?branch=master)](https://travis-ci.org/garyb/purescript-codec)

General purpose bi-directional codecs.

## Installation

```
bower install purescript-codec
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-codec).
