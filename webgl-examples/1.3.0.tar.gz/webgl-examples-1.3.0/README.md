[![Build Status](https://travis-ci.org/jutaro/purescript-webgl-examples.svg?branch=master)](https://travis-ci.org/jutaro/purescript-webgl-examples)

Examples for [purescript-webgl](https://github.com/jutaro/purescript-webgl)

The first n lessons form the page [learningwebgl](http://learningwebgl.com/blog/) ported to
purescript.

Build with:
~~~
npm install
bower update
./run.sh
~~~

Then open index#.html in browser.

For later examples you need to start chrome with --allow-file-access-from-files
to be able to load local files for textures.
