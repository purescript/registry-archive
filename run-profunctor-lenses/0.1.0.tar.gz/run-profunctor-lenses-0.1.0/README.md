# purescript-run-profunctor-lenses
Implementation of the stateful operators from purescript-profunctor-lenses for the State effect in Run
