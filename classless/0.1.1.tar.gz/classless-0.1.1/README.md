# purescript-classless

This library includes utils to create API's for things that are typically provided by type classes.

The best way to get started is to check out one of the libraries that uses this API. The `classless-arbitrary` package contains a tutorial which can be applied to the other packages, too.

- [classless-arbitrary](https://pursuit.purescript.org/packages/purescript-classless-arbitrary)

- [classless-encode-json](https://pursuit.purescript.org/packages/purescript-classless-encode-json)

- [classless-decode-json](https://pursuit.purescript.org/packages/purescript-classless-decode-json)
