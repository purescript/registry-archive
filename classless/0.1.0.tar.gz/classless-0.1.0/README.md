# purescript-classless

This library includes utils to create API's for things that are typically provided by typeclasses.

The best way to get started is to check out one of the libraries that uses this API. 

- [classless-arbitrary](https://github.com/thought2/purescript-classless-arbitrary)

- [classless-encode-json](https://github.com/thought2/purescript-classless-encode-json)

- [classless-decode-json](https://github.com/thought2/purescript-classless-decode-json)
