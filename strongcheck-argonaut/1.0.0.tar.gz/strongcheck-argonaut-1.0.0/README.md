# purescript-strongcheck-argonaut

[![Latest release](http://img.shields.io/github/release/purescript-contrib/purescript-strongcheck-argonaut.svg)](https://github.com/purescript-contrib/purescript-strongcheck-argonaut/releases)
[![Build status](https://travis-ci.org/purescript-contrib/purescript-strongcheck-argonaut.svg?branch=master)](https://travis-ci.org/purescript-contrib/purescript-strongcheck-argonaut)
[![Maintainer: slamdata](https://img.shields.io/badge/maintainer-slamdata-lightgrey.svg)](http://github.com/slamdata)

`Arbitrary` instances for `purescript-argonaut`, using `purescript-strongcheck`.

## Installation

```
bower install purescript-strongcheck-argonaut
```

## Documentation

- Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-strongcheck-argonaut).
