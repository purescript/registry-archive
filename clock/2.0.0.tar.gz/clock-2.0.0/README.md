# purescript-clock

High-resolution clock for PureScript.


## Installation

```
	bower install purescript-clock
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-clock).

