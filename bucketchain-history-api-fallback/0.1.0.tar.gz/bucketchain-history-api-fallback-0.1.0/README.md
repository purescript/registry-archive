# purescript-bucketchain-history-api-fallback

[![Latest release](http://img.shields.io/github/release/Bucketchain/purescript-bucketchain-history-api-fallback.svg)](https://github.com/Bucketchain/purescript-bucketchain-history-api-fallback/releases)

A History API fallback middleware of [Bucketchain](https://github.com/Bucketchain/purescript-bucketchain).

## Installation

```
bower install purescript-bucketchain-history-api-fallback
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-bucketchain-history-api-fallback).

## LICENSE

MIT
