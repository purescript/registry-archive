# purescript-xstream

A Purescript interface to [xstream](https://github.com/staltz/xstream).

WIP!!!

## Usage

See [tests](test/Main.purs) for usage.
