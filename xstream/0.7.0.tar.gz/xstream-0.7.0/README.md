# purescript-xstream

[![Build Status](https://travis-ci.org/justinwoo/purescript-xstream.svg?branch=master)](https://travis-ci.org/justinwoo/purescript-xstream)

A Purescript interface to [xstream](https://github.com/staltz/xstream).

API Docs available on [Pursuit](https://pursuit.purescript.org/packages/purescript-xstream/)

## Usage

See the [API Docs](https://pursuit.purescript.org/packages/purescript-xstream/) or the [tests](test/Main.purs) for usage.
