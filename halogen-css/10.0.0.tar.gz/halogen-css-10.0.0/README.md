# purescript-halogen-css

[![Latest release](http://img.shields.io/github/release/purescript-halogen/purescript-halogen-css.svg)](https://github.com/purescript-halogen/purescript-halogen-css/releases)
![Build Status](https://github.com/purescript-halogen/purescript-halogen-css/actions/workflows/ci.yml/badge.svg)

An adapter between the `purescript-halogen` and `purescript-css` libraries.

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-halogen-css).
