# purescript-halogen-css

[![Latest release](http://img.shields.io/github/release/slamdata/purescript-halogen-css.svg)](https://github.com/slamdata/purescript-halogen-css/releases)
[![Build status](https://travis-ci.org/slamdata/purescript-halogen-css.svg?branch=master)](https://travis-ci.org/slamdata/purescript-halogen-css)

An adapter between the `purescript-halogen` and `purescript-css` libraries.

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-halogen-css).
