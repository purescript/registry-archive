# purescript-halogen-css

[![Latest release](http://img.shields.io/bower/v/purescript-halogen-css.svg)](https://github.com/slamdata/purescript-halogen-css/releases)
[![Build Status](https://travis-ci.org/slamdata/purescript-halogen-css.svg?branch=master)](https://travis-ci.org/slamdata/purescript-halogen-css)
[![Dependency Status](https://www.versioneye.com/user/projects/56796dd0a7c90e002c00006d/badge.svg?style=flat)](https://www.versioneye.com/user/projects/56796dd0a7c90e002c00006d)

An adapter between the `purescript-halogen` and `purescript-css` libraries.

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-halogen-css).
