# purescript-node-websocket

Bindings to node's [`websocket`](https://github.com/theturtle32/WebSocket-Node) library.

# Installation

`bower i purescript-node-websocket`
