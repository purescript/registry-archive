# purescript-gametree

Algorithms to search for optimal moves in two-player zero-sum games.


Inspired by the Haskell package [game-tree](https://hackage.haskell.org/package/game-tree).
