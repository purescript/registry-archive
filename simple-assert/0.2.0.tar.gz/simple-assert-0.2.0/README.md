purescript-simple-assert
===
simple asserting library like [HUnit](https://hackage.haskell.org/package/HUnit) for purescript.

* [Module documentation](./docs/Test/Assert/Simple.md)
* [example](examples/Main.purs)
