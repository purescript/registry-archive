purescript-simple-assert
===
[![Build Status](https://travis-ci.org/philopon/purescript-simple-assert.svg?branch=master)](https://travis-ci.org/philopon/purescript-simple-assert)
[![Bower version](https://badge.fury.io/bo/purescript-simple-assert.svg)](http://badge.fury.io/bo/purescript-simple-assert)
[![devDependency Status](https://david-dm.org/philopon/purescript-simple-assert/dev-status.svg)](https://david-dm.org/philopon/purescript-simple-assert#info=devDependencies)

simple asserting library like [HUnit](https://hackage.haskell.org/package/HUnit) for purescript.

* [Module documentation](./docs.md)
* [example](examples/Main.purs)
