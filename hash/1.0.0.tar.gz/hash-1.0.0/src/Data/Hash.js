'use strict';

// module Data.Hash

exports.numberToString = function(a) {
    return '' + a;
};
