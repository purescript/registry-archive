# purescript-hash

This package provides a module with a type class for hashable values, and a
bunch of instances, as well as a few utility functions.

NOTE: the hash functions provided by this module are ***not*** cryptographically
secure.

## Usage

See [purescript-hash on Pursuit][1] for documentation.

[1]: https://pursuit.purescript.org/packages/purescript-hash
