# purescript-grain-router

[![Latest release](http://img.shields.io/github/release/purescript-grain/purescript-grain-router.svg)](https://github.com/purescript-grain/purescript-grain-router/releases)

Router for [purescript-grain](https://github.com/purescript-grain/purescript-grain).

## Installation

### Spago

```
$ spago install grain-router
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-grain-router).

## LICENSE

MIT
