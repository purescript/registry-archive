# purescript-react-stylesheet

Utilities to use [Purescript Stylesheet](https://github.com/danieljharvey/purescript-stylesheet) with [Purescript React](https://github.com/purescript-contrib/purescript-react).

Purescript Stylesheet is a Virtual Stylesheet that allows you to dynamically add styles to a CSS Stylesheet. This library provides components that provide and consume a Virtual Stylesheet via React Context.

Currently in the experimental stage - demonstration app in progress.
