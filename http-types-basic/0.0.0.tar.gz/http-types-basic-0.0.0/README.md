# purescript-http-types

A purescript implementation of [`http-types`](https://github.com/meeshkan/http-types).