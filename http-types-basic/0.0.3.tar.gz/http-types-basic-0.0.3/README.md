# purescript-http-types-basic

A purescript implementation of [`http-types`](https://github.com/meeshkan/http-types).
