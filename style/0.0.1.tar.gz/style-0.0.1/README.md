# purescript-style

## Usage

```purescript
width (42 # px)
```
