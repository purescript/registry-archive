"use strict";

exports.isUndefined = function(val) {
    return val == undefined;
}

exports.undefinedVal = undefined;
