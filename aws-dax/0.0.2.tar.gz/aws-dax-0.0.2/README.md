# purescript-aws-dax

[![Latest Release](https://pursuit.purescript.org/packages/purescript-aws-dax/badge)](https://pursuit.purescript.org/packages/purescript-aws-dax)
[![Build Status](https://app.wercker.com/status/5909b9e96d1080804b17a28f72f87b6b/s/master)](https://app.wercker.com/project/byKey/5909b9e96d1080804b17a28f72f87b6b)

This module has been generated with [purescript-aws-sdk/gen](https://github.com/purescript-aws-sdk/gen) from the [AWS SDK JS](https://github.com/aws/aws-sdk-js).

## Getting started

```sh
bower install purescript-aws-dax
npm install aws-sdk # bower package seems broken :(
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-aws-dax).
