# purescript-generics-rep

[![Latest release](http://img.shields.io/github/release/purescript/purescript-generics-rep.svg)](https://github.com/purescript/purescript-generics-rep/releases)
[![Build status](https://travis-ci.org/purescript/purescript-generics-rep.svg?branch=master)](https://travis-ci.org/purescript/purescript-generics-rep)

Generic programming using an approach inspired by GHC.Generics.

This library requires version 0.10 of the PureScript compiler, or later.

## Installation

```
bower install purescript-generics-rep
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-generics-rep).
