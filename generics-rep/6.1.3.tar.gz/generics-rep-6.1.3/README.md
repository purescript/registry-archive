# DEPRECATED

The library is no longer maintained under this repository as of the PureScript 0.14 compiler release. Relevant functionality has been moved into other repositories:

- Most code has been moved to [`prelude`](https://github.com/purescript/purescript-prelude)
- Enum-related code has been moved to [`enums`](https://github.com/purescript/purescript-enums)
- The `Maybe` type's `Generic` instance has been moved to [`maybe`](https://github.com/purescript/purescript-maybe)
- The `Either` type's `Generic` instance has been moved to [`either`](https://github.com/purescript/purescript-either)
- The `Tuple` type's `Generic` instance has been moved to [`tuple`](https://github.com/purescript/purescript-either)

[Previous releases](https://github.com/purescript-deprecated/purescript-generics-rep/releases) will continue to work for older libraries which depend on them.
