# purescript-generics-rep

Generic programming using an approach inspired by GHC.Generics.

This library requires version 0.10 of the PureScript compiler, or later.
