# Purescript-Record-Extra
[![Build Status](https://travis-ci.org/justinwoo/purescript-record-extra.svg?branch=master)](https://travis-ci.org/justinwoo/purescript-record-extra)

Examples and extra functions for working with records in PureScript.

These functions may be removed as they are merged into core libraries in 0.12 and beyond.
