# purescript-invariant

[![Build Status](https://travis-ci.org/purescript/purescript-invariant.svg?branch=master)](https://travis-ci.org/purescript/purescript-invariant)

Invariant functors.

## Installation

```
bower install purescript-invariant
```

## Module documentation

- [Data.Functor.Invariant](docs/Data.Functor.Invariant.md)
