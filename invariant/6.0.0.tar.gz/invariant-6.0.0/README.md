# purescript-invariant

[![Latest release](http://img.shields.io/github/release/purescript/purescript-invariant.svg)](https://github.com/purescript/purescript-invariant/releases)
[![Build status](https://github.com/purescript/purescript-invariant/workflows/CI/badge.svg?branch=master)](https://github.com/purescript/purescript-invariant/actions?query=workflow%3ACI+branch%3Amaster)
[![Pursuit](https://pursuit.purescript.org/packages/purescript-invariant/badge)](https://pursuit.purescript.org/packages/purescript-invariant)

Invariant functors.

## Installation

```
spago install invariant
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-invariant).
