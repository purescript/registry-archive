# purescript-invariant

[![Latest release](http://img.shields.io/github/release/purescript/purescript-invariant.svg)](https://github.com/purescript/purescript-invariant/releases)
[![Build status](https://travis-ci.org/purescript/purescript-invariant.svg?branch=master)](https://travis-ci.org/purescript/purescript-invariant)

Invariant functors.

## Installation

```
bower install purescript-invariant
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-invariant).
