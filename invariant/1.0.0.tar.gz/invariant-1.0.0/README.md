# purescript-invariant

[![Latest release](http://img.shields.io/bower/v/purescript-invariant.svg)](https://github.com/purescript/purescript-invariant/releases)
[![Build Status](https://travis-ci.org/purescript/purescript-invariant.svg?branch=master)](https://travis-ci.org/purescript/purescript-invariant)
[![Dependency Status](https://www.versioneye.com/user/projects/55848cc4363861001b0001af/badge.svg?style=flat)](https://www.versioneye.com/user/projects/55848cc4363861001b0001af)

Invariant functors.

## Installation

```
bower install purescript-invariant
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-invariant).
