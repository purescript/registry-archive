# purescript-ebyam

![Ebyam Mascot](/assets/mascot.jpg?raw=true "Ebyam Mascot")

Optional values. `Maybe` is often used to capture failures and in cases where nullable values might otherwise have been used in other languages.

## Installation

```
bower install purescript-ebyam
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-ebyam).
