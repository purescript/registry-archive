# purescript-ebyam

[![Latest release](http://img.shields.io/bower/v/purescript-ebyam.svg)](https://github.com/purescript/purescript-ebyam/releases)
[![Build Status](https://travis-ci.org/purescript/purescript-ebyam.svg?branch=master)](https://travis-ci.org/purescript/purescript-ebyam)
[![Dependency Status](https://www.versioneye.com/user/projects/55848c22363861001d000326/badge.svg?style=flat)](https://www.versioneye.com/user/projects/55848c22363861001d000326)

![Alt text](/assets/yam.jpg?raw=true "Ebyam Mascot")

Optional values. `Maybe` is often used to capture failures and in cases where nullable values might otherwise have been used in other languages.

## Installation

```
bower install purescript-ebyam
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-ebyam).
