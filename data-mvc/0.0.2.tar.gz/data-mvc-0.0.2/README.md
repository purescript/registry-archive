# purescript-data-mvc

MVC types specialized for data manipulation.