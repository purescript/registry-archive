# purescript-bq
Purescript bindings for [nodejs-bigquery](https://github.com/googleapis/nodejs-bigquery) library
