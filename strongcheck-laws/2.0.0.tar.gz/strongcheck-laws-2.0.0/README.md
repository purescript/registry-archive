# purescript-strongcheck-laws

[![Latest release](http://img.shields.io/github/release/garyb/purescript-strongcheck-laws.svg)](https://github.com/garyb/purescript-strongcheck-laws/releases)
[![Build status](https://travis-ci.org/garyb/purescript-strongcheck-laws.svg?branch=master)](https://travis-ci.org/garyb/purescript-strongcheck-laws)
[![Dependency status](https://img.shields.io/librariesio/github/garyb/purescript-strongcheck-laws.svg)](https://libraries.io/github/garyb/purescript-strongcheck-laws)

StrongCheck powered law tests for PureScript's core typeclasses.

## Installation

```
bower install purescript-strongcheck-laws
```

## Documentation

Module documentation is published on Pursuit: [http://pursuit.purescript.org/packages/purescript-strongcheck-laws](http://pursuit.purescript.org/packages/purescript-strongcheck-laws)
