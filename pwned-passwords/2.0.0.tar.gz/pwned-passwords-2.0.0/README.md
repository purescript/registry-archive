# purescript-pwned-passwords

[![Pursuit](https://pursuit.purescript.org/packages/purescript-pwned-passwords/badge)](https://pursuit.purescript.org/packages/purescript-pwned-passwords)