exports.sha1 = message => require('crypto-js/sha1')(message).toString();
