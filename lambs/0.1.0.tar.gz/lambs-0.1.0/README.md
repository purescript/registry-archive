# purescript-lambs

I tend to forget how to:
* `pulp build`
* `pulp psci`
* `pulp browserify --optimise --standalone lambs --to lambs.js`
