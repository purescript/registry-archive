# purescript-lambs

[Pursuuiit.](https://pursuit.purescript.org/packages/purescript-lambs)

Is like, lib for doing some lambda calculus things. It's roughly equivalent to
what I happen to need for putting a lambda calculus evaluator in a text editor.
Does normal order stuff.
