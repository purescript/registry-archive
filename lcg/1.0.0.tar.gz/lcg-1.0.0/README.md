# purescript-lcg

[![Latest release](http://img.shields.io/github/release/purescript/purescript-lcg.svg)](https://github.com/purescript/purescript-lcg/releases)
[![Build status](https://travis-ci.org/purescript/purescript-lcg.svg?branch=master)](https://travis-ci.org/purescript/purescript-lcg)

A seeded psuedorandom number generator based on the linear congruential generator algorithm.

## Installation

```
bower install purescript-lcg
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-lcg).
