export  { useMediaPredicate as useMedia_ } from "react-media-hook";
