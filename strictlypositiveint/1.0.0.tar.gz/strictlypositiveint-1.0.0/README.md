purescript-strictlypositiveint
==============================

Strictly positive integers (1,2,3,...).
