# purescript-tuples

[![Latest release](http://img.shields.io/github/release/purescript/purescript-tuples.svg)](https://github.com/purescript/purescript-tuples/releases)
[![Build status](https://travis-ci.org/purescript/purescript-tuples.svg?branch=master)](https://travis-ci.org/purescript/purescript-tuples)

Tuple data type and utility functions.

## Installation

```
bower install purescript-tuples
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-tuples).
