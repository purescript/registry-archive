# purescript-tuples

[![Latest release](http://img.shields.io/github/release/purescript/purescript-tuples.svg)](https://github.com/purescript/purescript-tuples/releases)
[![Build status](https://github.com/purescript/purescript-tuples/workflows/CI/badge.svg?branch=master)](https://github.com/purescript/purescript-tuples/actions?query=workflow%3ACI+branch%3Amaster)
[![Pursuit](https://pursuit.purescript.org/packages/purescript-tuples/badge)](https://pursuit.purescript.org/packages/purescript-tuples)

Tuple data type and utility functions.

## Installation

```
spago install tuples
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-tuples).
