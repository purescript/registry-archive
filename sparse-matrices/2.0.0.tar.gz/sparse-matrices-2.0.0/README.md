# purescript-sparse-matrices

A library to do various linear algebra computations with matrices like

* linear resolution,
* LU decomposition, 
* usual computations in various fields


## Documentation on Pursuit

https://pursuit.purescript.org/packages/purescript-sparse-matrices