# DEPRECATED

`purescript-node-fs-aff` is deprecated. Functions and values from this library were merged as-is into the [`purescript-node-fs`](https://github.com/purescript/purescript-node-fs) library.

The [original releases up to v9.2.0](https://github.com/purescript-deprecated/purescript-node-fs-aff/releases) of this library are still available and will work with compiler versions prior to PureScript v0.16.x.

