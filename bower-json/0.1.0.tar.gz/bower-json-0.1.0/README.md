# purescript-bower-json

[![](https://img.shields.io/librariesio/github/klntsky/purescript-bower-json.svg)](https://libraries.io/github/klntsky/purescript-bower-json)
[![Build status](https://travis-ci.com/klntsky/purescript-bower-json.svg?branch=master)](https://travis-ci.com/klntsky/purescript-bower-json)

A purescript port of [bower-json](https://github.com/hdgarrood/bower-json).

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-bower-json).
