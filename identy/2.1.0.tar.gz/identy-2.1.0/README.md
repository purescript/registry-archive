# purescript-identy

[![Latest release](http://img.shields.io/github/release/oreshinya/purescript-identy.svg)](https://github.com/oreshinya/purescript-identy/releases)

An opinionated UI state management utilities for [purescript-freedom](https://github.com/purescript-freedom/purescript-freedom).

[Guide](https://github.com/oreshinya/purescript-identy/tree/master/docs)

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-identy).

## LICENSE

MIT
