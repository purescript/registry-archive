# purescript-identy

[![Latest release](http://img.shields.io/github/release/oreshinya/purescript-identy.svg)](https://github.com/oreshinya/purescript-identy/releases)

An opinionated UI state management utilities.

[Guide](https://github.com/oreshinya/purescript-identy/tree/master/docs)

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-identy).

## LICENSE

MIT
