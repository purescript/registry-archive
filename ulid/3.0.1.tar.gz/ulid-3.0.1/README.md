# purescript-ulid

[![Pursuit](https://pursuit.purescript.org/packages/purescript-ulid/badge)](https://pursuit.purescript.org/packages/purescript-ulid)

PureScript bindings for [`ulid`](https://www.npmjs.com/package/ulid).

## Installation

```
spago install ulid
```

You will also need to have [`ulid`](https://www.npmjs.com/package/ulid) installed:

#### Yarn

```
yarn add ulid
```

#### npm

```
npm i ulid
```
