# purescript-routing-duplex
