purescript-naturals
===================

[![Build status](https://travis-ci.org/LiamGoodacre/purescript-naturals.svg?branch=master)](https://travis-ci.org/LiamGoodacre/purescript-naturals)

Natural numbers backed by integers hidden behind a smart constructor.
