Natural numbers backed by integers hidden behind a smart constructor.
