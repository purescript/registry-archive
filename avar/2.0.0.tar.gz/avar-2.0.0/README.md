# purescript-avar
Low-level interface for asynchronous variables
