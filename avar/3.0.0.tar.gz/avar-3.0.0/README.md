# purescript-avar

[![Latest release](http://img.shields.io/github/release/slamdata/purescript-avar.svg)](https://github.com/slamdata/purescript-avar/releases)
[![Build status](https://travis-ci.org/slamdata/purescript-avar.svg?branch=master)](https://travis-ci.org/slamdata/purescript-avar)

Low-level interface for asynchronous variables.

## Installation

```
bower install purescript-avar
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-avar).

