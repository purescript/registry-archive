# purescript-rout

[![Latest release](http://img.shields.io/github/release/oreshinya/purescript-rout.svg)](https://github.com/oreshinya/purescript-rout/releases)
[![Build status](https://travis-ci.org/oreshinya/purescript-rout.svg?branch=master)](https://travis-ci.org/oreshinya/purescript-rout)

URL parser for client side routing.

## Installation

```
bower install purescript-rout
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-rout).

## LICENSE

MIT
