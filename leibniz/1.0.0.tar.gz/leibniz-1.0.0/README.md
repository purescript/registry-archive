# purescript-leibniz

Leibniz Equality

- [Module Documentation](docs/Data/Leibniz.md)
- [Example](test/Main.purs)
