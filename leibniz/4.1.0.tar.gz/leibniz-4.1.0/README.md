# purescript-leibniz

[![Latest release](http://img.shields.io/bower/v/purescript-leibniz.svg)](https://github.com/paf31/purescript-leibniz/releases)
[![Build Status](https://travis-ci.org/paf31/purescript-leibniz.svg?branch=master)](https://travis-ci.org/paf31/purescript-leibniz)

Leibniz equality.

## Installation

```
bower install purescript-leibniz
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-leibniz).
