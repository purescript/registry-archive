# purescript-monad-eff

A type class for monads which support native effects
