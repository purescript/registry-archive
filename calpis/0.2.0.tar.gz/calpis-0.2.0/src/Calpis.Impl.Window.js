exports.windowFetch = window.fetch;
