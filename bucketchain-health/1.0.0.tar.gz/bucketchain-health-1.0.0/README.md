# purescript-bucketchain-health

[![Latest release](http://img.shields.io/github/release/Bucketchain/purescript-bucketchain-health.svg)](https://github.com/Bucketchain/purescript-bucketchain-health/releases)

A healthcheck middleware of [Bucketchain](https://github.com/Bucketchain/purescript-bucketchain).

## Installation

### Bower

```
$ bower install purescript-bucketchain-health
```

### Spago

```
$ spago install bucketchain-health
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-bucketchain-health).

## LICENSE

MIT
