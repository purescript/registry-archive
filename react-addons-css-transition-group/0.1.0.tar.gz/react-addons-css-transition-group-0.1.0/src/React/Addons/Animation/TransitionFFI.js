/* global exports */
"use strict";

// module React.Addons.Animation.Transition

var ReactCSSTransitionGroup = require('react-addons-css-transition-group');

exports.reactCSSTransitionGroupClass = ReactCSSTransitionGroup;
