# purescript-react-addons-css-transition-group

A PureScript interface to `ReactCSSTransitionGroup` for use with [`purescript-react`](https://github.com/purescript-contrib/purescript-react).

Please see [React's Animation documentation](https://facebook.github.io/react/docs/animation.html) for details concerning proper usage.  This API is byte-for-byte compatible.
