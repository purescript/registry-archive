# purescript-console-foreign

Log native Javascript objects to the console.

## Installation

```
bower install purescript-console-foreign
```

## Documentation

See module documentation for details.
