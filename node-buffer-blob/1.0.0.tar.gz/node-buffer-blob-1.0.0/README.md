# purescript-node-buffer-blob
Bindings to node-buffer's Blob type.

**Note:** This requires Node.js version >= v15.7.0, v14.18.0
