# purescript-type-equality

Type equality constraints
