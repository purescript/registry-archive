# purescript-type-equality

[![Latest release](http://img.shields.io/github/release/purescript/purescript-type-equality.svg)](https://github.com/purescript/purescript-type-equality/releases)
[![Build status](https://travis-ci.org/purescript/purescript-type-equality.svg?branch=master)](https://travis-ci.org/purescript/purescript-type-equality)

Type equality constraints

## Installation

```
bower install purescript-type-equality
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-type-equality).
