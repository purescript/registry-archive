# purescript-nodemailer

[![Latest release](http://img.shields.io/github/release/oreshinya/purescript-nodemailer.svg)](https://github.com/oreshinya/purescript-nodemailer/releases)

Bindings [nodemailer](https://github.com/nodemailer/nodemailer) for PureScript.

## Installation

```
npm install nodemailer
bower install purescript-nodemailer
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-nodemailer).

## LICENSE

MIT
