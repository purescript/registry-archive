# purescript-free-alt

[![Latest release](http://img.shields.io/github/release/Risto-Stevcev/purescript-free-alt.svg)](https://github.com/Risto-Stevcev/purescript-free-alt/releases)


An implementation of free alt in purescript


## Installation

`bower install purescript-free-alt`


## Usage

See [unit tests][1] for example usage

[1]: https://github.com/Risto-Stevcev/purescript-free-alt/blob/master/test/Control/Alt/Free.purs
