# purescript-free-alt

An implementation of free alt in purescript


## Installation

`bower install purescript-free-alt`


## Usage

See [unit tests][1] for example usage

[1]: https://github.com/Risto-Stevcev/purescript-free-alt/blob/master/test/Control/Alt/Free.purs
