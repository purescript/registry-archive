# purescript-markdown-halogen

[![Latest release](http://img.shields.io/bower/v/purescript-markdown-halogen.svg)](https://github.com/slamdata/purescript-markdown-halogen/releases)
[![Build Status](https://travis-ci.org/slamdata/purescript-markdown-halogen.svg?branch=master)](https://travis-ci.org/slamdata/purescript-markdown-halogen)
[![Dependency Status](https://www.versioneye.com/user/projects/567436ff107997003e00076a/badge.svg?style=flat)](https://www.versioneye.com/user/projects/567436ff107997003e00076a)

A Halogen rendering library for `purescript-markdown`.

## Installation

```
bower install purescript-markdown-halogen
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-markdown-halogen).
