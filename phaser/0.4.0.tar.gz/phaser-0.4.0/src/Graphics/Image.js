'use strict';

exports.createImpl = (textureKey, scene) => scene.add.image(0, 0, textureKey);
