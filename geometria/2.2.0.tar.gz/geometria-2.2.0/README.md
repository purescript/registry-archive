# purescript-geometria
Some basic tools for Euclidean geometry like vector constructions or intersections of common shapes in low dimensions
