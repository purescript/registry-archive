# purescript-qualified-do

## Installation

```sh
spago install qualified-do
```

## Documentation

This package contains several modules that allow for alternate `do` and `ado`
behavior through the `QualifiedDo` feature. See each module's top level
documentation for further reference.

### Reference

Module reference is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-qualified-do).
