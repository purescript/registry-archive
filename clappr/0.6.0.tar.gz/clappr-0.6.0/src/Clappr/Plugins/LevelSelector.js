/* global exports */
"use strict";

// module Clappr.Plugins.LevelSelector

exports.levelSelector = require('clappr-level-selector-plugin');

