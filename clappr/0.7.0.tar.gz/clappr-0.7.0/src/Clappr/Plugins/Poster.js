/* global exports */
"use strict";

// module Clappr.Plugins.Poster

var clappr = require('clappr');

exports.poster = clappr.Poster;
