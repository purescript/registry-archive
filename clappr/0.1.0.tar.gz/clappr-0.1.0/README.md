# purescript-clappr

Low level bindings to Clappr video player.

## API

Currently this lib coverse basic player options, most of event handlers binders and some of built in plugins (with one extras included: `ResponsiveContainer`).

## Examples

In `./examples` dir you can find working examples of event handlers binding and plugins setup. I'm going to improve build up process soon...
