# purescript-clappr

Low level bindings to Clappr video player.

## API

Status of bindings:

  * basic options

  * most of event handlers binders

  * most of built-in plugins

  * one extra plugin included - `ResponsiveContainer`


## Examples

You can find two examples which show:

  * how to attach event handlers

  * how to configure plugins

Both are self-containted - just check build instructions in their READMEs.
