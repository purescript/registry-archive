/* global exports */
"use strict";

// module Clappr.Plugins.DvrControls

var clappr = require('clappr');

exports.dvrControls = clappr.DvrControls;
