/* global exports */
"use strict";

// module Clappr.Plugins.Watermark

var clappr = require('clappr');

exports.watermark = clappr.WaterMarkPlugin;
