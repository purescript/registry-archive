# purescript-clappr

Purescript bindings to Clappr video player.

## Status

Bindings cover:

  * basic options

  * most of event handlers binders

  * most of built-in plugins

  * one extra plugin - `ResponsiveContainer`


## Examples

Examples show:

  * how to attach event handlers

  * how to configure plugins

Both are self-containted - just check build instructions in their READMEs.
