/* global exports */
"use strict";

// module Clappr.Plugins.ClickToPause

var clappr = require('clappr');

exports.clickToPause = clappr.ClickToPausePlugin;
