/* global exports */
"use strict";

// module Clappr.Plugins.Favicon

var clappr = require('clappr');

exports.favicon = clappr.Favicon;
