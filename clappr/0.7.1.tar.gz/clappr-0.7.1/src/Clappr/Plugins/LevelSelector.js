/* global exports */
"use strict";

// module Clappr.Plugins.LevelSelector

exports.levelSelector = require('level-selector');

