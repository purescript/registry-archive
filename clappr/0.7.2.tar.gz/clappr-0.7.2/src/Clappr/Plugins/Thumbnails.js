var thumbnails = require('clappr-thumbnails-plugin');

exports.thumbnails = thumbnails;
