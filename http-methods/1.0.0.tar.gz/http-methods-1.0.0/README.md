# purescript-http-methods

[![Latest release](http://img.shields.io/bower/v/purescript-http-methods.svg)](https://github.com/purescript-contrib/purescript-http-methods/releases)
[![Build Status](https://travis-ci.org/purescript-contrib/purescript-http-methods.svg?branch=master)](https://travis-ci.org/purescript-contrib/purescript-http-methods)
[![Dependency Status](https://www.versioneye.com/user/projects/57558c637757a00041b3a750/badge.svg?style=flat)](https://www.versioneye.com/user/projects/57558c637757a00041b3a750)
[![Maintainer: garyb](https://img.shields.io/badge/maintainer-garyb-lightgrey.svg)](http://github.com/garyb)

HTTP method type.

## Installation

```
bower install purescript-http-methods
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-http-methods).
