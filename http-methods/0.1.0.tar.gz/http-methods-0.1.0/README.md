# purescript-http-methods

[![Latest release](http://img.shields.io/bower/v/purescript-http-methods.svg)](https://github.com/purescript-contrib/purescript-http-methods/releases)
[![Build Status](https://travis-ci.org/purescript-contrib/purescript-http-methods.svg?branch=master)](https://travis-ci.org/purescript-contrib/purescript-http-methods)
[![Maintainer: garyb](https://img.shields.io/badge/maintainer-garyb-lightgrey.svg)](http://github.com/garyb)

HTTP method type.

## Installation

```
bower install purescript-http-methods
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-http-methods).
