# purescript-eth-core

[![Build Status](https://travis-ci.org/f-o-a-m/purescript-eth-core.svg?branch=master)](https://travis-ci.org/f-o-a-m/purescript-eth-core)

Common types and utility functions for all web3 libraries

## Installation

```
bower install purescript-eth-core
```

⚠️ You will also need to install additional **npm** dependencies specified [here](https://github.com/f-o-a-m/purescript-eth-core/blob/master/package.json#L7-L10)
