var rlp = require('rlp');

exports._rlpEncode = rlp.encode;

exports._rlpNull = null;
