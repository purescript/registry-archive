# PureScript bindings for RxJs

## Installation

```
npm install rx
bower install purescript-rx
```

## [Module documentation](http://pursuit.purescript.org/packages/purescript-rx/)

