# PureScript bindings for RxJs

## Installation

```
npm install rx
bower install purescript-rx
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-rx/). 

