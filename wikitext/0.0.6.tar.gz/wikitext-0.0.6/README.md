purescript-wikitext [![Build Status](https://api.travis-ci.org/AKST/purescript-wikitext.svg)](https://travis-ci.org/AKST/purescript-wikitext?branch=master)
==================



A wikitext diffing/parsing library written in PureScript.

- [Module documentation](docs.md)
- _No examples yet_
