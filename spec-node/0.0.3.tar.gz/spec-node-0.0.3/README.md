[![build](https://github.com/purescript-spec/purescript-spec-node/actions/workflows/build.yml/badge.svg)](https://github.com/purescript-spec/purescript-spec-node/actions/workflows/build.yml)

# PureScript Spec test runner for Node

The default runner for your tests if you're running on Node.

Documentation and examples here: https://purescript-spec.github.io/purescript-spec/running/
