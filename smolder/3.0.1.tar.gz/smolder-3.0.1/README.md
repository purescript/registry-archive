# purescript-smolder

A simple combinator library for generating HTML in PureScript, heavily inspired by Haskell's [BlazeHtml](http://jaspervdj.be/blaze/).

- [Module Documentation](docs/Text/Smolder/)
- [Example](test/Main.purs)

