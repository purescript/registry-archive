'use strict';

exports.newImpl = function(el, config) {
    return new Quill(el, config);
};
