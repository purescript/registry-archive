purescript-arrows
=================

[![Build Status](https://travis-ci.org/purescript-contrib/purescript-arrows.svg?branch=master)](https://travis-ci.org/purescript-contrib/purescript-arrows)

Type classes for Arrows.

- [Module documentation](docs/Module.md)
