# purescript-tailrec

A type class which captures stack-safe monadic tail recursion.
