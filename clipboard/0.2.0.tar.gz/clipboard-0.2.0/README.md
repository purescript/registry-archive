# purescript-clipboard

[![Latest release](http://img.shields.io/github/release/slamdata/purescript-clipboard.svg)](https://github.com/slamdata/purescript-clipboard/releases)
[![Build status](https://travis-ci.org/slamdata/purescript-clipboard.svg?branch=master)](https://travis-ci.org/slamdata/purescript-clipboard)

Basic PureScript bindings for the [clipboard.js](https://github.com/zenorocha/clipboard.js/) library.

## Installation

```
bower install purescript-clipboard
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-clipboard).
