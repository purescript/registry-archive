# purescript-clipboard

[![Latest release](http://img.shields.io/github/release/slamdata/purescript-clipboard.svg)](https://github.com/slamdata/purescript-clipboard/releases)
![Build Status](https://github.com/slamdata/purescript-clipboard/actions/workflows/ci.yml/badge.svg)

Basic PureScript bindings for the [clipboard.js](https://github.com/zenorocha/clipboard.js/) library.

## Installation

```
bower install purescript-clipboard
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-clipboard).
