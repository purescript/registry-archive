/* global exports */
"use strict";

// module Data.List.Unsafe

exports.unsafeThrow = function (msg) {
  throw new Error(msg);
};
