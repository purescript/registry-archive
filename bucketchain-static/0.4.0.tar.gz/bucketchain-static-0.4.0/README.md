# purescript-bucketchain-static

[![Latest release](http://img.shields.io/github/release/Bucketchain/purescript-bucketchain-static.svg)](https://github.com/Bucketchain/purescript-bucketchain-static/releases)

A static file server middleware of [Bucketchain](https://github.com/Bucketchain/purescript-bucketchain).

## Installation

### Bower

```
$ bower install purescript-bucketchain-static
```

### Spago

```
$ spago install bucketchain-static
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-bucketchain-static).

## LICENSE

MIT
