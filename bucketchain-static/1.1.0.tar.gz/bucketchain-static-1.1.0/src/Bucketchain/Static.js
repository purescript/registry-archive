'use strict';

export function code(e) {
  return e.code;
}
