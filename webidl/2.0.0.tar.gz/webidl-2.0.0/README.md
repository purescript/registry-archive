# purescript-webidl

A wrapper for the [webidl2.js](https://github.com/darobin/webidl2.js) library.

- [Module Documentation](docs/WebIDL.md)
- [Example](test/Main.purs)

## Usage

    bower i purescript-webidl
