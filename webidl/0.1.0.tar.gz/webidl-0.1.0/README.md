# purescript-webidl

A wrapper for the [webidl2.js](https://github.com/darobin/webidl2.js) library.
