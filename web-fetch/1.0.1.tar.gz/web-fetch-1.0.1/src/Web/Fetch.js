exports._fetch = function(a, b) {
  return fetch(a, b);
};
