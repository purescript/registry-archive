exports.fromArrayBuffer = function(a) { return a };
exports.fromArrayView = function(a) { return a };
exports.fromString = function(a) { return a };
exports.fromReadableStream = function(a) { return a };
exports.empty = null;