export function _fetch(a, b) {
  return fetch(a, b);
}
