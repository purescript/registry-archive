purescript-concurrent-queues
==
[![Latest release](http://img.shields.io/github/release/slamdata/purescript-concurrent-queues.svg)](https://github.com/slamdatapurescript-concurrent-queues/releases)
[![Build Status](https://travis-ci.org/slamdata/purescript-concurrent-queues.svg?branch=master)](https://travis-ci.org/slamdata/purescript-concurrent-queues)

An unbounded and bounded queue for concurrent access.

## Installation

```
bower install purescript-concurrent-queues
```

## Examples

See the `test/` directory for examples of all available functions.

## Documentation

Module documentatin is publish on [Pursuit](http://pursuit.purescript.org/packages/purescript-concurrent-queues).