exports.isENOENT = function (e) {
  return e.code === "ENOENT"
}
