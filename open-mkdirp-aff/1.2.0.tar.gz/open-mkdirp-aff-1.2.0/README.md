# purescript-open-mkdirp-aff

[![Latest release](http://img.shields.io/github/release/purescript-node/purescript-open-mkdirp-aff.svg)](https://github.com/purescript-node/purescript-open-mkdirp-aff/releases)
[![Build status](https://github.com/purescript-node/purescript-open-mkdirp-aff/workflows/CI/badge.svg?branch=master)](https://github.com/purescript-node/purescript-open-mkdirp-aff/actions?query=workflow%3ACI+branch%3Amaster)
[![Pursuit](https://pursuit.purescript.org/packages/purescript-open-mkdirp-aff/badge)](https://pursuit.purescript.org/packages/purescript-open-mkdirp-aff)

This is fork of

https://github.com/leighman/purescript-mkdirp-aff

## Installation

```
spago install open-mkdirp-aff
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-open-mkdirp-aff).
