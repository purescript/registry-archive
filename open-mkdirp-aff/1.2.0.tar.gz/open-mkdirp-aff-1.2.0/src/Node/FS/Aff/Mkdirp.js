export function isENOENT(e) {
  return e.code === "ENOENT"
}
