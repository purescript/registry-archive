# react-basic-emotion

[Emotion](https://emotion.sh/) support for [react-basic](https://github.com/lumihq/purescript-react-basic)!
