# react-basic-emotion

[Emotion](https://emotion.sh/) support for [react-basic](https://github.com/lumihq/purescript-react-basic)!

[![Build Status](https://github.com/lumihq/purescript-react-basic-emotion/actions/workflows/ci.yml/badge.svg)](https://github.com/lumihq/purescript-react-basic-emotion/actions/workflows/ci.yml)
<a href="https://pursuit.purescript.org/packages/purescript-react-basic-emotion">
  <img src="https://pursuit.purescript.org/packages/purescript-react-basic-emotion/badge"
       alt="Fixed Precision on Pursuit">
  </img>
</a>

