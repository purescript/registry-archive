# Purversion

Richly-typed and versioned localStorage keys for Purescript

- See [test/Example.purs](https://github.com/Quelklef/purversion/blob/master/test/Example.purs) or [test/Main.purs](https://github.com/Quelklef/purversion/blob/master/test/Main.purs) for examples
- See [Pursuit](#) for hard documentation (TODO)

Enjoy!
