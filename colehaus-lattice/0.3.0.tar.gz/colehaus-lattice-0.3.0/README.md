# purescript-lattice

[![Latest release](http://img.shields.io/github/release/Risto-Stevcev/purescript-lattice.svg)](https://github.com/Risto-Stevcev/purescript-lattice/releases)

Lattices in purescript

## Installation

```
bower install purescript-lattice
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-lattice).
