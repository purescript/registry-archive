# purescript-free-alternative

[![Latest release](http://img.shields.io/github/release/Risto-Stevcev/purescript-free-alternative.svg)](https://github.com/Risto-Stevcev/purescript-free-alternative/releases)


An implementation of free alternative in purescript


## Installation

`bower install purescript-free-alternative`


## Usage

See [unit tests][1] for example usage


[1]: https://github.com/Risto-Stevcev/purescript-free-alternative/blob/master/test/Control/Alternative/Free.purs
