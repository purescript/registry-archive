PureScript bindings for prettier

# Usage

```purescript
import Text.Prettier (defaultOptions, format)

format defaultOptions "const a=1" -- "const a = 1;\n"
```
