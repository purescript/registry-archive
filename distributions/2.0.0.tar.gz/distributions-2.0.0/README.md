# purescript-distributions

A monad which generalizes the probability monad to an arbitrary `Semiring` of probabilities.

- [Module Documentation](docs/Data/Distribution.md)
