# purescript-quickcheck-laws

[![Latest release](http://img.shields.io/github/release/garyb/purescript-quickcheck-laws.svg)](https://github.com/garyb/purescript-quickcheck-laws/releases)
[![Build status](https://travis-ci.org/garyb/purescript-quickcheck-laws.svg?branch=master)](https://travis-ci.org/garyb/purescript-quickcheck-laws)
[![Dependency status](https://img.shields.io/librariesio/github/garyb/purescript-quickcheck-laws.svg)](https://libraries.io/github/garyb/purescript-quickcheck-laws)

QuickCheck powered law tests for PureScript's core typeclasses.

## Installation

```
bower install purescript-quickcheck-laws
```

## Documentation

Module documentation is published on Pursuit: [http://pursuit.purescript.org/packages/purescript-quickcheck-laws](http://pursuit.purescript.org/packages/purescript-quickcheck-laws)
