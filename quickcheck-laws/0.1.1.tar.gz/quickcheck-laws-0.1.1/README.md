# purescript-quickcheck-laws

[![Latest release](http://img.shields.io/bower/v/purescript-quickcheck-laws.svg)](https://github.com/garyb/purescript-quickcheck-laws/releases)
[![Build Status](https://travis-ci.org/garyb/purescript-quickcheck-laws.svg?branch=master)](https://travis-ci.org/garyb/purescript-quickcheck-laws)
[![Dependency Status](https://www.versioneye.com/user/projects/56575684ff016c002c001d06/badge.svg?style=flat)](https://www.versioneye.com/user/projects/56575684ff016c002c001d06)

QuickCheck powered law tests for PureScript's core typeclasses.

## Installation

```
bower install purescript-quickcheck-laws
```

## Documentation

Module documentation is published on Pursuit: [http://pursuit.purescript.org/packages/purescript-quickcheck-laws](http://pursuit.purescript.org/packages/purescript-quickcheck-laws)
