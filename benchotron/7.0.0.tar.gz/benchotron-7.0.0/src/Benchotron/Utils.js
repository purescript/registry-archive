/* global exports */
"use strict";

exports.unsafeJsonStringify = JSON.stringify;
