/* global exports */
"use strict";

// module Benchotron.Utils

exports.unsafeJsonStringify = JSON.stringify;
