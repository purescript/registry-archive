# purescript-record

[![Latest release](http://img.shields.io/bower/v/purescript-record.svg)](https://github.com/purescript/purescript-record/releases)
[![Build Status](https://travis-ci.org/purescript/purescript-record.svg?branch=master)](https://travis-ci.org/purescript/purescript-record)

Functions for working with records and polymorphic labels

## Installation

```
bower install purescript-record
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-record).
