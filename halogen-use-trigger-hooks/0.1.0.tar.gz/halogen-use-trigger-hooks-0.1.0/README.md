# PureScript Halogen UseTrigger Hooks

A tiny hooks library allows ones to control the component evaluation.

[![purs - v0.15.15](https://img.shields.io/badge/purs-v0.15.15-blue?logo=purescript)](https://github.com/purescript/purescript/releases/tag/v0.15.15)
