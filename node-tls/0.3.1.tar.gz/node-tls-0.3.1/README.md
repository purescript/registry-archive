# purescript-node-tls

PureScript bindings to the Node.js [`tls`](https://nodejs.org/dist/latest-v18.x/docs/api/tls.html) module.
