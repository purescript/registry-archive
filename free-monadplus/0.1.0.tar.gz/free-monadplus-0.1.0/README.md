# purescript-free-monadplus

[![Latest release](http://img.shields.io/github/release/Risto-Stevcev/purescript-free-monadplus.svg)](https://github.com/Risto-Stevcev/purescript-free-monadplus/releases)


An implementation of free monad plus in purescript


## Installation

`bower install purescript-free-monadplus`


## Usage

See [unit tests][1] for example usage


[1]: https://github.com/Risto-Stevcev/purescript-free-monadplus/blob/master/test/Control/MonadPlus/Free.purs
