
exports.refEq = function (a) {
    return function (b) {
        return a === b;
    };
};
