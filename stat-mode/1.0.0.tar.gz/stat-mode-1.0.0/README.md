purescript-stat-mode
==================
A pure PureScript implementation of [stat-mode](https://github.com/TooTallNate/stat-mode).

Installation
------------
```bash
bower install -S purescript-stat-mode
```

Documentation
-------------
Module documentation is [published on Pursuit](https://pursuit.purescript.org/packages/purescript-stat-mode/),
or available in the [docs directory](docs/):

- [Stat/Mode.md](docs/Stat/Mode.md) - Functionality for working with stat `mode`s.
