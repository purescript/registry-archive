exports._parseJSON = JSON.parse;

exports._undefined = undefined;
