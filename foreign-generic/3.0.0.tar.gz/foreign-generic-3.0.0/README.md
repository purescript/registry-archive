# purescript-foreign-generic

[![Build Status](https://travis-ci.org/paf31/purescript-foreign-generic.svg?branch=master)](https://travis-ci.org/paf31/purescript-foreign-generic)

Generic deriving for `purescript-foreign`.

- [Module Documentation](docs/Data/Foreign/Generic.md)
- [Example](test/Main.purs)
