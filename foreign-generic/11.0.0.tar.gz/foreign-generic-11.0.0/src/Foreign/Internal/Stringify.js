exports.unsafeStringify = function (x) {
  return JSON.stringify(x);
};
