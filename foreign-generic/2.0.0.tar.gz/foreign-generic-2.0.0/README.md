# purescript-foreign-generic

Generic deriving for `purescript-foreign`.

- [Module Documentation](docs/Data/Foreign/Generic.md)
- [Example](test/Main.purs)
