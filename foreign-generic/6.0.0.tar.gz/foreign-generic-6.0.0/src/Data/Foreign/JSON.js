"use strict";

exports.parseJSONImpl = function (str) {
  return JSON.parse(str);
};
