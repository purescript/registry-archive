# purescript-polyform-validators

Set of useful validators which are build on top of `Validator` and `Dual` from purescript-polyform.

Heavy refactoring. New release soon.
