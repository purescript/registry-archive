# purescript-idiomatic-node-http
An idiomatic wrapper for Node's HTTP API.
