# purescript-plan
A simple chat runner write by purescript
