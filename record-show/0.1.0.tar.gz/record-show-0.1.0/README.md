# purescript-record-show

A `Show` instance for records. See `test/Main.purs` for usage.

## Installation

```
bower install purescript-record-show
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-record-show).
