# purescript-airconsole-view-manager
Purescript bindings for the airconsole-view-manager library
