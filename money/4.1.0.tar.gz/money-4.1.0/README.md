# purescript-money

Types and operations on monetary values.
