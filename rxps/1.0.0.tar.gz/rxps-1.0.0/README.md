# purescript-rxjs
An opinionated PureScript wrapper for RxJS, complete with a Monad Transformer `ObservableT`


### Installation

```bash
npm install rxjs
bower install purescript-rx-observable
```

### Documentation

- See the `docs` folder.
