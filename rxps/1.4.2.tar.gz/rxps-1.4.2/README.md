# purescript-rxps
An opinionated PureScript wrapper for RxJS, complete with a Monad Transformer `ObservableT`


### Installation

```bash
npm install rxjs
bower install purescript-rxps
```

### Documentation

- Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-rxps).
