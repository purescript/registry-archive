# purescript-filterables

[![Latest release](http://img.shields.io/github/release/Risto-Stevcev/purescript-filterables.svg)](https://github.com/Risto-Stevcev/purescript-filterables/releases)

A class for filterable data structures


## Installation

```
bower install purescript-filterables
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-filterables).
