# PureScript-Has-JS-Rep

Sometimes you want this if you're working with something you're going to codegen TypeScript/Flow bindings for.

## Usage

Mostly use the constraint whenever you need it. See <https://github.com/justinwoo/purescript-ohyes> for an example of when you'd use this.
