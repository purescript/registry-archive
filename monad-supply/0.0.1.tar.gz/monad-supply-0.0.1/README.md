
purescript-monad-supply
==================

[![Build
Status](https://travis-ci.org/cdepillabout/purescript-monad-supply.svg)](https://travis-ci.org/cdepillabout/purescript-monad-supply)

This library makes it easy to generate new names.

It is based on
[`Control.Monad.Supply`](https://github.com/purescript/purescript/blob/master/src/Control/Monad/Supply.hs)
from the PureScript compiler.

- [Module documentation](docs/Control/Monad/)

### Installing

```sh
$ npm install
$ ./node_modules/.bin/bower install --save purescript-monad-supply
```

### Building / Testing

```sh
$ pulp build
$ pulp test
```

### Usage

TODO
