# purescript-twilio

Twilio client library for PureScript. This library depends on the npm library
twilio. To use this library, you must manually install twilio.
