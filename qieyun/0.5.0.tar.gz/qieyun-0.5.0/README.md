# purescript-qieyun [![](https://github.com/nk2028/purescript-qieyun/workflows/Build/badge.svg)](https://github.com/nk2028/purescript-qieyun/actions?query=workflow%3ABuild) [![](https://pursuit.purescript.org/packages/purescript-qieyun/badge)](https://pursuit.purescript.org/packages/purescript-qieyun)

A PureScript library for the Qieyun phonological system

## Install

See [INSTALL.md](INSTALL.md).

## Documentation

Published on [Pursuit](https://pursuit.purescript.org/packages/purescript-qieyun).
