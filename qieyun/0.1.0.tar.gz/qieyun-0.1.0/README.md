# purescript-qieyun [![](https://github.com/nk2028/purescript-qieyun/workflows/Build/badge.svg)](https://github.com/nk2028/purescript-qieyun/actions?query=workflow%3ABuild)

A PureScript library for the Qieyun phonological system
