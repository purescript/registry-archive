# purescript-conveyor

[![Latest release](http://img.shields.io/github/release/oreshinya/purescript-conveyor.svg)](https://github.com/oreshinya/purescript-conveyor/releases)

Simple RPC framework.

See [example](https://github.com/oreshinya/purescript-conveyor/blob/master/example/Main.purs).

## Installation

```
bower install purescript-conveyor
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-conveyor).

## LICENSE

MIT
