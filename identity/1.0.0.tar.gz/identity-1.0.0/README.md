# purescript-identity

[![Latest release](http://img.shields.io/bower/v/purescript-identity.svg)](https://github.com/purescript/purescript-identity/releases)
[![Build Status](https://travis-ci.org/purescript/purescript-identity.svg?branch=master)](https://travis-ci.org/purescript/purescript-identity)
[![Dependency Status](https://www.versioneye.com/user/projects/55848cab363861001b0001a5/badge.svg?style=flat)](https://www.versioneye.com/user/projects/55848cab363861001b0001a5)

Identity value.

## Installation

```
bower install purescript-identity
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-identity).
