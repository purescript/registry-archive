# purescript-identity

[![Build Status](https://travis-ci.org/purescript/purescript-identity.svg?branch=master)](https://travis-ci.org/purescript/purescript-identity)

Identity value.

## Installation

```
bower install purescript-identity
```

## Module documentation

- [Data.Identity](docs/Data.Identity.md)
