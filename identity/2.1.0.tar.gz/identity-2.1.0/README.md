# purescript-identity

[![Latest release](http://img.shields.io/github/release/purescript/purescript-identity.svg)](https://github.com/purescript/purescript-identity/releases)
[![Build status](https://travis-ci.org/purescript/purescript-identity.svg?branch=master)](https://travis-ci.org/purescript/purescript-identity)

Identity value.

## Installation

```
bower install purescript-identity
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-identity).
