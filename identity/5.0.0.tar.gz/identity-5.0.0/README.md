# purescript-identity

[![Latest release](http://img.shields.io/github/release/purescript/purescript-identity.svg)](https://github.com/purescript/purescript-identity/releases)
[![Build status](https://github.com/purescript/purescript-identity/workflows/CI/badge.svg?branch=master)](https://github.com/purescript/purescript-identity/actions?query=workflow%3ACI+branch%3Amaster)
[![Pursuit](https://pursuit.purescript.org/packages/purescript-identity/badge)](https://pursuit.purescript.org/packages/purescript-identity)

Identity value.

## Installation

```
spago install identity
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-identity).
