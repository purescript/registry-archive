# purescript-node-path

[![Latest release](http://img.shields.io/bower/v/purescript-node-path.svg)](https://github.com/purescript-node/purescript-node-path/releases)
[![Build Status](https://travis-ci.org/purescript-node/purescript-node-path.svg?branch=master)](https://travis-ci.org/purescript-node/purescript-node-path)
[![Maintainer: garyb](https://img.shields.io/badge/maintainer-garyb-lightgrey.svg)](http://github.com/garyb)

Type type definitions for Node's path module.

## Installation

```
bower install purescript-node-path
```

## Module documentation

- [Node.Path](docs/Node/Path.md)
