# purescript-parallel

A newtype for parallel composition of continuations

- [Module Documentation](docs/README.md)
- [Example](example/Main.purs)

## Building

```
npm install
bower update
grunt
```
