# purescript-parallel

A newtype for parallel composition of continuations

- [Module Documentation](docs/README.md)

## Building

```
npm install
bower update
grunt
```
