# purescript-parallel

[![Latest release](http://img.shields.io/bower/v/purescript-parallel.svg)](https://github.com/purescript/purescript-parallel/releases)
[![Build Status](https://travis-ci.org/purescript/purescript-parallel.svg?branch=master)](https://travis-ci.org/purescript/purescript-parallel)
[![Dependency Status](https://www.versioneye.com/user/projects/55848caf363861001d00034a/badge.svg?style=flat)](https://www.versioneye.com/user/projects/55848caf363861001d00034a)

Classes for parallel composition and racing of asynchronous computations.

## Installation

```
bower install purescript-parallel
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-parallel).
