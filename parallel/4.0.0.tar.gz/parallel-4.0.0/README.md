# purescript-parallel

[![Latest release](http://img.shields.io/github/release/purescript/purescript-parallel.svg)](https://github.com/purescript/purescript-parallel/releases)
[![Build status](https://travis-ci.org/purescript/purescript-parallel.svg?branch=master)](https://travis-ci.org/purescript/purescript-parallel)
[![Dependency status](https://img.shields.io/librariesio/github/purescript/purescript-parallel.svg)](https://libraries.io/github/purescript/purescript-parallel)

Classes for parallel composition and racing of asynchronous computations.

## Installation

```
bower install purescript-parallel
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-parallel).
