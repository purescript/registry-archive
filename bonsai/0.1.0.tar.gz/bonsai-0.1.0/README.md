# Purescript Bonsai

It's a mini-Elm *groan*

It's Elm's Virtual DOM implementation with
the debugger and other Elm specific parts removed.

Enough Elm-like infrastructure was implemented in
Purescript to make it usable.  Well, kind of.
It works on my machine.
