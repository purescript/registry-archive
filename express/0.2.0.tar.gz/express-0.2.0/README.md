purescript-express
==================

[![Build Status](https://travis-ci.org/dancingrobot84/purescript-express.svg?branch=master)](https://travis-ci.org/dancingrobot84/purescript-express)

Purescript wrapper around Node.js Express web-framework. Currently in deep
alpha.

