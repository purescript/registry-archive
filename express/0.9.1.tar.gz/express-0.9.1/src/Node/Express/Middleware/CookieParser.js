import cookieParser from "cookie-parser";

export const _cookieParser = cookieParser
