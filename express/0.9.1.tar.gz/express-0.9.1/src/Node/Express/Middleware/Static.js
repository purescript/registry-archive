import { static as expressStatic } from "express";

export const _static = expressStatic
