export const _set = (app, tableItemName, tableItemValue) => app.set(tableItemName, tableItemValue);
export const _get = (app, tableItemName) => app.get(tableItemName);
