export const showSymbolImpl = (s) => s.toString();
export const forImpl = (s) => Symbol.for(s);
export const keyForImpl = (s) => Symbol.keyFor(s);
