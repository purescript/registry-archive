# purescript-node-event-emitter

Bindings for the [`event-emitter`](https://nodejs.org/api/events.html#class-eventemitter) class.
