# purescript-node-streams

A wrapper for Node's [Stream API](https://nodejs.org/api/stream.html).

- [Example](example/Gzip.purs)

Documentation is published on [Pursuit](https://pursuit.purescript.org/packages/purescript-node-streams).
