# purescript-node-streams

A wrapper for Node's Stream API

- [Module Documentation](docs/)
- [Example](example/Gzip.purs)
