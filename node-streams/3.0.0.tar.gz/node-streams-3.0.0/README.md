# purescript-node-streams

[![Latest release](http://img.shields.io/github/release/purescript-node/purescript-node-streams.svg)](https://github.com/purescript-node/purescript-node-streams/releases)
[![Build Status](https://travis-ci.org/purescript-node/purescript-node-streams.svg?branch=master)](https://travis-ci.org/purescript-node/purescript-node-streams)

A wrapper for Node's [Stream API](https://nodejs.org/api/stream.html).

## Installation

```
bower install purescript-node-streams
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-node-streams).
