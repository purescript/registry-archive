# purescript-posix-types

[![Latest release](http://img.shields.io/github/release/purescript-node/purescript-posix-types.svg)](https://github.com/purescript-node/purescript-posix-types/releases)
[![Build Status](https://travis-ci.org/purescript-node/purescript-posix-types.svg?branch=master)](https://travis-ci.org/purescript-node/purescript-posix-types)

Basic types for use with bindings to POSIX-style APIs.

## Installation

```
bower install purescript-posix-types
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-posix-types).
