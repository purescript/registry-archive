# purescript-posix-types

Basic types for use with bindings to POSIX-style APIs.

Documentation is [on Pursuit](http://pursuit.purescript.org/packages/purescript-posix-types).
