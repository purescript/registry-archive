purescript-virtual-dom-typed [![Build Status](https://travis-ci.org/mechairoi/purescript-virtual-dom-typed.svg?branch=master)](https://travis-ci.org/mechairoi/purescript-virtual-dom-typed)
===
typed wrapper for purescript-virtual-dom

- [Module documentation](MODULE.md)
