import image from "next/image.js"

export const imageImpl = image;
