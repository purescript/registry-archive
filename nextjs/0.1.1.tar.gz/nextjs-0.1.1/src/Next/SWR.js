export { default as useSWR_ , SWRConfig as swrConfig } from 'swr'

