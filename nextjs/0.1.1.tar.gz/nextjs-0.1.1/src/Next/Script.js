
export { default as script } from 'next/script';
