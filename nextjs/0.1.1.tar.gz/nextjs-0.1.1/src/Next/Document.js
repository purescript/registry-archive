import document from "next/document";
export var _html = document.Html;
export var _head = document.Head;
export var _main = document.Main;
export var _nextScript = document.NextScript;

export const unsafeDocument = component => () => {
    component.getInitialProps = nextDoc.getInitialProps
    return component
}
