# purescript-graphql-client

A typesafe graphql client for purescript.