# purescript-arrays-zipper
Zippers for arrays
