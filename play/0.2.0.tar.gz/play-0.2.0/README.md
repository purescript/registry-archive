# purescript-play

UI layout system, as simple and minimal as possible, inspired by Clay (C Layout) from Nic Baker: [YouTube Video](https://www.youtube.com/watch?v=by9lQvpvMIc).

No text measurement and so auto-fit support yet.

Quick overview with `test/Demo` module running: [as YT shorts](https://youtube.com/shorts/cRGQw67-7FQ).
