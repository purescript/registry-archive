# purescript-taylor

Taylor series as lazy streams of coefficients, based on The Music of Streams by Doug McIlroy.
