exports.nativeShowDocument = function(doc) {
  return JSON.stringify(doc);
};
