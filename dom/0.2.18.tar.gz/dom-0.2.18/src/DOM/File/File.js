// module DOM.File.File

exports.name = function(file) { return file.name };
exports.lastModifiedDate = function(file) { return file.lastModifiedDate }
exports.lastModified = function(file) { return file.lastModified }
