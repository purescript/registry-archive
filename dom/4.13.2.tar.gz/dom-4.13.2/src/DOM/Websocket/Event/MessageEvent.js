"use strict";

exports.data_ = function (e) {
  return e.data;
};

exports.origin = function (e) {
  return e.origin;
};

exports.lastEventId = function (e) {
  return e.lastEventId;
};
