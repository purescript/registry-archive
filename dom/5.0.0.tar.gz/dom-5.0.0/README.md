# DEPRECATED

`purescript-dom` has been split up into a variety of projects in the [`purescript-web`](https://github.com/purescript-web/) organization. The closest equivalent now is [`purescript-web-html`](https://github.com/purescript-web/purescript-web-html) (for the HTML5 API, with a transitive dependency on the DOM API) combined with [`purescript-web-uievents`](https://github.com/purescript-web/purescript-web-uievents).

The [original releases up to v4.16.0](https://github.com/purescript-deprecated/purescript-dom/releases) of this library are still available and will work with compiler versions prior to PureScript v0.12.x.
