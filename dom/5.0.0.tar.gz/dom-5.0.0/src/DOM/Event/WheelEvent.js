"use strict";

exports.deltaX = function (e) {
  return e.deltaX;
};

exports.deltaY = function (e) {
  return e.deltaY;
};

exports.deltaZ = function (e) {
  return e.deltaZ;
};

exports.deltaModeIndex = function (e) {
  return e.deltaModeIndex;
};
