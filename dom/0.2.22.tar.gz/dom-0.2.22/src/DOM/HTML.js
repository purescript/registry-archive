/* global window */
"use strict";

// module DOM.HTML

exports.window = function () {
  return window;
};
