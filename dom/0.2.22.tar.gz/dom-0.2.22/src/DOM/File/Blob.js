"use strict";

// module DOM.File.Blob

exports.typeImpl = function (blob) { return blob.type; };

exports.size = function (blob) { return blob.size; };
