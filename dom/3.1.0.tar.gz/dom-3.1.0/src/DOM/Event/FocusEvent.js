"use strict";

exports.relatedTargetNullable = function (e) {
  return e.relatedTarget;
};
