"use strict";

exports.options = function (dle) {
  return function () {
    return dle.options;
  };
};
