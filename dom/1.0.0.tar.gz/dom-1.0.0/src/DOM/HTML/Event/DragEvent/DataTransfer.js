"use strict";

exports.files = function (dataTransfer) {
  return dataTransfer.files;
};
