"use strict";

exports.form = function (le) {
  return function () {
    return le.form;
  };
};
