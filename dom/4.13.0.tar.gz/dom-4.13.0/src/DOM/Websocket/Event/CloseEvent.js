"use strict";

exports.code = function (e) {
  return e.code;
};

exports.reason = function (e) {
  return e.reason;
};

exports.wasClean = function (e) {
  return e.wasClean;
};
