/* global exports */
"use strict";

// module DOM.HTML.HTMLDataListElement

exports.options = function (dle) {
  return function () {
    return dle.options;
  };
};
