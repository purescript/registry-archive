"use strict";

exports._relatedTarget = function (e) {
  return e.relatedTarget;
};
