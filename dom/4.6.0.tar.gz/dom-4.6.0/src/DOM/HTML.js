/* global window */
"use strict";

exports.window = function () {
  return window;
};
