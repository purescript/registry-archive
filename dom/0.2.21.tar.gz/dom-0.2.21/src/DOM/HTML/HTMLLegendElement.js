/* global exports */
"use strict";

// module DOM.HTML.HTMLLegendElement

exports.form = function (le) {
  return function () {
    return le.form;
  };
};
