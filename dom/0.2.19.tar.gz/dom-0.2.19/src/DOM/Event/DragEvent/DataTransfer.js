// module DOM.Event.DragEvent.DataTransfer

exports.files = function(dataTransfer) {
  return dataTransfer.files;
}
