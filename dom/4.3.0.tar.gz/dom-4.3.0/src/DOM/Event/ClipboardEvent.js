"use strict";

exports.clipboardData = function (e) {
  return e.clipboardData;
};
