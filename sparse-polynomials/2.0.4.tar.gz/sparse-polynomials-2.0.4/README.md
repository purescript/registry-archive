# purescript-sparse-polynomials

A library to do various computations with sparse polynomials like

* usual computations using univariate polynomials,
* multivariate polynomials, or
* numeric roots of real univariate polynomials


## Documentation on Pursuit

https://pursuit.purescript.org/packages/purescript-sparse-polynomials