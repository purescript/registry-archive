# purescript-freedom-portal

[![Latest release](http://img.shields.io/github/release/purescript-freedom/purescript-freedom-portal.svg)](https://github.com/purescript-freedom/purescript-freedom-portal/releases)

A way to render children into a node that exists outside the DOM hierarchy of the parent node.

[Demo](https://purescript-freedom.github.io/purescript-freedom-portal/)

## Installation

```
bower install purescript-freedom-portal
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-freedom-portal).

## LICENSE

MIT
