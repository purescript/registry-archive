# purescript-record-extra-srghma

this repo includes functions from:
- https://github.com/justinwoo/purescript-record-extra
- https://github.com/matthewleon/purescript-homogeneous-records/pull/1 (because this repo in unmaintained)
- some additional functions
