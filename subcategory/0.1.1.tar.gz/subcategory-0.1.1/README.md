# purescript-subcategory

Collection of typeclasses describing unwide subcategories of the default PureScript category 'Functor'

## Installation

```
bower install purescript-subcategory
```
