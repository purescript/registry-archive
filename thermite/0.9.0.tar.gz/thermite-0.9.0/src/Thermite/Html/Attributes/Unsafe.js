/* global exports */
"use strict";

// module Thermite.Html.Attributes.Unsafe

exports.styleUnsafe = function(a) {
  return a;
};