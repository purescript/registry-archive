# Halogen SVG

A collection of SVG elements for Halogen.

## Contributing

Contributions of or requests for additional elements and properties are welcome!
