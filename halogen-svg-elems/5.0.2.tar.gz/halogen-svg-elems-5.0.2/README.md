# Halogen SVG

A collection of SVG elements for Halogen.

## Contributing

Contributions of or requests for additional elements and properties are welcome!

To test and verify that everything displays properly, do the following:

1. Run `spago install`
2. Run `npm test`
3. Open `dist/test.html`
