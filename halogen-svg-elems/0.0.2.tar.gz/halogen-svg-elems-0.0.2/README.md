# Halogen SVG

A collection of SVG elements for Halogen.

## Contributing

This is currently **proof-of-concept**, and not suitable for production use.

Contributions of additional elements and properties are welcome!
