# purescript-painting

A canvas rendering library using a declarative ADT to describe writing to and reading from a canvas. It is heavily inspired by [`purescript-drawing`](https://github.com/paf31/purescript-drawing).
