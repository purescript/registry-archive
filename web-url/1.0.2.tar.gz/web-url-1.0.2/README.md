# PureScript Web URL

FFI for the Web URL API (encode and decode URL's): https://developer.mozilla.org/en-US/docs/Web/API/URL
