# purescript-random

[![Build Status](https://travis-ci.org/purescript/purescript-random.svg?branch=master)](https://travis-ci.org/purescript/purescript-random)

Random value generation.

## Installation

```
bower install purescript-random
```

## Module documentation

- [Control.Monad.Eff.Random](docs/Control.Monad.Eff.Random.md)
