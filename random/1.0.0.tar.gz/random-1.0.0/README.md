# purescript-random

[![Latest release](http://img.shields.io/bower/v/purescript-random.svg)](https://github.com/purescript/purescript-random/releases)
[![Build Status](https://travis-ci.org/purescript/purescript-random.svg?branch=master)](https://travis-ci.org/purescript/purescript-random)
[![Dependency Status](https://www.versioneye.com/user/projects/55848c6736386100150003e4/badge.svg?style=flat)](https://www.versioneye.com/user/projects/55848c6736386100150003e4)

Random value generation.

## Installation

```
bower install purescript-random
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-random).
