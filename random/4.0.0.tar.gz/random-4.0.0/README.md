# purescript-random

[![Latest release](http://img.shields.io/github/release/purescript/purescript-random.svg)](https://github.com/purescript/purescript-random/releases)
[![Build status](https://travis-ci.org/purescript/purescript-random.svg?branch=master)](https://travis-ci.org/purescript/purescript-random)

Random value generation.

## Installation

```
bower install purescript-random
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-random).
