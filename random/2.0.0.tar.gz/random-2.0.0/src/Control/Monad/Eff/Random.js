"use strict";

exports.random = Math.random;
