# purescript-random

[![Latest release](http://img.shields.io/github/release/purescript/purescript-random.svg)](https://github.com/purescript/purescript-random/releases)
[![Build status](https://github.com/purescript/purescript-random/workflows/CI/badge.svg?branch=master)](https://github.com/purescript/purescript-random/actions?query=workflow%3ACI+branch%3Amaster)
[![Pursuit](https://pursuit.purescript.org/packages/purescript-random/badge)](https://pursuit.purescript.org/packages/purescript-random)

Random value generation.

## Installation

```
spago install random
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-random).
