export const random = Math.random;
