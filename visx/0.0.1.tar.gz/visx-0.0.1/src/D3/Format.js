import * as d3Format from "d3-format";

export const format = d3Format.format;
