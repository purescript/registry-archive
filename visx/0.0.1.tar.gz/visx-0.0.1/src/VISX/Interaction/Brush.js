import { Brush } from "@visx/brush";

export const brushImpl = Brush;
