import { Threshold } from "@visx/threshold";

export const thresholdImpl = Threshold;
