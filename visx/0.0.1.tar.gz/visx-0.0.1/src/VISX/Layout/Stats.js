import { BoxPlot, ViolinPlot } from "@visx/stats";

export const boxPlotImpl = BoxPlot;
export const violinPlotImpl = ViolinPlot;
