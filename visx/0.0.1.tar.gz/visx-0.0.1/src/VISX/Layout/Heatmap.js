import { HeatmapRect, HeatmapCircle } from "@visx/heatmap";

export const heatmapRectImpl = HeatmapRect;
export const heatmapCircleImpl = HeatmapCircle;
