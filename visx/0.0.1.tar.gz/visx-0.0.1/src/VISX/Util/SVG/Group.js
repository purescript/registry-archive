import { Group } from "@visx/group"

export const groupImpl = Group