import { localPoint } from "@visx/event";

export const localPointImpl = localPoint;
