import { letterFrequency } from "@visx/mock-data";

export const letterFrequency = letterFrequency;
