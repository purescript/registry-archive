import * as visxPattern from "@visx/pattern"

export const pattern = visxPattern.Pattern
export const patternLinesImpl = visxPattern.PatternLines
export const patternCirclesImpl = visxPattern.PatternCircles
export const patternWavesImpl = visxPattern.PatternWaves
export const patternHexagonsImpl = visxPattern.PatternHexagons
export const patternPathImpl = visxPattern.PatternPath
