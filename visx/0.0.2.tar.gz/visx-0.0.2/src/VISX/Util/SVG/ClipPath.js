import { RectClipPath, CircleClipPath } from "@visx/clip-path";

export const rectClipPathImpl = RectClipPath;
export const circleClipPathImpl = CircleClipPath;
