import { Graph, Nodes, Links, DefaultNode, DefaultLinks } from "@visx/network";

export const graphImpl = Graph;
export const nodesImpl = Nodes;
export const linksImpl = Links;
export const defaultNodeImpl = DefaultNode;
export const defaultLinksImpl = DefaultLinks;
