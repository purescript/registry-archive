import { Axis, AxisBottom, AxisLeft, AxisRight, AxisTop } from "@visx/axis"

export const axisImpl = Axis
export const axisBottomImpl = AxisBottom
export const axisLeftImpl = AxisLeft
export const axisRightImpl = AxisRight
export const axisTopImpl = AxisTop
