import { Zoom } from "@visx/zoom";

export const zoomImpl = Zoom;
