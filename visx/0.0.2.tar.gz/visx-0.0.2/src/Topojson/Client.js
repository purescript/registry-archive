import { feature } from "topojson-client";

export const featureImpl = feature;
