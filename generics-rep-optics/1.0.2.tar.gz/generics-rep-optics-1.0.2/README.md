# purescript-generics-rep-optics

[![Build status](https://travis-ci.org/LiamGoodacre/purescript-generics-rep-optics.svg?branch=master)](https://travis-ci.org/LiamGoodacre/purescript-generics-rep-optics)

Generating optics for generic data types.

Check out [test/Main](test/Main.purs) for examples.

## Installation

```
bower install purescript-generics-rep-optics
```

## Documentation

See on [Pursuit](https://pursuit.purescript.org/packages/purescript-generics-rep-optics/).

Or build docs with `npm run build:docs`.
