# purescript-refty

[![Latest release](http://img.shields.io/github/release/oreshinya/purescript-refty.svg)](https://github.com/oreshinya/purescript-refty/releases)

JSON encoder for api responses.

## Installation

```
bower install purescript-refty
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-refty).

## LICENSE

MIT
