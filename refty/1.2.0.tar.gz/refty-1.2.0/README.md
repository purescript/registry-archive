# purescript-refty

[![Latest release](http://img.shields.io/github/release/oreshinya/purescript-refty.svg)](https://github.com/oreshinya/purescript-refty/releases)

Formatted JSON generator for API server inspired by normalizr.
Reference + Entity = Refty ♡

## Installation

```
bower install purescript-refty
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-refty).

## LICENSE

MIT
