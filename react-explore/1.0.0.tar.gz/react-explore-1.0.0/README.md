# purescript-react-explore

Experiments with comonads for modelling React UIs, based on the upcoming paper
"Declarative UIs are the Future --- And the Future is Comonadic!"

- [Module Documentation](generated-docs/React/)
- [Example](test/Main.purs)
