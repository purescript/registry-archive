# purescript-freedom-router

[![Latest release](http://img.shields.io/github/release/purescript-freedom/purescript-freedom-router.svg)](https://github.com/purescript-freedom/purescript-freedom-router/releases)

Router subscription for [purescript-freedom](https://github.com/purescript-freedom/purescript-freedom).

## Installation

```
bower install purescript-freedom-router
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-freedom-router).

## LICENSE

MIT
