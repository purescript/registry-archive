# purescript-typelevel-prelude

[![Latest release](http://img.shields.io/github/release/purescript/purescript-typelevel-prelude.svg)](https://github.com/purescript/purescript-typelevel-prelude/releases)
[![Build status](https://travis-ci.org/purescript/purescript-typelevel-prelude.svg?branch=master)](https://travis-ci.org/purescript/purescript-typelevel-prelude)

Types and kinds for basic type-level programming, for PureScript >= v0.10.5.

## Installation

```
bower install purescript-typelevel-prelude
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-typelevel-prelude).
