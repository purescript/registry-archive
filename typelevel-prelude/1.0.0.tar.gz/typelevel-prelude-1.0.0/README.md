# purescript-typelevel-prelude

[![Build Status](https://travis-ci.org/purescript/purescript-typelevel-prelude.svg?branch=master)](https://travis-ci.org/purescript/purescript-typelevel-prelude)

Types and kinds for basic type-level programming

_Note_: this library is a work in progress, and depends on compiler features which have not been officially released yet.

## Installation

```
bower install purescript-typelevel-prelude
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-typelevel-prelude).
