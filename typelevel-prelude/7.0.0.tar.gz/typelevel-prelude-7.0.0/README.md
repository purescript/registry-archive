# purescript-typelevel-prelude

[![Latest release](http://img.shields.io/github/release/purescript/purescript-typelevel-prelude.svg)](https://github.com/purescript/purescript-typelevel-prelude/releases)
[![Build status](https://github.com/purescript/purescript-typelevel-prelude/workflows/CI/badge.svg?branch=master)](https://github.com/purescript/purescript-typelevel-prelude/actions?query=workflow%3ACI+branch%3Amaster)
[![Pursuit](https://pursuit.purescript.org/packages/purescript-typelevel-prelude/badge)](https://pursuit.purescript.org/packages/purescript-typelevel-prelude)

Types and kinds for basic type-level programming.

## Installation

```
spago install typelevel-prelude
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-typelevel-prelude).
