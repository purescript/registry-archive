# purescript-run-supply

## Motivation

Sometimes, we want to have a supply of values.
A place where unique values comes up frequently is in code generation.
Another is using de Bruijn indices.

There are many places where a supply of values is useful

## Why [run][]?

We're going down the [run][] rabbit-hole with this package as well.
[run][] allows us to interleave effects more straight-forwardly than other approaches.

[run]: https://github.com/natefaubion/purescript-run
