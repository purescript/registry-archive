# purescript-float32

This data type is just a wrapper around `Number`, where
entering into the type can only be done with `Math.fround()`.

It supports all of the features of `Number`.
