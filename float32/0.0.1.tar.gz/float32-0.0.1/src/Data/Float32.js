"use strict";

exports.fromNumber = function fromNumber (x) {
    return Math.fround(x);
};
