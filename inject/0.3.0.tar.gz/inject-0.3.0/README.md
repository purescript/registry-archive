# purescript-inject

[![Build Status](https://travis-ci.org/purescript/purescript-inject.svg?branch=master)](https://travis-ci.org/purescript/purescript-inject)

Inject typeclass.

## Installation

```
bower install purescript-inject
```

## Module documentation

- [Data.Inject](docs/Data.Inject.md)
