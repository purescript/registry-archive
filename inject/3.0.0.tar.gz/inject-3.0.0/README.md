# purescript-inject

[![Latest release](http://img.shields.io/bower/v/purescript-inject.svg)](https://github.com/purescript/purescript-inject/releases)
[![Build Status](https://travis-ci.org/purescript/purescript-inject.svg?branch=master)](https://travis-ci.org/purescript/purescript-inject)
[![Dependency Status](https://www.versioneye.com/user/projects/55848cb436386100150003fe/badge.svg?style=flat)](https://www.versioneye.com/user/projects/55848cb436386100150003fe)

Inject typeclass.

## Installation

```
bower install purescript-inject
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-inject).
