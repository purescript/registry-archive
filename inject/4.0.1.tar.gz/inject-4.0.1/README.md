# DEPRECATED

The library is no longer maintained under this repository. An `Inject` class now exists in [`purescript-functors`](https://github.com/purescript/purescript-functors), for `Coproduct`, and another in [`purescript-either`](https://github.com/purescript/purescript-either), for `Either`.

[The previous releases](https://github.com/purescript-deprecated/purescript-inject/releases) will continue to work for older libraries that still depend on them.


