# purescript-inject

[![Latest release](http://img.shields.io/github/release/purescript/purescript-inject.svg)](https://github.com/purescript/purescript-inject/releases)
[![Build status](https://travis-ci.org/purescript/purescript-inject.svg?branch=master)](https://travis-ci.org/purescript/purescript-inject)

Inject typeclass.

## Installation

```
bower install purescript-inject
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-inject).
