"use strict";

export function _toLocaleString(locales, options, date) {
  return date.toLocaleString(locales, options);
}

export function _toLocaleDateString(locales, options, date) {
  return date.toLocaleDateString(locales, options);
}

export function _toLocaleTimeString(locales, options, date) {
  return date.toLocaleTimeString(locales, options);
}
