"use strict";

export function _toLocaleString(locales, options, number) {
  return number.toLocaleString(locales, options);
}
