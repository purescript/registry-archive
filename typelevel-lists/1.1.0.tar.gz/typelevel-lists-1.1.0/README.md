# purescript-typelevel-lists
Type-level heterogenous list of kinds for PureScript.

## Documentation
Documentation is published in [Pursuit](https://pursuit.purescript.org/packages/purescript-typelevel-lists).

## Examples
Examples can be found in the [examples](./examples) directory.

## Installation
```sh
$ spago install typelevel-lists
```
