# purescript-typelevel-lists
Type-level list of kinds for PureScript.

## Documentation
* Module documentation is published in [Pursuit](https://pursuit.purescript.org/packages/purescript-typelevel-lists).
* Changes per release are listed on [CHANGELOG.md](/CHANGELOG.md).
* Example code can be found in the [test](./test) directory.

## Installation
```sh
$ spago install typelevel-lists
```
