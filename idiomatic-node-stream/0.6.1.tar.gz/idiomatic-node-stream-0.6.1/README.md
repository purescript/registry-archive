# purescript-idiomatic-node-stream
An idiomatic wrapper for Node's Stream API.
