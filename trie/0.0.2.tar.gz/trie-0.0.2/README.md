# purescript-trie

[![Build Status](https://travis-ci.org/paulyoung/purescript-trie.svg?branch=master)](https://travis-ci.org/paulyoung/purescript-trie)

A trie implementation in PureScript.
