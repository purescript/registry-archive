# purescript-string-parsers

A parsing library for parsing strings.

This library is a simpler, faster alternative to `purescript-parsing`, for when you know your input will be a string.

## Installing

    bower i purescript-string-parsers

- [Module Documentation](docs/)
