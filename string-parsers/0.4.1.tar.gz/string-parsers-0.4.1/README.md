# purescript-string-parsers

A parsing library for parsing strings

