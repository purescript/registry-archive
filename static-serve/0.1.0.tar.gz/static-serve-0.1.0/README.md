# purescript-static-serve

[![Latest release](http://img.shields.io/github/release/oreshinya/purescript-static-serve.svg)](https://github.com/oreshinya/purescript-static-serve/releases)

Serve static files.

See [example](https://github.com/oreshinya/purescript-static-serve/blob/master/example/Main.purs).

## Installation

```
bower install purescript-static-serve
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-static-serve).

## LICENSE

MIT
