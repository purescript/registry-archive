'use strict';

exports.code = function(e) {
  return e.code;
}
