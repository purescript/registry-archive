# purescript-line-reader

[![Latest release](http://img.shields.io/bower/v/purescript-line-reader.svg)](https://github.com/ChrisPenner/purescript-line-reader/releases)
[![Build Status](https://travis-ci.org/ChrisPenner/purescript-line-reader.svg?branch=master)](https://travis-ci.org/purescript/purescript-line-reader)

## Installation

```
bower install purescript-line-reader
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-line-reader).
