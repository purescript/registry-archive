# purescript-api-helpers

![API Helpers Mascot](/assets/mascot.jpg?raw=true "API Helpers Mascot")

Just some API helpers. Used primarily in my haskell-interop-prime project.

## Installation

```
bower install purescript-api-helpers
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-api-helpers).
