/* global exports */
"use strict";

// module Elm.Char

exports.toLocaleUpper = function (c) {
    return c.toLocaleUpperCase();
};

exports.toLocaleLower = function (c) {
    return c.toLocaleLowerCase();
};
