/* global exports */
"use strict";

// module Elm.Basics

exports.truncate = function (num) {
    return num | 0;
}
