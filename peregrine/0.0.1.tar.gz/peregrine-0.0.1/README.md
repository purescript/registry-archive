# Peregrine

A fast web framework for PureScript.
