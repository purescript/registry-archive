# purescript-undefined
The undefined value.
