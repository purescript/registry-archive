# purescript-mmorph [![Build Status](https://travis-ci.org/Thimoteus/purescript-mmorph.svg?branch=master)](https://travis-ci.org/Thimoteus/purescript-mmorph)

This library is a port of Haskell's `mmorph` [package](http://hackage.haskell.org/package/mmorph-1.0.0/docs/Control-Monad-Morph.html).

## Installation

`bower install Thimoteus/purescript-mmorph`

## Documentation
[Control.Monad.Morph](docs/Control/Monad/Morph.md)

