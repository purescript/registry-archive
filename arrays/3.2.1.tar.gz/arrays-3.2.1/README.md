# purescript-arrays

[![Latest release](http://img.shields.io/github/release/purescript/purescript-arrays.svg)](https://github.com/purescript/purescript-arrays/releases)
[![Build status](https://travis-ci.org/purescript/purescript-arrays.svg?branch=master)](https://travis-ci.org/purescript/purescript-arrays)

Utility functions for the `Array` type - JavaScript's native arrays.

## Installation

```
bower install purescript-arrays
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-arrays).
