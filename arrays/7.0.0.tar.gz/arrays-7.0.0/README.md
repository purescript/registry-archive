# purescript-arrays

[![Latest release](http://img.shields.io/github/release/purescript/purescript-arrays.svg)](https://github.com/purescript/purescript-arrays/releases)
[![Build status](https://github.com/purescript/purescript-arrays/workflows/CI/badge.svg?branch=master)](https://github.com/purescript/purescript-arrays/actions?query=workflow%3ACI+branch%3Amaster)
[![Pursuit](https://pursuit.purescript.org/packages/purescript-arrays/badge)](https://pursuit.purescript.org/packages/purescript-arrays)

Utility functions for the `Array` type - JavaScript's native arrays.

## Installation

```
spago install arrays
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-arrays).
