# purescript-functor-optics

Optics between functors

Docs are available on [Pursuit](https://pursuit.purescript.org/packages/purescript-functor-optics).
