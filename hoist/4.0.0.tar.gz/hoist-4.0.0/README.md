# purescript-hoist

Hoisting natural transformations

Docs are available on [Pursuit](https://pursuit.purescript.org/packages/purescript-hoist).
