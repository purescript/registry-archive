# purescript-glitter

Easy interactive testing of parsers, with the magic of [purescript-sparkle](https://github.com/sharkdp/purescript-sparkle).