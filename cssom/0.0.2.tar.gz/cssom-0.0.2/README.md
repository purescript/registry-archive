# Purescript CSSOM

Types etc for dealing with stylesheets in Purescript: https://developer.mozilla.org/en-US/docs/Web/API/CSS_Object_Model
