# purescript-halogen-bootstrap4

Bootstrap 4 classes and utilities for `purescript-halogen`.

## Installation

```
bower install purescript-halogen-bootstrap4
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-halogen-bootstrap4).
