## Cirru EDN on PureScript

### Usages

_TODO_

```purs
parseCirruEdn "[] 1 2 3 4"
writeCirruEdn edn
```

[More on Pursuit](https://pursuit.purescript.org/packages/purescript-cirru-edn/).

### License

MIT
