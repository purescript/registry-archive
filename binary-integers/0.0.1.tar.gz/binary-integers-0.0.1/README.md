# purescript-binary-integers
[Un]sized [Un]signed integer types on top of purescript-binary

[![Build Status](https://travis-ci.org/Unisay/purescript-binary-integers.svg?branch=master)](https://travis-ci.org/Unisay/purescript-binary-integers)

Work in progress
