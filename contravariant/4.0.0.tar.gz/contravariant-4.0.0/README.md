# purescript-contravariant

[![Latest release](http://img.shields.io/github/release/purescript/purescript-contravariant.svg)](https://github.com/purescript/purescript-contravariant/releases)
[![Build status](https://travis-ci.org/purescript/purescript-contravariant.svg?branch=master)](https://travis-ci.org/purescript/purescript-contravariant)

Contravariant functors.

## Installation

```
bower install purescript-contravariant
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-contravariant).
