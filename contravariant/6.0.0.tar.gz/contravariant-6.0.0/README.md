# purescript-contravariant

[![Latest release](http://img.shields.io/github/release/purescript/purescript-contravariant.svg)](https://github.com/purescript/purescript-contravariant/releases)
[![Build status](https://github.com/purescript/purescript-contravariant/workflows/CI/badge.svg?branch=master)](https://github.com/purescript/purescript-contravariant/actions?query=workflow%3ACI+branch%3Amaster)
[![Pursuit](https://pursuit.purescript.org/packages/purescript-contravariant/badge)](https://pursuit.purescript.org/packages/purescript-contravariant)

Contravariant functors.

## Installation

```
spago install contravariant
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-contravariant).
