PureScript Contravariant
========================

PureScript Contravariant type class.
