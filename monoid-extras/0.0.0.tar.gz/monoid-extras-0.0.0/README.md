# purescript-monoid-extras

[![Build Status](https://secure.travis-ci.org/diagrams/monoid-extras.png)](http://travis-ci.org/diagrams/monoid-extras)

A direct port of Haskell's `monoid-extras`.