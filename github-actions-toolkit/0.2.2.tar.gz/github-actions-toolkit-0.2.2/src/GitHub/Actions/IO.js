"use strict";
const io = require("@actions/io");

exports.cp2Impl = io.cp;

exports.cp3Impl = io.cp;

exports.mv2Impl = io.mv;

exports.mv3Impl = io.mv;

exports.rmRFImpl = io.rmRF;

exports.mkdirPImpl = io.mkdirP;

exports.which2Impl = io.which;

exports.which3Impl = io.which;
