import io from "@actions/io";
export const cp2Impl = io.cp;
export const cp3Impl = io.cp;
export const mv2Impl = io.mv;
export const mv3Impl = io.mv;
export const rmRFImpl = io.rmRF;
export const mkdirPImpl = io.mkdirP;
export const which2Impl = io.which;
export const which3Impl = io.which;
