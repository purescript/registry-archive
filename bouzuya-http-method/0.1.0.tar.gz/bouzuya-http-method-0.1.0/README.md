# purescript-bouzuya-http-method

[![Build Status](https://img.shields.io/travis/bouzuya/purescript-bouzuya-http-method.svg)](https://travis-ci.org/bouzuya/purescript-bouzuya-http-method)

HTTP method.
