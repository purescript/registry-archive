# purescript-bouzuya-http-method

HTTP method.

## Badge

[![Travis CI][travis-ci-badge]][travis-ci]
[![Bower][bower-badge]][bower]

[bower]: https://github.com/bouzuya/purescript-bouzuya-http-method
[bower-badge]: https://img.shields.io/bower/v/purescript-bouzuya-http-method.svg
[travis-ci]: https://travis-ci.org/bouzuya/purescript-bouzuya-http-method
[travis-ci-badge]: https://img.shields.io/travis/bouzuya/purescript-bouzuya-http-method.svg

## Installation

```
bower install purescript-bouzuya-http-method
```

## How to build

See: [`.travis.yml`](.travis.yml).
