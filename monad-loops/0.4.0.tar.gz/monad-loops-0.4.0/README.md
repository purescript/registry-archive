# purescript-monad-loops

A collection of monadic loop operators inspired by the Haskell monad-loops package.

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-monad-loops).

