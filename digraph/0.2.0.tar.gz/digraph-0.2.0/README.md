# purescript-digraph

[![Build Status](https://travis-ci.org/nullobject/purescript-digraph.svg?branch=master)](https://travis-ci.org/nullobject/purescript-digraph)

A directed graph library for PureScript.

## API

[Data.Graph](https://pursuit.purescript.org/packages/purescript-digraph)
