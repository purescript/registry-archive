# purescript-dgraph

A directed graph library for PureScript.
