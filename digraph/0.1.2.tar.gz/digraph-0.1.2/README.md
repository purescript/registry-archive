# purescript-digraph

A directed graph library for PureScript.

## API

[Data.Graph](https://pursuit.purescript.org/packages/purescript-digraph/0.1.2/docs/Data.Graph)
