# purescript-ui

This library is an experiment in using final interpreters to describe UI's.

See the example directory of some usages.
