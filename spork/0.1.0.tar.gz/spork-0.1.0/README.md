# purescript-spork

An Elm-like for PureScript. No `npm` dependencies required.

## TODO

*   Needs docs
*   Needs subscription examples
*   Refine the interpreter story
