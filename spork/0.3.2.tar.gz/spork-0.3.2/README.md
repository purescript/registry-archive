# purescript-spork

[![Latest release](http://img.shields.io/github/release/natefaubion/purescript-spork.svg)](https://github.com/natefaubion/purescript-spork/releases)
[![Build status](https://travis-ci.org/natefaubion/purescript-spork.svg?branch=master)](https://travis-ci.org/natefaubion/purescript-spork)

An Elm-like for PureScript. No `npm` dependencies required.

## Install

```
bower install purescript-spork
```

## Documentation

- Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-spork).


