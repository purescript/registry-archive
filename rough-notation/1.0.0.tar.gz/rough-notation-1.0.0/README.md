### To compile:
`npm install && npm run build`

### Running tests
`npm run tests` builds `test/script.js`
Open `test/index.html` in a browser