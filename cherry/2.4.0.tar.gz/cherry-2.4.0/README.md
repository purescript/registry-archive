# purescript-cherry

[![Latest release](http://img.shields.io/github/release/oreshinya/purescript-cherry.svg)](https://github.com/oreshinya/purescript-cherry/releases)

Simple PureScript application framework. see [example](https://github.com/oreshinya/purescript-cherry/blob/master/example/Main.purs).

## Installation

```
bower install purescript-cherry
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-cherry).

## LICENSE

MIT
