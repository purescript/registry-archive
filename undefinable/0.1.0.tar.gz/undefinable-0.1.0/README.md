# purescript-undefinable

A library for handling `undefined` values.

## Installation

```bash
bower install --save purescript-undefinable
```
