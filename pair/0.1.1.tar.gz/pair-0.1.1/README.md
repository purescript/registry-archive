# `purescript-pair`

A module defining a pair of objects of the same type.
