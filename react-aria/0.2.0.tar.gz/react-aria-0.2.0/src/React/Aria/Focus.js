import { FocusRing, FocusScope, useFocusRing } from "@react-aria/focus"

export const focusRingImpl = FocusRing
export const focusScopeImpl = FocusScope
export const useFocusRingImpl = useFocusRing
