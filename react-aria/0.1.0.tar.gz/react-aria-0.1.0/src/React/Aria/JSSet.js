export const toArray = Array.from
export function fromArray(arr) {
  return new Set(arr)
}
