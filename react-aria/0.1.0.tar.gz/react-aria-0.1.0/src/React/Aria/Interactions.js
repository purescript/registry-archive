import { useFocusWithin, useFocus } from "@react-aria/interactions"

export const useFocusWithinImpl = useFocusWithin
export const useFocusImpl = useFocus
