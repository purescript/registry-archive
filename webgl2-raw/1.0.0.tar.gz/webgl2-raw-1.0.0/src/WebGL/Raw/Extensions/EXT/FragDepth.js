"use strict";

exports.js_getExtensionEXT_frag_depth = function (gl) {
  return gl.getExtension("EXT_frag_depth");
};