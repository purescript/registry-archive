"use strict";

exports.js_getExtensionEXT_sRGB = function (gl) {
  return gl.getExtension("EXT_sRGB");
};