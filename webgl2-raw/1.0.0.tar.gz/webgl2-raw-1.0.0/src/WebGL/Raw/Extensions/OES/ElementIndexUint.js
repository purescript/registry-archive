"use strict";

exports.js_getExtensionOES_element_index_uint = function (gl) {
  return gl.getExtension("OES_element_index_uint");
};