"use strict";

exports.js_getExtensionOES_standard_derivatives = function (gl) {
  return gl.getExtension("OES_standard_derivatives");
};