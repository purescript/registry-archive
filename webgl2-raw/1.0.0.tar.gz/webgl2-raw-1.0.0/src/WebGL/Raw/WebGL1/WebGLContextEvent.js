"use strict";

exports.js_getStatusMessage = function (webglcontextevent) {
  return webglcontextevent.statusMessage;
};