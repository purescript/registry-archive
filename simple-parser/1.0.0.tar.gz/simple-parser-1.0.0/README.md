# purescript-simple-parser [![Build Status](https://travis-ci.org/Thimoteus/purescript-string-parsers.svg?branch=master)](https://travis-ci.org/Thimoteus/purescript-string-parsers)

A simple parsing library.

You may prefer [purescript-string-parsers](https://github.com/paf31/purescript-string-parsers)
or [purescript-parsing](https://github.com/purescript-contrib/purescript-parsing)
if you want fancy features, like error messages when your parsers fail.

## Installing

    bower i purescript-simple-parser

- [Module Documentation](docs/)
