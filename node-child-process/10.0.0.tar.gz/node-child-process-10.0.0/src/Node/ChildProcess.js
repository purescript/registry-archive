const _undefined = undefined;
export { _undefined as undefined };
