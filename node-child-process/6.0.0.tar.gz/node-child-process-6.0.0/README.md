# purescript-node-child-process

[![Latest release](http://img.shields.io/github/release/purescript-node/purescript-node-child-process.svg)](https://github.com/purescript/purescript-node-child-process/releases)
[![Build Status](https://travis-ci.org/purescript-node/purescript-node-child-process.svg?branch=master)](https://travis-ci.org/purescript-node/purescript-node-child-process)

Bindings to Node's `child_process` API.

## Installation

```
bower install purescript-node-child-process
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-node-child-process).
