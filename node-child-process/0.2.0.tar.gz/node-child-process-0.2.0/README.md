# purescript-node-child-process

Bindings to Node's `child_process` API.

## Module documentation

* [Node.ChildProcess](docs/Node/ChildProcess.md)
* [Node.ChildProcess.Signal](docs/Node/ChildProcess/Signal.md)
