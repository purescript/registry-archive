# purescript-node-child-process

Bindings to Node's `child_process` API.

Documentation is [on Pursuit](http://pursuit.purescript.org/packages/purescript-node-child-process).
