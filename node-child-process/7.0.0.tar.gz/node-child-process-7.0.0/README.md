# purescript-node-child-process

[![Latest release](http://img.shields.io/github/release/purescript-node/purescript-node-child-process.svg)](https://github.com/purescript/purescript-node-child-process/releases)
[![Build status](https://github.com/purescript-node/purescript-node-child-process/workflows/CI/badge.svg?branch=master)](https://github.com/purescript-node/purescript-node-child-process/actions?query=workflow%3ACI+branch%3Amaster)
[![Pursuit](https://pursuit.purescript.org/packages/purescript-node-child-process/badge)](https://pursuit.purescript.org/packages/purescript-node-child-process)

Bindings to Node's `child_process` API.

## Installation

```
spago install node-child-process
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-node-child-process).
