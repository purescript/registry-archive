# purescript-exceptions

[![Latest release](http://img.shields.io/github/release/purescript/purescript-exceptions.svg)](https://github.com/purescript/purescript-exceptions/releases)
[![Build status](https://github.com/purescript/purescript-exceptions/workflows/CI/badge.svg?branch=master)](https://github.com/purescript/purescript-exceptions/actions?query=workflow%3ACI+branch%3Amaster)
[![Pursuit](https://pursuit.purescript.org/packages/purescript-exceptions/badge)](https://pursuit.purescript.org/packages/purescript-exceptions)

Exception effects.

## Installation

```
spago install exceptions
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-exceptions).
