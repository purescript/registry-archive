# purescript-exceptions

[![Build Status](https://travis-ci.org/purescript/purescript-exceptions.svg?branch=master)](https://travis-ci.org/purescript/purescript-exceptions)

Exception effects.

## Installation

```
bower install purescript-exceptions
```

## Module documentation

- [Control.Monad.Eff.Exception](docs/Control.Monad.Eff.Exception.md)
