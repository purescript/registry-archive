# purescript-exceptions

[![Latest release](http://img.shields.io/bower/v/purescript-exceptions.svg)](https://github.com/purescript/purescript-exceptions/releases)
[![Build Status](https://travis-ci.org/purescript/purescript-exceptions.svg?branch=master)](https://travis-ci.org/purescript/purescript-exceptions)
[![Dependency Status](https://www.versioneye.com/user/projects/55848c6b363861001b000198/badge.svg?style=flat)](https://www.versioneye.com/user/projects/55848c6b363861001b000198)

Exception effects.

## Installation

```
bower install purescript-exceptions
```

## Module documentation

- [Control.Monad.Eff.Exception](docs/Control/Monad/Eff/Exception.md)
