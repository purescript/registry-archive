export const envVars = {
  prefix: process.env.PREFIX || "",
  version: process.env.VERSION || "no-version",
};
