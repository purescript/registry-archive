# purescript-interactive-data.all

This is a mirror of the package [purescript-interactive-data](https://github.com/thought2/purescript-interactive-data).
However, all local package from the source repo are merged into a single package.
This is due to the fact that publishing local packages from monorepos is currently not supported.