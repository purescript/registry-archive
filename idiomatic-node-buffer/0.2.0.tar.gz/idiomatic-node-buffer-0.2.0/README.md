# purescript-idiomatic-node-buffer
An idiomatic wrapper for Node's Buffer API.
