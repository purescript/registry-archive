# purescript-crypt-nacl
[![Build status](https://travis-ci.org/throughnothing/purescript-crypt-nacl.svg?branch=master)](https://travis-ci.org/throughnothing/purescript-crypt-nacl)
[![Pursuit](https://pursuit.purescript.org/packages/purescript-crypt-nacl/badge)](https://pursuit.purescript.org/packages/purescript-crypt-nacl)

This module wraps [tweetnacl](https://github.com/dchest/tweetnacl-js), which is
a javascript re-implementation of the original
[TweetNaCl](http://tweetnacl.cr.yp.to).
