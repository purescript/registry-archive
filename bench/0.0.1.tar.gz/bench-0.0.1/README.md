# purescript-bench

Benchmarking library for PureScript.

## Example

You can find an example in `src/Main.purs`. The output of this example may be
the following chart:

![Example output][plot]

[plot]: https://raw.githubusercontent.com/rightfold/purescript-bench/master/doc/plot.png
