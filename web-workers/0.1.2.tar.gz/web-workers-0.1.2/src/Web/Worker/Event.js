export function data_(ev) {
  return ev.data; 
}

export function origin(ev) {
  return ev.origin; 
}

export function lastEventId(ev) {
  return ev.lastEventId;
}