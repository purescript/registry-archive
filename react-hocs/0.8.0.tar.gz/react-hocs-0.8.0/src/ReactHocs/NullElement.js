"use strict"

exports.nullElement = null
