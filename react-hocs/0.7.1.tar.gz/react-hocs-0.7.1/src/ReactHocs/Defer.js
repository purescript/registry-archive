"use strict"

exports.nullElement = null

exports.requestAnimationFrame = window.requestAnimationFrame
