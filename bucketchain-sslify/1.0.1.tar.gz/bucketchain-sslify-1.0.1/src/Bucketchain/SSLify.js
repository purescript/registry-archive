'use strict';

export function requestProtocol(req) {
  return req.socket.encrypted ? 'https' : 'http';
}
