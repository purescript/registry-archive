# purescript-bucketchain-sslify

[![Latest release](http://img.shields.io/github/release/Bucketchain/purescript-bucketchain-sslify.svg)](https://github.com/Bucketchain/purescript-bucketchain-sslify/releases)

A force https middleware of [Bucketchain](https://github.com/Bucketchain/purescript-bucketchain).

## Installation

### Bower

```
$ bower install purescript-bucketchain-sslify
```

### Spago

```
$ spago install bucketchain-sslify
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-bucketchain-sslify).

## LICENSE

MIT
