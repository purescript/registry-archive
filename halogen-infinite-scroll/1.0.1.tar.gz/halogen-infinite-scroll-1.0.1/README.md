# halogen-infinite-scroll

Infinite scroll implemented as a Halogen component.

Supports bi-directional scrolling (loading and unloading from above and below) via a pipes based API.

Excess content above and below the visible section of the feed is garbage collected from the DOM.

