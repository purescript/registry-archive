# purescript-sockjs-node
Purescript bindings for sockjs-node

## Installing
```
bower install --save purescript-sockjs-node
yarn add sockjs
```

## Example usage
See [example/ directory](https://github.com/FruitieX/purescript-sockjs-node/tree/master/example)
