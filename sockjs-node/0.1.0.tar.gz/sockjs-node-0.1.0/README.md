# purescript-sockjs-node
Purescript bindings for sockjs-node

## Installing
```
bower install --save purescript-sockjs-node
yarn add sockjs
```

## Example usage
See [example/ directory](/example)
