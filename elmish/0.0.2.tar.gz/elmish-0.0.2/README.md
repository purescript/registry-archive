# PureScript-Elmish
## A PureScript implementation of The Elm Architecture
______

More documentation is forthcoming