# PureScript-Elmish
## A PureScript implementation of The Elm Architecture

![build](https://github.com/collegevine/purescript-elmish/workflows/build/badge.svg?branch=master)

This library is a port of The Elm Architecture to PureScript with minimal fuss and transparent interop with React, including minimal-friction use of existing React components.
______

For some examples, see https://github.com/collegevine/purescript-elmish-examples

More documentation is forthcoming
