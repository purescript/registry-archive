exports.eqByReference = a => b => a === b
