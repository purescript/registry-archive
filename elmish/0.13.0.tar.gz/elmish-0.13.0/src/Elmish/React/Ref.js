export function eqByReference(a) {
  return b => a === b;
}
