export const getField_ = (field, obj) => obj[field]
export const setField_ = (field, value, obj) => obj[field] = value
