# PureScript-Elmish
## A PureScript implementation of The Elm Architecture

[![CircleCI](https://circleci.com/gh/collegevine/purescript-elmish.svg?style=svg)](https://circleci.com/gh/collegevine/purescript-elmish)

______

More documentation is forthcoming