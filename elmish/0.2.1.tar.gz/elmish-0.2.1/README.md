# PureScript-Elmish
## A PureScript implementation of The Elm Architecture

[![CircleCI](https://circleci.com/gh/collegevine/purescript-elmish.svg?style=svg)](https://circleci.com/gh/collegevine/purescript-elmish)

This library is a port of The Elm Architecture to PureScript with minimal fuss and transparent interop with React, including minimal-friction use of existing React components.
______

For some examples, see https://github.com/collegevine/purescript-elmish-examples

More documentation is forthcoming
