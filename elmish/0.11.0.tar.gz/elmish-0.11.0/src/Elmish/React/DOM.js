import { Fragment } from "react/index.js";
export var fragment_ = Fragment;
