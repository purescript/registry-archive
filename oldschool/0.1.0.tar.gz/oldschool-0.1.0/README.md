# purescript-oldschool

[![Pursuit](https://pursuit.purescript.org/packages/purescript-oldschool/badge)](https://pursuit.purescript.org/packages/purescript-oldschool)

Utilities pertaining to [Old School RuneScape](https://oldschool.runescape.com/).

## Installation

```
spago install oldschool
```
