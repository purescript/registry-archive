# purescript-vary

[![Latest release](http://img.shields.io/github/release/oreshinya/purescript-vary.svg)](https://github.com/oreshinya/purescript-vary/releases)

Manipulate the HTTP Vary header.

## Installation

```
bower install purescript-vary
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-vary).

## LICENSE

MIT
