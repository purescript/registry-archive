/* global exports */
"use strict";

// module Test.Spec.Runner

exports.dateNow = function () {
  return Date.now();
}
