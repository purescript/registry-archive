# purescript-pqueue

A priority queue library for PureScript.

## API

[Data.PQueue](https://pursuit.purescript.org/packages/purescript-pqueue/0.1.1/docs/Data.PQueue)
