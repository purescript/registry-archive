# purescript-pqueue

[![Build Status](https://travis-ci.org/nullobject/purescript-pqueue.svg?branch=master)](https://travis-ci.org/nullobject/purescript-pqueue)

A priority queue library for PureScript.

## API

[Data.PQueue](https://pursuit.purescript.org/packages/purescript-pqueue)
