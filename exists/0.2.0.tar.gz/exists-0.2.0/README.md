# purescript-exists

[![Build Status](https://travis-ci.org/purescript/purescript-exists.svg?branch=master)](https://travis-ci.org/purescript/purescript-exists)

Existential types as a library.

## Installation

```
bower install purescript-exists
```

## Module documentation

- [Data.Exists](docs/Data.Exists.md)
