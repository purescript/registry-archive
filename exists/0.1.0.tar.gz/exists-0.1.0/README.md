# purescript-exists

Existential types as a library

## Building

```
npm install
bower update
grunt
```
