# purescript-node-stream-buffers

[![License](https://img.shields.io/badge/license-MIT-blue.svg)](https://raw.githubusercontent.com/cprussin/purescript-node-stream-buffers/master/LICENSE)
[![Latest release](http://img.shields.io/github/release/cprussin/purescript-node-stream-buffers.svg)](https://github.com/cprussin/purescript-node-stream-buffers/releases)
[![Build Status](https://travis-ci.org/cprussin/purescript-node-stream-buffers.svg?branch=master)](https://travis-ci.org/cprussin/purescript-node-stream-buffers)

A wrapper for [stream-buffers](https://www.npmjs.com/package/stream-buffers).

## Installation

```bash
npm install stream-buffers
bower install purescript-node-stream-buffers
```

## Documentation

Module documentation
is
[published on Pursuit](http://pursuit.purescript.org/packages/purescript-node-stream-buffers).
