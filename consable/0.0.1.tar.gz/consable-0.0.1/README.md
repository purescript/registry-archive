# purescript-consable

![](https://img.shields.io/librariesio/github/8084/purescript-consable.svg)
[![Build status](https://travis-ci.org/8084/purescript-consable.svg?branch=master)](https://travis-ci.org/8084/purescript-consable)
