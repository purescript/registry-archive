# purescript-css

[![Latest release](http://img.shields.io/github/release/slamdata/purescript-css.svg)](https://github.com/slamdata/purescript-css/releases)
[![Build status](https://travis-ci.org/slamdata/purescript-css.svg?branch=master)](https://travis-ci.org/slamdata/purescript-css)

A type-safe library for describing, manipulating, and rendering CSS.

## Installation

```
bower install purescript-css
```

## Documentation

Module documentation is published on Pursuit: [http://pursuit.purescript.org/packages/purescript-css](http://pursuit.purescript.org/packages/purescript-css)
