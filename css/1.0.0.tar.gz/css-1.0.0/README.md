# purescript-css

[![Latest release](http://img.shields.io/bower/v/purescript-css.svg)](https://github.com/slamdata/purescript-css/releases)
[![Build Status](https://travis-ci.org/slamdata/purescript-css.svg?branch=master)](https://travis-ci.org/slamdata/purescript-css)
[![Dependency Status](https://www.versioneye.com/user/projects/564f5f32ff016c002c00052d/badge.svg?style=flat)](https://www.versioneye.com/user/projects/564f5f32ff016c002c00052d)

A type-safe library for describing, manipulating, and rendering CSS.

## Installation

```
bower install purescript-css
```

## Documentation

Module documentation is published on Pursuit: [http://pursuit.purescript.org/packages/purescript-css](http://pursuit.purescript.org/packages/purescript-css)
