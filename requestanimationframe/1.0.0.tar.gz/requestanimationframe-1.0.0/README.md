# Module Documentation

Exports a polyfilled `requestAnimationFrame` function.

- [Module Documentation](docs/DOM/RequestAnimationFrame.md)


