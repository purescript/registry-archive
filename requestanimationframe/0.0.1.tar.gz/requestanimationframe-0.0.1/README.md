# Module Documentation

[![Build Status](https://travis-ci.org/CapillarySoftware/purescript-requestAnimationFrame.svg)](https://travis-ci.org/CapillarySoftware/purescript-requestAnimationFrame)
[![Bower version](https://badge.fury.io/bo/purescript-requestanimationframe.svg)](http://badge.fury.io/bo/purescript-requestanimationframe)
[![Dependency Status](https://www.versioneye.com/user/projects/547239dd810106c65e000987/badge.svg?style=flat)](https://www.versioneye.com/user/projects/547239dd810106c65e000987)

## Module Control.RAF

### Types

    data RAF :: !


### Values

    requestAnimationFrame :: forall a e. Eff (raf :: RAF | e) a -> Eff (raf :: RAF | e) Unit



