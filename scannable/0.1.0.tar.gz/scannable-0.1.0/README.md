# purescript-scannable

[![Latest release](http://img.shields.io/github/release/Risto-Stevcev/purescript-scannable.svg)](https://github.com/Risto-Stevcev/purescript-scannable/releases)

A class for scannable data structures


## Installation

```
bower install purescript-scannable
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-scannable).
