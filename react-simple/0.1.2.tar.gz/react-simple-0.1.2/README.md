# purescript-react-simple

A simplified wrapper around react.

The goal of this fork is to make the use of React from PureScript much easier.

For the most part you can do a simple conversion from js or jsx code to ps code.

See the examples for a brief look at what things look like.
