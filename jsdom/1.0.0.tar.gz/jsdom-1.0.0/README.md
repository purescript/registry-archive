# purescript-jsdom

A PureScript interface to jsdom.

## Module documentation

- [DOM.JSDOM](docs/DOM/JSDOM.md)
