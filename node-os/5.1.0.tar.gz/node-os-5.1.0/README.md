# purescript-node-os 

Bindings for node's "os" module.

Documentation is available on [Pursuit](http://pursuit.purescript.org/packages/purescript-node-os).
