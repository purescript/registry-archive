# purescript-node-os [![Build Status](https://travis-ci.org/Thimoteus/purescript-node-os.svg?branch=master)](https://travis-ci.org/Thimoteus/purescript-node-os)

Bindings for node's "os" module.

Documentation is available on [Pursuit](http://pursuit.purescript.org/packages/purescript-node-os).
