# purescript-fft
Fast Fourier Transform in 1D or 2D
