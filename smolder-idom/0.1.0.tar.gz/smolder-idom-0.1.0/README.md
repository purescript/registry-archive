# purescript-smolder-idom

Smolder renderer for [Incremental DOM](https://github.com/google/incremental-dom).
