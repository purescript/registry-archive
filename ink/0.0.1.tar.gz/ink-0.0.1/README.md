# Purescript bindings for Ink

Some rough, incomplete Purescript bindings for [Ink](https://github.com/vadimdemedes/ink). See the [./examples](./examples/) directory for usage examples.

![menu-demo-gif-1](./menu-demo-gif-1.gif)
