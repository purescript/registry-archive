# purescript-tweetnacl
[![Pursuit](https://pursuit.purescript.org/packages/purescript-tweetnacl/badge)](https://pursuit.purescript.org/packages/purescript-tweetnacl)

This module wraps [tweetnacl](https://github.com/dchest/tweetnacl-js), which is
a javascript re-implementation of the original
[TweetNaCl](http://tweetnacl.cr.yp.to).


# Attribution

This module was originally released by William Wolf, [here](https://github.com/throughnothing/purescript-crypt-nacl)

Owing to inactivity on the part of the original author, this forked release has been created to carry support to 0.12.
