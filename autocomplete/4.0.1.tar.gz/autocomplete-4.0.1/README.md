# purescript-autocomplete [![Build Status](https://travis-ci.org/jane/purescript-autocomplete.svg?branch=master)](https://travis-ci.org/jane/purescript-autocomplete)

## Installation
`bower install purescript-autocomplete`

## Development
```
npm install
npm run build
```
Then use `npm test` to run test.

## Documentation
Module documentation on Pursuit: [purescript-autocomplete](https://pursuit.purescript.org/packages/purescript-autocomplete)
