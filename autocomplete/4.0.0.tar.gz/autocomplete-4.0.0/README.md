# purescript-autocomplete [![Build Status](https://travis-ci.org/jane/purescript-autocomplete.svg?branch=master)](https://travis-ci.org/jane/purescript-autocomplete)

Module documentation on Pursuit: [purescript-autocomplete](https://pursuit.purescript.org/packages/purescript-autocomplete)
