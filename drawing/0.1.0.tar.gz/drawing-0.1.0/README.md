purescript-drawing
==================

Functional rendering using PureScript and HTML 5 Canvas

![Snowflake](https://github.com/paf31/purescript-drawing/raw/master/Snowflake.png "Snowflake")
