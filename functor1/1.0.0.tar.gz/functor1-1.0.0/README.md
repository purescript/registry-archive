# purescript-functor1

[![Latest release](http://img.shields.io/github/release/garyb/purescript-functor1.svg)](https://github.com/garyb/purescript-functor1/releases)
[![Build Status](https://travis-ci.org/garyb/purescript-functor1.svg?branch=master)](https://travis-ci.org/garyb/purescript-functor1)

Functor (and related) classes for types of kind `(Type -> Type) -> Type`.

## Installation

```
bower install purescript-functor1
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-functor1).
