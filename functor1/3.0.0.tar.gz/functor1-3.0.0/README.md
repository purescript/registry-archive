# purescript-functor1

[![Latest release](http://img.shields.io/github/release/garyb/purescript-functor1.svg)](https://github.com/garyb/purescript-functor1/releases)
![Build Status](https://github.com/garyb/purescript-functor1/actions/workflows/ci.yml/badge.svg)

Functor (and related) classes for types of kind `(Type -> Type) -> Type`.

## Installation

```
bower install purescript-functor1
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-functor1).
