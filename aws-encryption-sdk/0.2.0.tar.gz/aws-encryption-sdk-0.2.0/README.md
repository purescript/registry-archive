# purescript-aws-encryption-sdk

Purescript wrapper for the aws-encryption-sdk. 

## Usage

See [test folder](./test/) for how to decrypt & encrypt.