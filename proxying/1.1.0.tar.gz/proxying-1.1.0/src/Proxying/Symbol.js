"use strict";

exports.unsafeCoerce = function (arg) {
  return arg;
};
