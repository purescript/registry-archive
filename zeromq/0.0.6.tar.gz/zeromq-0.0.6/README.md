# purescript-zeromq

Bindings to the [zeromq](https://github.com/zeromq/zeromq.js/) npm package, through [purescript-node-buffer](https://pursuit.purescript.org/packages/purescript-node-buffer).
