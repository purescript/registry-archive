export function code(e) {
  return e.code;
}

export function reason(e) {
  return e.reason;
}

export function wasClean(e) {
  return e.wasClean;
}
