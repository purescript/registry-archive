# purescript-web-socket

[![Latest release](http://img.shields.io/github/release/purescript-web/purescript-web-socket.svg)](https://github.com/purescript-web/purescript-web-socket/releases)
[![Build status](https://travis-ci.org/purescript-web/purescript-web-socket.svg?branch=master)](https://travis-ci.org/purescript-web/purescript-web-socket)

Type definitions and low level interface implementations for the W3C WebSocket API.

## Installation

```
bower install purescript-web-socket
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-web-socket).
