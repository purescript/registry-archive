# purescript-bound
Port of Edward Kmett's bound library to PureScript
