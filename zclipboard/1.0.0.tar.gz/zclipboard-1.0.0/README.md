# purescript-zclipboard

[![Latest release](http://img.shields.io/bower/v/purescript-zclipboard.svg)](https://github.com/slamdata/purescript-zclipboard/releases)
[![Build Status](https://travis-ci.org/slamdata/purescript-zclipboard.svg?branch=master)](https://travis-ci.org/slamdata/purescript-zclipboard)
[![Dependency Status](https://www.versioneye.com/user/projects/578e6d6588bf88002da4e50c/badge.svg?style=flat)](https://www.versioneye.com/user/projects/578e6d6588bf88002da4e50c)

Basic PureScript bindings for the [zeroclipboard](https://github.com/zeroclipboard/zeroclipboard) library.

## Installation

```
bower install purescript-zclipboard
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-zclipboard).
