# purescript-zclipboard
Very basic bindings to **zeroclipboard** library 
A micro clipboard library for PureScript

