# DEPRECATED

The library is no longer maintained. The compiler dropped support for deriving this style of `Generic` in v0.12, the newer style `Generic`s are available in [`purescript-generics-rep`](https://github.com/purescript/purescript-generics-rep).

[The previous releases](https://github.com/purescript-deprecated/purescript-generics/releases) will continue to work for older libraries that still depend on them.
