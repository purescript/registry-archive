# purescript-generics

Generic Programming.

- [Module Documentation](docs/Data/)
- [Example](test/Main.purs)

The methods in the `Generic` type class can be derived in versions >= 0.7.3 of the PureScript compiler. Simply omit their definitions to derive them.

