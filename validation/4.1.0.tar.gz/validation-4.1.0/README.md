# purescript-validation

[![Latest release](http://img.shields.io/github/release/purescript/purescript-validation.svg)](https://github.com/purescript/purescript-validation/releases)
[![Build status](https://travis-ci.org/purescript/purescript-validation.svg?branch=master)](https://travis-ci.org/purescript/purescript-validation)

Applicative validation.

## Installation

```
bower install purescript-validation
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-validation).
