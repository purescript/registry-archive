# purescript-validation

A data type for applicative validation

### Usage

The `V` data type can be used to validate data.

The type `V err result` describes possibly valid values of type `result` with validation errors in the semigroup `err`.

