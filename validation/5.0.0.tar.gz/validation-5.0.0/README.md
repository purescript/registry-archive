# purescript-validation

[![Latest release](http://img.shields.io/github/release/purescript/purescript-validation.svg)](https://github.com/purescript/purescript-validation/releases)
[![Build status](https://github.com/purescript/purescript-validation/workflows/CI/badge.svg?branch=master)](https://github.com/purescript/purescript-validation/actions?query=workflow%3ACI+branch%3Amaster)
[![Pursuit](https://pursuit.purescript.org/packages/purescript-validation/badge)](https://pursuit.purescript.org/packages/purescript-validation)

Applicative validation.

## Installation

```
spago install validation
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-validation).

There is also an [entire chapter in PureScript by Example](https://book.purescript.org/chapter7.html#applicative-validation-1) dedicated to describing how to use this module.
