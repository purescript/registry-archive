# purescript-validation

Applicative validation

## Installation

```
bower install purescript-validation
```

## Module documentation

- [Data.Validation](docs/Data/Validation.md)
- [Data.Validation.Semiring](docs/Data/Validation/Semiring.md)
