"use strict";

exports._clipboardData = function (e) {
  return e.clipboardData;
};
