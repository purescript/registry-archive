export function _clipboardData(e) {
  return e.clipboardData;
}
