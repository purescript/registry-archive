# purescript-mersenne

A pure implementation of the [Mersenne Twister](https://en.wikipedia.org/wiki/Mersenne_Twister) PRNG with a minimal API.

## Installation

```
bower install purescript-mersenne
```

## Documentation

- Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-mersenne).
