# purescript-react-basic-dom

[![Build Status](https://travis-ci.org/lumihq/purescript-react-basic-dom.svg?branch=main)](https://travis-ci.org/lumihq/purescript-react-basic-dom)

This library contains the [React Basic](https://github.com/lumihq/purescript-react-basic) DOM modules.
