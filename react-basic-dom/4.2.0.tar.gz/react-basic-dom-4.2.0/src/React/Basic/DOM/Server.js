"use strict";

const ReactDOMServer = require("react-dom/server");

exports.renderToString = ReactDOMServer.renderToString;

exports.renderToStaticMarkup = ReactDOMServer.renderToStaticMarkup;
