import ReactDOMServer from "react-dom/server.js";
export var renderToString = ReactDOMServer.renderToString;
export var renderToStaticMarkup = ReactDOMServer.renderToStaticMarkup;
