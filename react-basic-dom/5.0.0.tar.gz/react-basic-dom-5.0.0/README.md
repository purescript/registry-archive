# purescript-react-basic-dom

[![Build Status](https://github.com/lumihq/purescript-react-basic-dom/actions/workflows/ci.yml/badge.svg)](https://github.com/lumihq/purescript-react-basic-dom/actions/workflows/ci.yml)
<a href="https://pursuit.purescript.org/packages/purescript-react-basic-dom">
  <img src="https://pursuit.purescript.org/packages/purescript-react-basic-dom/badge"
       alt="React Basic DOM on Pursuit">
  </img>
</a>

This library contains the [React Basic](https://github.com/lumihq/purescript-react-basic) DOM modules.
