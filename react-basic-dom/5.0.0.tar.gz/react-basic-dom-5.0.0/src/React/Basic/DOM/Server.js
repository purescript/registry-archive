import ReactDOMServer from "react-dom/server";
export var renderToString = ReactDOMServer.renderToString;
export var renderToStaticMarkup = ReactDOMServer.renderToStaticMarkup;
