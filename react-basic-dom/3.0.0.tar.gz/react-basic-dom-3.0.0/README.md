# purescript-react-basic-dom

[![Build Status](https://travis-ci.org/lumihq/purescript-react-basic-dom.svg?branch=main)](https://travis-ci.org/lumihq/purescript-react-basic-dom)

This library contains the [React Basic](https://github.com/lumihq/purescript-react-basic) DOM modules. For more info, see the React Basic [docs](https://react-basic-starter.github.io/)! (work in progress)
