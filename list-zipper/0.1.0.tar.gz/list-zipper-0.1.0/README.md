# purescript-list-zipper
List Zipper in PureScript

[![Latest release](http://img.shields.io/bower/v/purescript-list-zipper.svg)](https://github.com/DavidHarrison/purescript-list-zipper/releases)
[![Build Status](https://travis-ci.org/DavidHarrison/purescript-list-zipper.svg?branch=master)](https://travis-ci.org/DavidHarrison/purescript-list-zipper)
[![Dependency Status](https://www.versioneye.com/user/projects/55a0a73b323939001700016e/badge.svg?style=flat)](https://www.versioneye.com/user/projects/55a0a73b323939001700016e)

## Installation
```
bower install purescript-list-zipper
```

## Local Testing
- Install [Docker Compose](https://docs.docker.com/compose/install/)
- `docker-compose run test`

## Generating Documenation
- Install [Docker Compose](https://docs.docker.com/compose/install/)
- `docker-compose run docs`

## Module Documentation

[Data.List.Zipper](docs/Data/List/Zipper.md)
