# purescript-simple-json-generics

Simple generics-rep based implementations for Simple-JSON. You should read the Simple-JSON guide page here: <https://purescript-simple-json.readthedocs.io/en/latest/generics-rep.html>

Ultimately, you should not use this directly but as a reference.
