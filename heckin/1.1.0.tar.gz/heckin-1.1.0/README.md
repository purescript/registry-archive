# purescript-heckin

[![Pursuit](https://pursuit.purescript.org/packages/purescript-heckin/badge)](https://pursuit.purescript.org/packages/purescript-heckin)

Oh heck, it's a heckin' case conversion library for PureScript

## Prior Art

This library was inspired by [heck](https://github.com/withoutboats/heck), both in name and behavior.
