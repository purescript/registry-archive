# purescript-snail
*Very much a work in progress*

`purescript-snail` basically places some node commands into `Aff`, providing
combinators that kind-of sort-of if-you-don't-look-too-hard have the appearance
of BASH syntax, but with types! and error-handling! and all the power of `Aff`, etc. etc.

Examples are in the `test/` folder.
