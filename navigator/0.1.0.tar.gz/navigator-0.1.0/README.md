# Module Documentation

## Module Browser.Navigator

### Types

    type Navigator = { userAgent :: String, taintEnabled :: Unit -> Boolean, product :: String, platform :: String, appVersion :: String, appName :: String, appCodeName :: String }

    data NavigatorEff :: !


### Values

    navigator :: Navigator



