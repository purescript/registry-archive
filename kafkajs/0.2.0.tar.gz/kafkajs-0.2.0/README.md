# purescript-kafkajs

Purescript wrapper for [kafkajs](https://kafka.js.org).


## Usage

See [examples folder](./example) for usage. 