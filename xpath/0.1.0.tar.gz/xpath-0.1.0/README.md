# purescript-xpath

[![Latest release](http://img.shields.io/github/release/slamdata/purescript-xpath.svg)](https://github.com/slamdata/purescript-xpath/releases)
[![Build status](https://travis-ci.org/slamdata/purescript-xpath.svg?branch=master)](https://travis-ci.org/slamdata/purescript-xpath)

ADT and printer for XPath queries.

## Installation

```
bower install purescript-xpath
```

## Documentation

- Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-xpath).
