# purescript-functors

[![Latest release](http://img.shields.io/bower/v/purescript-functors.svg)](https://github.com/purescript/purescript-functors/releases)
[![Build Status](https://travis-ci.org/purescript/purescript-functors.svg)](https://travis-ci.org/purescript/purescript-functors)
[![Dependency Status](https://www.versioneye.com/user/projects/5620ce1636d0ab0019000847/badge.svg?style=flat)](https://www.versioneye.com/user/projects/5620ce1636d0ab0019000847)

Constructions on functors.

## Installation

```
bower install purescript-functors
```

## Module documentation

- [Data.Functor.Product](docs/Data/Functor/Product.md)
