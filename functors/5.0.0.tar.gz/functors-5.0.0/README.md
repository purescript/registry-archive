# purescript-functors

[![Latest release](http://img.shields.io/github/release/purescript/purescript-functors.svg)](https://github.com/purescript/purescript-functors/releases)
[![Build status](https://github.com/purescript/purescript-functors/workflows/CI/badge.svg?branch=master)](https://github.com/purescript/purescript-functors/actions?query=workflow%3ACI+branch%3Amaster)
[![Pursuit](https://pursuit.purescript.org/packages/purescript-functors/badge)](https://pursuit.purescript.org/packages/purescript-functors)

Functor products, coproducts, and composition.

## Installation

```
spago install functors
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-functors).
