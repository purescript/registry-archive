# purescript-functors

[![Build Status](https://travis-ci.org/purescript/purescript-functors.svg)](https://travis-ci.org/purescript/purescript-functors)

Constructions on functors.

- [Module Documentation](docs/)
