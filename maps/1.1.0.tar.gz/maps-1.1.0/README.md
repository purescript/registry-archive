# purescript-maps

[![Latest release](http://img.shields.io/bower/v/purescript-maps.svg)](https://github.com/purescript/purescript-maps/releases)
[![Build Status](https://travis-ci.org/purescript/purescript-maps.svg?branch=master)](https://travis-ci.org/purescript/purescript-maps)
[![Dependency Status](https://www.versioneye.com/user/projects/55848c1b363861001d000315/badge.svg?style=flat)](https://www.versioneye.com/user/projects/55848c1b363861001d000315)

Purely-functional map data structures.

## Installation

```
bower install purescript-maps
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-maps).
