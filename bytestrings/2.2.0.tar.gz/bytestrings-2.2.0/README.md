# purescript-bytestrings

Immutable packed byte sequences. Similar to the Haskell bytestring package.
