# purescript-aff-parallel

Parallelize asynchronous computations with specified number of fibers
