# purescript-semigroups

Utility semigroups.

## Installation

```
bower install purescript-semigroups
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-semigroups).
