# purescript-shortid
PureScript types for [shortid](https://github.com/dylang/shortid)
