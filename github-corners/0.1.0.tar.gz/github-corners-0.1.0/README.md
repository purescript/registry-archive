# purescript-github-corners

Bindings of [github-corners](https://github.com/tholman/github-corners) in PureScript, implemented with [purescript-smolder](https://github.com/bodil/purescript-smolder) and [purescript-css](https://github.com/slamdata/purescript-css).
