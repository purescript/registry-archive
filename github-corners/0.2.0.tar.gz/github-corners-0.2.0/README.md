# purescript-github-corners

Bindings of [github-corners](https://github.com/tholman/github-corners) in PureScript, implemented with [purescript-smolder](https://github.com/bodil/purescript-smolder) and [purescript-css](https://github.com/slamdata/purescript-css).

## Installation

```
bower install purescript-github-corners
```

## Documentation

Module documentation is [published on Pursuit](https://pursuit.purescript.org/packages/purescript-github-corners).
