# purescript-errors

> A partial port of Gabriel Gonzales' [errors
> library](https://github.com/Gabriel439/Haskell-Errors-Library) for Haskell.

- [Module documentation](docs/Control/Error/Util.md)
