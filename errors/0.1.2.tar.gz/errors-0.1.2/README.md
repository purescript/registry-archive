# purescript-errors

[![Latest release](http://img.shields.io/bower/v/purescript-errors.svg)](https://github.com/passy/purescript-errors/releases)
[![Build Status](https://travis-ci.org/passy/purescript-errors.svg?branch=master)](https://travis-ci.org/passy/purescript-errors)

> A partial port of Gabriel Gonzales' [errors
> library](https://github.com/Gabriel439/Haskell-Errors-Library) for Haskell.

- [Module documentation](docs/Control/Error/Util.md)
