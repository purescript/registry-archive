//-----------------------------------------------------------------------------
// Phina.Types.Size

exports._setSize = function(size, a) {
  a.width = size.width;
  a.height = size.height;
  return a;
};
