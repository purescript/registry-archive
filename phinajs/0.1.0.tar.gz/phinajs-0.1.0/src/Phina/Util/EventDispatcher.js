//-----------------------------------------------------------------------------
// Phina.Util.EventDispatcher

exports._flare = function(event, param, instance) {
  return instance.flare(event, param);
};
