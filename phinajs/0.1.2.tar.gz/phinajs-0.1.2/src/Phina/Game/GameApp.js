//-----------------------------------------------------------------------------
// Phina.Game.GameApp

exports._enableStats = function(app) {
  return app.enableStats();
};
