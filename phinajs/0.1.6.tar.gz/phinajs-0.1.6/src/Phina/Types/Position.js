//-----------------------------------------------------------------------------
// Phina.Types.Position

exports._setPosition = function(pos, a) {
  a.x = pos.x;
  a.y = pos.y;
  return a;
};
