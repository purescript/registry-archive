# purescript-react-cedar

Simple architecture for [purescript-react](https://github.com/purescript-contrib/purescript-react)
inspired by [Elm](http://elm-lang.org/) and [Thermite](https://github.com/paf31/purescript-thermite).

- [Module Documentation](docs/)

## Related Modules
- [React](https://github.com/purescript-contrib/purescript-react)
