# purescript-browserfeatures

[![Latest release](http://img.shields.io/bower/v/purescript-browserfeatures.svg)](https://github.com/slamdata/purescript-browserfeatures/releases)
[![Build Status](https://travis-ci.org/slamdata/purescript-browserfeatures.svg?branch=master)](https://travis-ci.org/slamdata/purescript-browserfeatures)
[![Dependency Status](https://www.versioneye.com/user/projects/579a398a3815c8003b2a6cb4/badge.svg?style=flat)](https://www.versioneye.com/user/projects/579a398a3815c8003b2a6cb4)

A data type for browser features and detectors to test for the features.

## Installation

```
bower install purescript-browserfeatures
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-browserfeatures).
