# purescript-browserfeatures
A data type for browser features and detectors to test for the features.

To build, run

```
gulp
```

Then open `test/index.html` and observe the console to see this in action.
