# purescript-browserfeatures

[![Latest release](http://img.shields.io/github/release/slamdata/purescript-browserfeatures.svg)](https://github.com/slamdata/purescript-browserfeatures/releases)
[![Build status](https://travis-ci.org/slamdata/purescript-browserfeatures.svg?branch=master)](https://travis-ci.org/slamdata/purescript-browserfeatures)

A data type for browser features and detectors to test for the features.

## Installation

```
bower install purescript-browserfeatures
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-browserfeatures).
