"use strict";

exports._getTypeProperty = function (el) {
  return function () {
    return el.type;
  };
};
