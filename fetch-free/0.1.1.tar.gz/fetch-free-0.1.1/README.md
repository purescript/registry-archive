# purescript-fetch-free

A library modeling operations for fetch.

## Installation

```bash
bower install --save purescript-fetch-free
```
