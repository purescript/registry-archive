purescript-bifunctors
=====================

[![Build Status](https://travis-ci.org/purescript/purescript-bifunctors.svg?branch=master)](https://travis-ci.org/purescript/purescript-bifunctors)

Bifunctors, Biapplicatives, Bifoldable, Bitraversable. Includes instances for `Either`, `Tuple`, and `Const`.

- [Module documentation](docs/Module.md)
