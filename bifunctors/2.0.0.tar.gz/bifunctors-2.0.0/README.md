# purescript-bifunctors

[![Latest release](http://img.shields.io/bower/v/purescript-bifunctors.svg)](https://github.com/purescript/purescript-bifunctors/releases)
[![Build Status](https://travis-ci.org/purescript/purescript-bifunctors.svg?branch=master)](https://travis-ci.org/purescript/purescript-bifunctors)
[![Dependency Status](https://www.versioneye.com/user/projects/55848c8136386100150003ef/badge.svg?style=flat)](https://www.versioneye.com/user/projects/55848c8136386100150003ef)

Bifunctors and biapplicatives.

## Installation

```
bower install purescript-bifunctors
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-bifunctors).
