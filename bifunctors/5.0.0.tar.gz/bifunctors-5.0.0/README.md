# purescript-bifunctors

[![Latest release](http://img.shields.io/github/release/purescript/purescript-bifunctors.svg)](https://github.com/purescript/purescript-bifunctors/releases)
[![Build status](https://github.com/purescript/purescript-bifunctors/workflows/CI/badge.svg?branch=master)](https://github.com/purescript/purescript-bifunctors/actions?query=workflow%3ACI+branch%3Amaster)
[![Pursuit](https://pursuit.purescript.org/packages/purescript-bifunctors/badge)](https://pursuit.purescript.org/packages/purescript-bifunctors)

Bifunctors and biapplicatives.

## Installation

```
spago install bifunctors
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-bifunctors).
