# purescript-bifunctors

[![Latest release](http://img.shields.io/github/release/purescript/purescript-bifunctors.svg)](https://github.com/purescript/purescript-bifunctors/releases)
[![Build status](https://travis-ci.org/purescript/purescript-bifunctors.svg?branch=master)](https://travis-ci.org/purescript/purescript-bifunctors)

Bifunctors and biapplicatives.

## Installation

```
bower install purescript-bifunctors
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-bifunctors).
