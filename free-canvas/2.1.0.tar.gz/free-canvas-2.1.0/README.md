# purescript-free-canvas

A free monad interface to the canvas

## Installing

    bower i purescript-free-canvas
    
- [Module Documentation](docs/)
