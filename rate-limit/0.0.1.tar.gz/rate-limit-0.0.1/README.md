# purescript-rate-limit

Simple in-memory rate limiting.
