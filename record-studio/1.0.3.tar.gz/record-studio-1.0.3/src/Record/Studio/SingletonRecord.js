
export const unsafeGetFirstField = rec => Object.keys(rec)[0]
