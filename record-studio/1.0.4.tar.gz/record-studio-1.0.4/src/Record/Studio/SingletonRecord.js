
export const unsafeGetFirstField = rec => Object.values(rec)[0]
