# ppp

`ppp` is a library for (pleasant)
[permutations](http://mathworld.wolfram.com/PermutationGroup.html) in
PureScript. Currently, it is somewhat incomplete, but it already has
functions to multiply and invert permutations.

## Installation

To add to your project:

```bash
bower install purescript-permutations
```

### Documentation

You can find documentation
[here](https://pursuit.purescript.org/packages/permutations/).

## Building

If you'd like to contribute to this library, I'd recommend building with
[pulp](https://github.com/purescript-contrib/pulp):

```bash
 $ pulp --psc-package build
 $ pulp --psc-package test
```
