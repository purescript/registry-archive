# ppp

`ppp` is a library for (pleasant)
[permutations](http://mathworld.wolfram.com/PermutationGroup.html) in
PureScript. Currently, it is somewhat incomplete, but it already has
functions to multiply and invert permutations.

## Installation

To add to your project:

```bash
psc-package install permutations
```

### Documentation

You can find documentation
[here](https://pursuit.purescript.org/packages/permutations/0.1.0).

## Building

If you'd like to contribute to this library, I'd recommend building with
[pulp](https://github.com/purescript-contrib/pulp):

```bash
 $ pulp build
 $ pulp test
```
