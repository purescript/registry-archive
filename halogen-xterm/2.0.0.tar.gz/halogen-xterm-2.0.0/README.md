# halogen-xterm

Halogen components for [xterm](https://github.com/grybiena/xterm). 

## Example
- [the example page](https://grybiena.github.io/halogen-xterm-example/index.html)
- [the example code](https://github.com/grybiena/grybiena.github.io/blob/grybiena/halogen-xterm-example/src/Example.purs)

## Documentation

Module documentation is [published on Pursuit](https://pursuit.purescript.org/packages/purescript-halogen-xterm).
