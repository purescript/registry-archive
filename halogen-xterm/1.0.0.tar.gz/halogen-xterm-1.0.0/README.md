# halogen-xterm

Halogen components for [xterm](https://github.com/grybiena/xterm). 
