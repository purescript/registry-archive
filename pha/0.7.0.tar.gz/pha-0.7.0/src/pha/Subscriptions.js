exports.makeSubscription = fn => d => [fn, d]
