exports.makeSub = fn => d => [fn, d]
