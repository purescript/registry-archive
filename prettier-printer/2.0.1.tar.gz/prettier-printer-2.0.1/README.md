# purescript-prettier-printer

[![Build Status](https://travis-ci.org/paulyoung/purescript-prettier-printer.svg?branch=master)](https://travis-ci.org/paulyoung/purescript-prettier-printer)

An implementation of [A prettier printer (Wadler 2003)](https://homepages.inf.ed.ac.uk/wadler/papers/prettier/prettier.pdf) in PureScript.
