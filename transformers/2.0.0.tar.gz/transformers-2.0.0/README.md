# purescript-transformers

[![Latest release](http://img.shields.io/bower/v/purescript-transformers.svg)](https://github.com/purescript/purescript-transformers/releases)
[![Build Status](https://travis-ci.org/purescript/purescript-transformers.svg?branch=master)](https://travis-ci.org/purescript/purescript-transformers)
[![Dependency Status](https://www.versioneye.com/user/projects/55848c19363861001b00018a/badge.svg?style=flat)](https://www.versioneye.com/user/projects/55848c19363861001b00018a)

Monad and comonad transformers based on [mtl](http://hackage.haskell.org/package/mtl).

## Installation

```
bower install purescript-transformers
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-transformers).
