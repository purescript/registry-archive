# purescript-transformers

[![Latest release](http://img.shields.io/github/release/purescript/purescript-transformers.svg)](https://github.com/purescript/purescript-transformers/releases)
[![Build status](https://travis-ci.org/purescript/purescript-transformers.svg?branch=master)](https://travis-ci.org/purescript/purescript-transformers)

Monad and comonad transformers based on [mtl](http://hackage.haskell.org/package/mtl).

## Installation

```
bower install purescript-transformers
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-transformers).
