purescript-transformers
=======================

[![Build Status](https://travis-ci.org/purescript/purescript-transformers.svg?branch=master)](https://travis-ci.org/purescript/purescript-transformers)

Monad transformers based on [mtl](http://hackage.haskell.org/package/mtl).

- [Module documentation](docs/Module.md)
- [Examples](examples/)
