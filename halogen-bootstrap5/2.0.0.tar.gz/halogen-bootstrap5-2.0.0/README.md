# purescript-halogen-bootstrap5

Bootstrap 5 classes and utilities for `purescript-halogen`.

Classes extracted from https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css

## Installation

```
spago install purescript-halogen-bootstrap5
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-halogen-bootstrap5).
