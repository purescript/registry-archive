"use strict";

const helpers = require("@turf/helpers");

// exports.featureCollectionImpl = helpers.featureCollection;

// exports.featureImpl = helpers.feature;

// exports.geometryCollectionImpl = helpers.geometryCollection;

exports.lineStringImpl = helpers.lineString;

exports.multiLineStringImpl = helpers.multiLineString;

exports.multiPointImpl = helpers.multiPoint;

exports.multiPolygonImpl = helpers.multiPolygon;

exports.pointImpl = helpers.point;

exports.polygonImpl = helpers.polygon;
