# purescript-const

Functions from [purescript-console](https://github.com/purescript/purescript-console) lifted to [MonadEff](https://pursuit.purescript.org/packages/purescript-eff/3.2.1/docs/Control.Monad.Eff.Class#t:MonadEff).

## Installation

```
bower install purescript-const
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-console-lifted).
