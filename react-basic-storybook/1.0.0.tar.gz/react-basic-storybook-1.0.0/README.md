# Purescript React Basic Storybook

# Requirements
This is intended to be used with [the hooks version of react basic](https://github.com/spicydonuts/purescript-react-basic-hooks).

# Using it
```
spago install react-basic-storybook
```

# Example
Check out the example in the [example](./example) folder and see the corresponding Storybook [here](https://www.chromatic.com/library?appId=6361654082cc659cc6303ca4)
