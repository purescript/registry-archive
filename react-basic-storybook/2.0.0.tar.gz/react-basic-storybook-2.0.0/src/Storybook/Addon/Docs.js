export {
  Title as titleImpl,
  Subtitle as subtitleImpl,
  Description as descriptionImpl,
  Primary as primaryImpl,
  ArgsTable as argsTableImpl,
  Stories as storiesImpl,
  PRIMARY_STORY as primaryStoryImpl
} from "@storybook/addon-docs";
