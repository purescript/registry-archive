purescript-assertion-error
===
[![Bower version](https://badge.fury.io/bo/purescript-assertion-error.svg)](http://badge.fury.io/bo/purescript-assertion-error)
[![devDependency Status](https://david-dm.org/philopon/purescript-assertion-error/dev-status.svg)](https://david-dm.org/philopon/purescript-assertion-error#info=devDependencies)

assertion-error wrapper for purescript

* [Module documentation](./docs/Test/Assert/AssertionError.md)
* [example](examples/Main.purs)
