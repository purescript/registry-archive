purescript-assertion-error
===
assertion-error wrapper for purescript

* [Module documentation](./docs/Test/Assert/AssertionError.md)
* [example](examples/Main.purs)
