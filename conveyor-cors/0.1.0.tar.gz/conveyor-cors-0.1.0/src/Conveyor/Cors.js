"use strict";

exports.responseHeaders = function(res) {
  return res.getHeaders();
}
