# purescript-conveyor-cors

[![Latest release](http://img.shields.io/github/release/oreshinya/purescript-conveyor-cors.svg)](https://github.com/oreshinya/purescript-conveyor-cors/releases)

CORS for [purescript-conveyor](https://github.com/oreshinya/purescript-conveyor).

See [example](https://github.com/oreshinya/purescript-conveyor-cors/blob/master/example/Main.purs#L86).

## Installation

```
bower install purescript-conveyor-cors
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-conveyor-cors).

## LICENSE

MIT
