# purescript-openapi

A port of the [Haskell port](https://github.com/meeshkan/openapi-haskell) of [`openapi_typed_2`](https://github.com/meeshkan/openapi-typed-2).