export function touches(e) {
  return e.touches;
}

export function targetTouches(e) {
  return e.targetTouches;
}

export function changedTouches(e) {
  return e.changedTouches;
}

export function altKey(e) {
  return e.altKey;
}

export function metaKey(e) {
  return e.metaKey;
}

export function ctrlKey(e) {
  return e.ctrlKey;
}

export function shiftKey(e) {
  return e.shiftKey;
}
