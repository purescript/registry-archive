export function identifier(t) {
  return t.identifier;
}

export function screenX(t) {
  return t.screenX;
}

export function screenY(t) {
  return t.screenY;
}

export function clientX(t) {
  return t.clientX;
}

export function clientY(t) {
  return t.clientY;
}

export function pageX(t) {
  return t.pageX;
}

export function pageY(t) {
  return t.pageY;
}

export function target(t) {
  return t.target;
}
