export function length(l) {
  return l.length;
}

export function _item(i, l) {
  return l.item(i);
}
