"use strict";

exports.identifier = function (t) {
  return t.identifier;
};

exports.screenX = function (t) {
  return t.screenX;
};

exports.screenY = function (t) {
  return t.screenY;
};

exports.clientX = function (t) {
  return t.clientX;
};

exports.clientY = function (t) {
  return t.clientY;
};

exports.pageX = function (t) {
  return t.pageX;
};

exports.pageY = function (t) {
  return t.pageY;
};

exports.target = function (t) {
  return t.target;
};
