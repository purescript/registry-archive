"use strict";

exports.length = function (l) {
  return l.length;
};

exports._item = function (i, l) {
  return l.item(i);
};
