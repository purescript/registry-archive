# purescript-ring-modules

Type classes for modules over rings.
