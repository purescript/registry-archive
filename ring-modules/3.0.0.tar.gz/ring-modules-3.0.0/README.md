# purescript-modules

Type classes for modules over rings.
