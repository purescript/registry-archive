PureScript Read [![](https://img.shields.io/badge/doc-pursuit-60b5cc.svg)](http://pursuit.purescript.org/packages/purescript-read)
=====

This package offers simple class definitions for defining readable (that can be parsed from
`String`) types in PureScript.

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-read).
