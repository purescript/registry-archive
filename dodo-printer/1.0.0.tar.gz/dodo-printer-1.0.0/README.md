# purescript-dodo-printer

An adequate printer.

This library implements the equivalent functions of many other pretty-printers in
the Wadler/Leijen style but with all the names gratuitously changed.

It also provides nice ANSI integration.

## Examples

* Colorful JSON printer ([code](test/snapshots/DodoExampleJson.purs), [output](test/snapshots/DodoExampleJson.output))
