# purescript-bucketchain-logger

[![Latest release](http://img.shields.io/github/release/Bucketchain/purescript-bucketchain-logger.svg)](https://github.com/Bucketchain/purescript-bucketchain-logger/releases)

Logger middlewares of [Bucketchain](https://github.com/Bucketchain/purescript-bucketchain).

## Installation

```
bower install purescript-bucketchain-logger
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-bucketchain-logger).

## LICENSE

MIT
