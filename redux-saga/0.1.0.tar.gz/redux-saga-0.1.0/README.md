# purescript-redux-saga

Pipes based implementation of redux-saga in purescript

## Example

See the [purescript-redux-saga-example project](https://github.com/felixschl/purescript-redux-saga-example) for a working demo!
