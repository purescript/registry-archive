"use strict";

exports.now = function () {
  return Date.now();
};
