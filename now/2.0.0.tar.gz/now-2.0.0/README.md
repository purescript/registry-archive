# purescript-now

[![Latest release](http://img.shields.io/github/release/purescript-contrib/purescript-now.svg)](https://github.com/purescript-contrib/purescript-now/releases)
[![Build Status](https://travis-ci.org/purescript-contrib/purescript-now.svg?branch=master)](https://travis-ci.org/purescript-contrib/purescript-now)
[![Maintainer: garyb](https://img.shields.io/badge/maintainer-garyb-lightgrey.svg)](http://github.com/garyb)

Effect type and function for accessing the current machine's date and time.

## Installation

```
bower install purescript-now
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-now).
