# purescript-var

An API to provide uniform read/write access to the references in the `Eff` monad.
