# purescript-var

<a href="https://pursuit.purescript.org/packages/purescript-var">
  <img src="https://pursuit.purescript.org/packages/purescript-var/badge"
       alt="purescript-var on Pursuit">
  </img>
</a>

An API to provide uniform read/write access to the references in the `Eff` monad.

[Documentation](https://pursuit.purescript.org/packages/purescript-var/2.0.0/docs/Control.Monad.Eff.Var)
