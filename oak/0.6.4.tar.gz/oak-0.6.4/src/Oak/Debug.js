exports.traceImpl = function(a) {
  console.log(a);
  return a;
};

