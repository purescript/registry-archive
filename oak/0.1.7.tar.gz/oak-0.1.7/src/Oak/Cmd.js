exports.noneImpl = function() {
};
