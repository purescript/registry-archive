# purescript-behaviors

The goals of this library are to create a simple implementation of FRP which:

- Separates events and behaviors
- Can be used easily from JavaScript

## Building

```
pulp build
npm run test
```
