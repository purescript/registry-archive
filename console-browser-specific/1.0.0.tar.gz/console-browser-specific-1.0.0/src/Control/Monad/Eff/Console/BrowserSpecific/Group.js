"use strict";

exports["group'"] = function () {
  console.groupEnd();
  return {};
};

exports["groupCollapsed'"] = function () {
  console.groupCollapsed();
  return {};
};

exports["groupEnd'"] = function () {
  console.groupEnd();
  return {};
};
