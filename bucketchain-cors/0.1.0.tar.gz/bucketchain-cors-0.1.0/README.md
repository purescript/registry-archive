# purescript-bucketchain-cors

[![Latest release](http://img.shields.io/github/release/Bucketchain/purescript-bucketchain-cors.svg)](https://github.com/Bucketchain/purescript-bucketchain-cors/releases)

A CORS middleware of [Bucketchain](https://github.com/Bucketchain/purescript-bucketchain).

## Installation

```
bower install purescript-bucketchain-cors
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-bucketchain-cors).

## LICENSE

MIT
