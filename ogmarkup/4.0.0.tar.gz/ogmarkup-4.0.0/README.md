# purescript-ogmarkup

This library is a port of the Haskell
[ogmarkup](http://hackage.haskell.org/package/ogmarkup) library. The
documentation may contain references to this initial library.
