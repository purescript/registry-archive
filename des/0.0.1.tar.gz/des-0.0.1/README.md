# purescript-des

DES encryption/decryption adapted from https://github.com/vincenthz/hs-crypto-cipher/blob/master/cipher-des/Crypto/Cipher/DES/Primitive.hs

Originally used for RFB auth, not suitable for big chunks of data.

## Installation

```
        bower install purescript-des
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-des).