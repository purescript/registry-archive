# purescript-integers

[![Latest release](http://img.shields.io/bower/v/purescript-integers.svg)](https://github.com/purescript/purescript-integers/releases)
[![Build Status](https://travis-ci.org/purescript/purescript-integers.svg?branch=master)](https://travis-ci.org/purescript/purescript-integers)
[![Dependency Status](https://www.versioneye.com/user/projects/55848cbc363861001d00034e/badge.svg?style=flat)](https://www.versioneye.com/user/projects/55848cbc363861001d00034e)

Functions and bitwise operators for the Int numeric type.

## Installation

```
bower install purescript-integers
```

## Module documentation

- [`Data.Int`](docs/Data/Int.md)
- [`Data.Int.Bits`](docs/Data/Int/Bits.md)
