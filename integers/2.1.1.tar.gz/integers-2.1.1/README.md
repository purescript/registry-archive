# purescript-integers

[![Latest release](http://img.shields.io/github/release/purescript/purescript-integers.svg)](https://github.com/purescript/purescript-integers/releases)
[![Build status](https://travis-ci.org/purescript/purescript-integers.svg?branch=master)](https://travis-ci.org/purescript/purescript-integers)

Functions and bitwise operators for the `Int` numeric type.

## Installation

```
bower install purescript-integers
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-integers).
