# purescript-integers

[![Latest release](http://img.shields.io/github/release/purescript/purescript-integers.svg)](https://github.com/purescript/purescript-integers/releases)
[![Build status](https://github.com/purescript/purescript-integers/workflows/CI/badge.svg?branch=master)](https://github.com/purescript/purescript-integers/actions?query=workflow%3ACI+branch%3Amaster)
[![Pursuit](https://pursuit.purescript.org/packages/purescript-integers/badge)](https://pursuit.purescript.org/packages/purescript-integers)

Functions and bitwise operators for the `Int` numeric type.

## Installation

```
spago install integers
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-integers).
