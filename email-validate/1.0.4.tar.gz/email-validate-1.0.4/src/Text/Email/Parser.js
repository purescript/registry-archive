/* global exports */
"use strict";

// module Text.Email.Parser

exports.undefined = undefined;
