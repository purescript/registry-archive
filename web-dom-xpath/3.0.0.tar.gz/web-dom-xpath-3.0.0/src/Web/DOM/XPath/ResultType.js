export const any_type = XPathResult.ANY_TYPE;
export const number_type = XPathResult.NUMBER_TYPE;
export const string_type = XPathResult.STRING_TYPE;
export const boolean_type = XPathResult.BOOLEAN_TYPE;
export const unordered_node_iterator_type = XPathResult.UNORDERED_NODE_ITERATOR_TYPE;
export const ordered_node_iterator_type = XPathResult.ORDERED_NODE_ITERATOR_TYPE;
export const unordered_node_snapshot_type = XPathResult.UNORDERED_NODE_SNAPSHOT_TYPE;
export const ordered_node_snapshot_type = XPathResult.ORDERED_NODE_SNAPSHOT_TYPE;
export const any_unordered_node_type = XPathResult.ANY_UNORDERED_NODE_TYPE;
export const first_ordered_node_type = XPathResult.FIRST_ORDERED_NODE_TYPE;

