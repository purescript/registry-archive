# purescript-geometry-plane
some basic tools for planar geometry like vector constructions or intersections of common shapes
