# purescript-yoga-subtlecrypto

Simple bindings to the Browser's `window.crypto.subtle` API thing.

*__Warning__*: This only works on specific browsers - not even node.js!

## Provenance

Forked from https://github.com/athanclark/purescript-subtlecrypto
