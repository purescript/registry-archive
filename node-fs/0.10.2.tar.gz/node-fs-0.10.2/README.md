# purescript-node-fs

Bindings to node's "fs" module.

Module documentation is hosted on [Pursuit](http://pursuit.purescript.org/packages/purescript-node-fs).
