"use strict";
// module Node.FS.Internal

exports.unsafeRequireFS = require("fs");
