export {
  createReadStream as createReadStreamImpl,
  createWriteStream as createWriteStreamImpl
} from "fs";
