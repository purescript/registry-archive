# purescript-node-fs

[![Latest release](http://img.shields.io/github/release/purescript-node/purescript-node-fs.svg)](https://github.com/purescript-node/purescript-node-fs/releases)
[![Build Status](https://travis-ci.org/purescript-node/purescript-node-fs.svg?branch=master)](https://travis-ci.org/purescript-node/purescript-node-fs)

PureScript bindings to node's `fs` module.

## Installation

```
bower install purescript-node-fs
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-node-fs).
