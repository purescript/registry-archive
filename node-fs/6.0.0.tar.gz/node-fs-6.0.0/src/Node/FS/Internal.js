"use strict";

exports.unsafeRequireFS = require("fs");
