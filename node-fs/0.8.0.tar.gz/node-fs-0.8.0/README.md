# purescript-node-fs

Bindings to node's "fs" module.

## Module documentation

* [Node.FS](docs/Node/FS.md)
* [Node.FS.Sync](docs/Node/FS/Sync.md)
* [Node.FS.Async](docs/Node/FS/Async.md)
* [Node.FS.Stats](docs/Node/FS/Stats.md)
* [Node.FS.Perms](docs/Node/FS/Perms.md)
