# purescript-node-fs

[![Latest release](http://img.shields.io/bower/v/purescript-node-fs.svg)](https://github.com/purescript-node/purescript-node-fs/releases)
[![Build Status](https://travis-ci.org/purescript-node/purescript-node-fs.svg?branch=master)](https://travis-ci.org/purescript-node/purescript-node-fs)
[![Dependency Status](https://www.versioneye.com/user/projects/575bdefb7757a0003bd4bff5/badge.svg?style=flat)](https://www.versioneye.com/user/projects/575bdefb7757a0003bd4bff5)

PureScript bindings to node's `fs` module.

## Installation

```
bower install purescript-node-fs
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-node-fs).
