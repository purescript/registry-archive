# purescript-grain-portal

[![Latest release](http://img.shields.io/github/release/purescript-grain/purescript-grain-portal.svg)](https://github.com/purescript-grain/purescript-grain-portal/releases)

A way to render children into a node that exists outside the DOM hierarchy of the parent node.

[Demo](https://purescript-grain.github.io/purescript-grain-portal/)

## Installation

### Spago

```
$ spago install grain-portal
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-grain-portal).

## LICENSE

MIT
