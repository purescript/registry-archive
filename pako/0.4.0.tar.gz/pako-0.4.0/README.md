# purescript-pako

PureScript bindings for https://github.com/nodeca/pako
