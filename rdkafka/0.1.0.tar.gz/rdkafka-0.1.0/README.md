# purescript-rdkafka

`purescript-rdkafka` contains [PureScript](http://purescript.org) bindings for [`node-rdkafka`](https://github.com/Blizzard/node-rdkafka).

# License

Released under the MIT license. See `LICENSE` file.
