# purescript-electron

[![Latest release](http://img.shields.io/bower/v/purescript-electron.svg)](https://github.com/bamboo/purescript-electron/releases)
[![Build Status](https://travis-ci.org/bamboo/purescript-electron.svg?branch=master)](https://travis-ci.org/bamboo/purescript-electron)

PureScript FFI bindings for the [Electron](http://electron.atom.io) API.

See the [quick start project](https://github.com/bamboo/purescript-electron-quickstart) for an example.

## Status

The project has just started and we'd gladly accept your help, specially in the form of pull requests.
