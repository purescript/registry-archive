# purescript-electron

PureScript FFI bindings for the [Electron](http://electron.atom.io) API.

See the [quick start project](https://github.com/bamboo/purescript-electron-quickstart) for an example.

## Status

The project has just started and we'd gladly accept your help, specially in the form of pull requests.
