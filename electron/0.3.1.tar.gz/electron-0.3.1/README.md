# Purescript Electron

[![Latest release](http://img.shields.io/bower/v/purescript-electron.svg)](https://github.com/cjduncana/purescript-electron/releases)
[![PureScript Electron on Pursuit](https://pursuit.purescript.org/packages/purescript-electron/badge)](https://pursuit.purescript.org/packages/purescript-electron)

PureScript FFI bindings for the [Electron](http://electron.atom.io) API.

See the [quick start project](https://github.com/cjduncana/purescript-electron-quickstart) for an example.

Browse the [module
documentation](https://pursuit.purescript.org/packages/purescript-electron).

## Status

The project has just started and we'd gladly accept your help, specially in the form of pull requests.
