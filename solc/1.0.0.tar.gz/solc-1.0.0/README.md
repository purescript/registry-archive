# purescript-solc

[![Build Status](https://travis-ci.org/f-o-a-m/purescript-solc.svg?branch=master)](https://travis-ci.org/f-o-a-m/purescript-solc)

PureScript bindings for the JavaScript bindings for the Solidity compiler.