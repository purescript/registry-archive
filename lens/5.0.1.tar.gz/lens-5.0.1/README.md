# DEPRECATED

`purescript-lens` has been deprecated because [purescript-profunctor-lenses](https://github.com/purescript-contrib/purescript-profunctor-lenses) has become the de facto way to use lenses in PureScript: it's easier to understand, is actively maintained and expanded, and has documentation resources including a [book](https://leanpub.com/lenses) and [long-form guide](https://thomashoneyman.com/articles/practical-profunctor-lenses-optics/).

Previous releases continue to work. Further details can be found in the [Discourse discussion](https://discourse.purescript.org/t/proposed-purescript-contrib-library-deprecations) about this deprecation.

