# purescript-stdout

[![Latest release](http://img.shields.io/github/release/oreshinya/purescript-stdout.svg)](https://github.com/oreshinya/purescript-vary/releases)

PureScript stdout logger.

## Installation

```
bower install purescript-stdout
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-stdout).

## LICENSE

MIT
