# purescript-ansi

A small PureScript library for dealing with ANSI escape codes.

Documentation is [on Pursuit](http://pursuit.purescript.org/packages/purescript-ansi).
