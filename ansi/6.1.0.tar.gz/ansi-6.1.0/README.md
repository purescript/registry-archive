[![build](https://github.com/hdgarrood/purescript-ansi/actions/workflows/build.yml/badge.svg?branch=master)](https://github.com/hdgarrood/purescript-ansi/actions/workflows/build.yml)

# purescript-ansi

A small PureScript library for dealing with ANSI escape codes.

Documentation is [on Pursuit](http://pursuit.purescript.org/packages/purescript-ansi).
