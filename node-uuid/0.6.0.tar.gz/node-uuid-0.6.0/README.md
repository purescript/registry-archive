# purescript-node-uuid

This is just a simple wrapper around node-uuid.
It is soon to be deprecated in favor of a ps solution.

## Installation

```
bower i purescript-node-uuid
```
