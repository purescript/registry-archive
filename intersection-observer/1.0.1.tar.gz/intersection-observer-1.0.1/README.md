# intersection-observer

Bindings to the [DOM IntersectionObserver API](https://developer.mozilla.org/en-US/docs/Web/API/IntersectionObserver).
