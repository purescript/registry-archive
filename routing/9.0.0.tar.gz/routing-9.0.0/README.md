# purescript-routing

[![Latest release](http://img.shields.io/github/release/slamdata/purescript-routing.svg)](https://github.com/slamdata/purescript-routing/releases)
[![Build status](https://travis-ci.org/slamdata/purescript-routing.svg?branch=master)](https://travis-ci.org/slamdata/purescript-routing)

Client side routing library.

## Installation

```shell
bower install purescript-routing
```

# Module documentation

- The [guide](GUIDE.md) provides an overview of library's usage and implementation.

- Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-routing).
