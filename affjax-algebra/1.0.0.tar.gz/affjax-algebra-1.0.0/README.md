# purescript-affjax-algebra

[![Latest release](http://img.shields.io/bower/v/purescript-affjax-algebra.svg)](https://github.com/slamdata/purescript-affjax-algebra/releases)
[![Build Status](https://travis-ci.org/slamdata/purescript-affjax-algebra.svg?branch=master)](https://travis-ci.org/slamdata/purescript-affjax-algebra)
[![Dependency Status](https://www.versioneye.com/user/projects/57194511fcd19a00518561d2/badge.svg?style=flat)](https://www.versioneye.com/user/projects/57194511fcd19a00518561d2)

An algebra for [`purescript-affjax`](https://github.com/slamdata/purescript-affjax) requests.

## Installation

``` purescript
bower install purescript-affjax-algebra
```

## Module documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-affjax-algebra).
