# purescript-affjax-algebra

[![Latest release](http://img.shields.io/github/release/slamdata/purescript-affjax-algebra.svg)](https://github.com/slamdata/purescript-affjax-algebra/releases)
[![Build status](https://travis-ci.org/slamdata/purescript-affjax-algebra.svg?branch=master)](https://travis-ci.org/slamdata/purescript-affjax-algebra)

An algebra for [`purescript-affjax`](https://github.com/slamdata/purescript-affjax) requests.

## Installation

``` purescript
bower install purescript-affjax-algebra
```

## Module documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-affjax-algebra).
