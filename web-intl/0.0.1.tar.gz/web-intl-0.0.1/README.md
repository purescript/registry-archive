Low-level bindings for the `Intl` object https://tc39.es/ecma402/#intl-object
