export const windowFetch = window.fetch;
