# 📬 purescript-yoga-fetch

A simple wrapper for the JavaScript fetch API.

**Note**: This is a fork of [milkis](https://github.com/justinwoo/purescript-milkis) ([MIT Licence](./LICENCE/purescript-milkis.LICENSE)).

## Table of Contents
* [usage](#usage)
* [migrate from `milkis`](#migrate-from-purescript-milkis)

## Usage


## Migrate from `purescript-milkis`

`purescript-yoga-fetch` is a drop-in replacement for `purescript-milkis`. Just change the imports from `Milkis` to `Fetch`.
