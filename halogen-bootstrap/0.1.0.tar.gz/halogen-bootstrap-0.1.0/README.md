# purescript-halogen-bootstrap

A Bootstrap 3 theme for `purescript-halogen`. 
