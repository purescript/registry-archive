export { constants as osConstants } from "os";
