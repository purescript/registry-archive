# purescript-react-dom

Low-level React DOM bindings for PureScript

- [Module Documentation](docs/)

## Installation

```
bower install purescript-react-dom
```

## Example

Please refer to [purescript-react-example](https://github.com/ethul/purescript-react-example)
