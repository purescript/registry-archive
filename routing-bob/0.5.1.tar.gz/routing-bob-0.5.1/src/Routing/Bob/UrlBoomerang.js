/* global exports */
"use strict";

// module Routing.Bob.UrlBoomerang

exports.encodeURIComponent = encodeURIComponent;
exports.decodeURIComponent = decodeURIComponent;
