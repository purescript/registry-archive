# purescript-parsing-expect

Ad-hoc helper functions for implementing unit tests for PureScript parsers. 
