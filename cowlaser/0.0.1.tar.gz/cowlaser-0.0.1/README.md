# Cowlaser

Cowlaser is a PureScript library with utilities for building server-side web
applications.
