# purescript-run-streaming

[![Latest release](http://img.shields.io/github/release/natefaubion/purescript-run-streaming.svg)](https://github.com/natefaubion/purescript-run-streaming/releases)
[![Build status](https://travis-ci.org/natefaubion/purescript-run-streaming.svg?branch=master)](https://travis-ci.org/natefaubion/purescript-run-streaming)

Streaming bidirectional pipes for PureScript.

## Install

```
bower install purescript-run-streaming
```

## Documentation

- Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-run-streaming).
