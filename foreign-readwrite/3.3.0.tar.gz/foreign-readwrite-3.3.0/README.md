# purescript-foreign-readwrite

## Installation

```sh
spago install foreign-readwrite
```

## Documentation

### Reference

Module reference is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-foreign-readwrite).
