# purescript-run

[![Latest release](http://img.shields.io/github/release/natefaubion/purescript-run.svg)](https://github.com/natefaubion/purescript-run/releases)
[![Build status](https://travis-ci.org/natefaubion/purescript-run.svg?branch=master)](https://travis-ci.org/natefaubion/purescript-run)

An [extensible-effects](https://hackage.haskell.org/package/extensible-effects)
implementation for PureScript.

## Install

```
bower install purescript-run
```

## Documentation

- Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-run).
