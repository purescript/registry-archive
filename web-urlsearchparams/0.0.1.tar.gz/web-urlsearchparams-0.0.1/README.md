# purescript-web-urlsearchparams

Bindings to the URLSearchParams object in browsers - see the [MDN Spec](https://developer.mozilla.org/en-US/docs/Web/API/URLSearchParams) for details.
