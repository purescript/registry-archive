# purescript-canvas

[![Latest release](http://img.shields.io/github/release/purescript-web/purescript-canvas.svg)](https://github.com/purescript-web/purescript-canvas/releases)
[![Build status](https://github.com/purescript-web/purescript-canvas/workflows/CI/badge.svg?branch=master)](https://github.com/purescript-web/purescript-canvas/actions?query=workflow%3ACI+branch%3Amaster)
[![Pursuit](https://pursuit.purescript.org/packages/purescript-canvas/badge)](https://pursuit.purescript.org/packages/purescript-canvas)

Canvas bindings for PureScript.

## Installation

```
spago install canvas
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-canvas).
