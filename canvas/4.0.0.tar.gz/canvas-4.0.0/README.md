# purescript-canvas

[![Latest release](http://img.shields.io/bower/v/purescript-canvas.svg)](https://github.com/purescript-contrib/purescript-canvas/releases)

Canvas bindings for PureScript

- [Module Documentation](generated-docs/)

## Installing

    bower i purescript-canvas
