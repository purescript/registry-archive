# purescript-canvas

Canvas bindings for PureScript

- [Module Documentation](docs/)

## Installing

    bower i purescript-canvas
