# purescript-observable-classy

[![Latest release](http://img.shields.io/github/release/Risto-Stevcev/purescript-observable-classy.svg)](https://github.com/Risto-Stevcev/purescript-observable-classy/releases)
[![Build Status](https://travis-ci.org/Risto-Stevcev/purescript-observable-classy.svg?branch=master)](https://travis-ci.org/Risto-Stevcev/purescript-observable-classy)

A purescript typeclass for the ES observable interface

## Installation

```
bower install purescript-observable-classy
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-observable-classy).
