# purescript-wkhtmltopdf

Bindings for the Node utility that calls wkhtmltopdf on the command line.
