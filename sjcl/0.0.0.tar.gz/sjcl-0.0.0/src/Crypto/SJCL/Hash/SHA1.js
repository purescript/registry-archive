"use strict";

var sjcl = require('sjcl');

exports.sha1 = sjcl.hash.sha1;
