"use strict";

var sjcl = require('sjcl');

exports.ripemd160 = sjcl.hash.ripemd160;
