"use strict";

var sjcl = require('sjcl');

exports.sha256 = sjcl.hash.sha256;
