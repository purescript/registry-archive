"use strict";

var sjcl = require('sjcl');

exports.sha512 = sjcl.hash.sha512;
