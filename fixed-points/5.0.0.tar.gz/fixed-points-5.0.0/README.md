# purescript-fixed-points

[![Latest release](http://img.shields.io/github/release/slamdata/purescript-fixed-points.svg)](https://github.com/slamdata/purescript-fixed-points/releases)
[![Build status](https://travis-ci.org/slamdata/purescript-fixed-points.svg?branch=master)](https://travis-ci.org/slamdata/purescript-fixed-points)

Types for the least (`Mu`) and greatest (`Nu`) fixed points of functors.

## Installation

```
bower install purescript-fixed-points
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-fixed-points).
