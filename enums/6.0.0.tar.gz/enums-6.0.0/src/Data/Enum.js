export function toCharCode(c) {
  return c.charCodeAt(0);
}

export function fromCharCode(c) {
  return String.fromCharCode(c);
}
