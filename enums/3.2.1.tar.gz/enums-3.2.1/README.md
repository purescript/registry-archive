# purescript-enums

[![Latest release](http://img.shields.io/github/release/purescript/purescript-enums.svg)](https://github.com/purescript/purescript-enums/releases)
[![Build status](https://travis-ci.org/purescript/purescript-enums.svg?branch=master)](https://travis-ci.org/purescript/purescript-enums)

Operations for sequentially ordered types.

## Installation

```
bower install purescript-enums
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-enums).
