# purescript-enums

[![Latest release](http://img.shields.io/bower/v/purescript-enums.svg)](https://github.com/purescript/purescript-enums/releases)
[![Build Status](https://travis-ci.org/purescript/purescript-enums.svg?branch=master)](https://travis-ci.org/purescript/purescript-enums)
[![Dependency Status](https://www.versioneye.com/user/projects/55848c63363861001d000330/badge.svg?style=flat)](https://www.versioneye.com/user/projects/55848c63363861001d000330)

Operations for small ordered sum types.

## Installation

```
bower install purescript-enums
```

## Module documentation

- [Data.Enum](docs/Data/Enum.md)
