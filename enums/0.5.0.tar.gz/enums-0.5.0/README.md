# purescript-enums

[![Build Status](https://travis-ci.org/purescript/purescript-enums.svg?branch=master)](https://travis-ci.org/purescript/purescript-enums)

Operations for small ordered sum types.

## Installation

```
bower install purescript-enums
```

## Module documentation

- [Data.Enum](docs/Data.Enum.md)
