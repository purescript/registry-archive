
purescript-language-purescript-ast
==================

[![Build
Status](https://travis-ci.org/cdepillabout/purescript-language-purescript-ast.svg)](https://travis-ci.org/cdepillabout/purescript-language-purescript-ast)

This library provides the AST module for the PureScript compiler.


### Installing

```sh
$ npm install bower
$ ./node_modules/.bin/bower install --save purescript-language-purescript-ast
```

### Building / Testing

```sh
$ pulp build
$ pulp test
```

### Usage

*TODO*
