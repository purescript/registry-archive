# purescript-maybe

[![Latest release](http://img.shields.io/bower/v/purescript-maybe.svg)](https://github.com/purescript/purescript-maybe/releases)
[![Build Status](https://travis-ci.org/purescript/purescript-maybe.svg?branch=master)](https://travis-ci.org/purescript/purescript-maybe)
[![Dependency Status](https://www.versioneye.com/user/projects/55848c22363861001d000326/badge.svg?style=flat)](https://www.versioneye.com/user/projects/55848c22363861001d000326)

Optional values. `Maybe` is often used to capture failures and in cases where nullable values might otherwise have been used in other languages.

## Installation

```
bower install purescript-maybe
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-maybe).
