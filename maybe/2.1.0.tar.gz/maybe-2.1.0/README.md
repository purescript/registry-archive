# purescript-maybe

[![Latest release](http://img.shields.io/github/release/purescript/purescript-maybe.svg)](https://github.com/purescript/purescript-maybe/releases)
[![Build status](https://travis-ci.org/purescript/purescript-maybe.svg?branch=master)](https://travis-ci.org/purescript/purescript-maybe)

Optional values. `Maybe` is often used to capture failures and in cases where nullable values might otherwise have been used in other languages.

## Installation

```
bower install purescript-maybe
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-maybe).
