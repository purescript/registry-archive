
purescript-language-purescript-base
==================

[![Build
Status](https://travis-ci.org/cdepillabout/purescript-language-purescript-base.svg)](https://travis-ci.org/cdepillabout/purescript-language-purescript-base)

This library provides base modules for the PureScript compiler.


### Installing

```sh
$ npm install bower
$ ./node_modules/.bin/bower install --save purescript-language-purescript-base
```

### Building / Testing

```sh
$ pulp build
$ pulp test
```

### Usage

*TODO*
