# purescript-react-basic-compat

[![Build Status](https://travis-ci.org/lumihq/purescript-react-basic-compat.svg?branch=main)](https://travis-ci.org/lumihq/purescript-react-basic-compat)

_Warning: This library is depricated. We recommend using the [`react-basic-hooks`](https://github.com/spicydonuts/purescript-react-basic-hooks) or [`react-basic-classic`](https://github.com/lumihq/purescript-react-basic-classic) implementations instead._

This library contains the [React Basic](https://github.com/lumihq/purescript-react-basic) Compat implementation. For more info, see the React Basic [docs](https://react-basic-starter.github.io/)! (work in progress)
