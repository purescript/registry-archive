'use strict';

exports.reverse = function(array) {
  return array.reverse();
};
