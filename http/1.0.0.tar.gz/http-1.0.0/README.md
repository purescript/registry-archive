# purescript-http

Basic HTTP types.

## Installation

```
bower i purescript-http
```

## Documentation

- [Network.HTTP](docs/Network/HTTP.md)
