# purescript-http

Basic HTTP types.

## Installation

```
bower i purescript-http
```

## Documentation

Module documentation is [published on Pursuit](https://pursuit.purescript.org/packages/purescript-http).
