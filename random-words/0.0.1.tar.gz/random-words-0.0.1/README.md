# purescript-random-words

A PureScript library to generate random words from a dictionary.
