import fetch from "node-fetch";

export const nodeFetch = fetch;
