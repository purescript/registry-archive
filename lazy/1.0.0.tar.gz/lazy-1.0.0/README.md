# purescript-lazy

[![Latest release](http://img.shields.io/bower/v/purescript-lazy.svg)](https://github.com/purescript/purescript-lazy/releases)
[![Build Status](https://travis-ci.org/purescript/purescript-lazy.svg?branch=master)](https://travis-ci.org/purescript/purescript-lazy)
[![Dependency Status](https://www.versioneye.com/user/projects/55848c20363861001b00018f/badge.svg?style=flat)](https://www.versioneye.com/user/projects/55848c20363861001b00018f)

Call-by-need values.

## Installation

```
bower install purescript-lazy
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-lazy).
