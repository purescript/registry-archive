# purescript-lazy

[![Latest release](http://img.shields.io/github/release/purescript/purescript-lazy.svg)](https://github.com/purescript/purescript-lazy/releases)
[![Build status](https://travis-ci.org/purescript/purescript-lazy.svg?branch=master)](https://travis-ci.org/purescript/purescript-lazy)

Call-by-need values.

## Installation

```
bower install purescript-lazy
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-lazy).
