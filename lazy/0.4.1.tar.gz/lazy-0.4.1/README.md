# purescript-lazy

[![Build Status](https://travis-ci.org/purescript/purescript-lazy.svg?branch=master)](https://travis-ci.org/purescript/purescript-lazy)

Call-by-need values.

## Installation

```
bower install purescript-lazy
```

## Module documentation

- [Data.Lazy](docs/Data.Lazy.md)
