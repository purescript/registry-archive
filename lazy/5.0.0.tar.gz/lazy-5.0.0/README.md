# purescript-lazy

[![Latest release](http://img.shields.io/github/release/purescript/purescript-lazy.svg)](https://github.com/purescript/purescript-lazy/releases)
[![Build status](https://github.com/purescript/purescript-lazy/workflows/CI/badge.svg?branch=master)](https://github.com/purescript/purescript-lazy/actions?query=workflow%3ACI+branch%3Amaster)
[![Pursuit](https://pursuit.purescript.org/packages/purescript-lazy/badge)](https://pursuit.purescript.org/packages/purescript-lazy)

Call-by-need values.

## Installation

```
spago install lazy
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-lazy).
