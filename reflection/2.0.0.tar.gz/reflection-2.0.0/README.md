# purescript-reflection

Reflecting values at the type level

- [Module Documentation](docs/Data/Reflection.md)
- [Example](test/Main.purs)
