# purescript-reflection

Reflecting values at the type level, based on the [`reflection`](http://hackage.haskell.org/package/reflection) package in Haskell.

- [Module Documentation](generated-docs/Data/Reflection.md)
- [Example](test/Main.purs)
