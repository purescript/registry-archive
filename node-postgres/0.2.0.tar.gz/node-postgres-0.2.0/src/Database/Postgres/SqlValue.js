'use strict';

// module Database.Postgres.SqlValue

exports.unsafeToSqlValue = function (x) {
  return x;
}

exports.nullSqlValue = null;
