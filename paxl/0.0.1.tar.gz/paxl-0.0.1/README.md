# purescript-paxl

this is meant to be a purescript translation of Haxl, using row types to constrain the number of data sources available for use

# todo

- [ ] cached requests
- [ ] documentation
- [ ] use Fail instances to get better error messages
- [ ] write a nontrivial example
- [ ] idk
