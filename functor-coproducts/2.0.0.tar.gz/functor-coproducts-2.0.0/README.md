# purescript-functor-coproducts

[![Latest release](http://img.shields.io/bower/v/purescript-functor-coproducts.svg)](https://github.com/purescript/purescript-functor-coproducts/releases)
[![Build Status](https://travis-ci.org/purescript/purescript-functor-coproducts.svg?branch=master)](https://travis-ci.org/purescript/purescript-functor-coproducts)
[![Dependency Status](https://www.versioneye.com/user/projects/56f5381635630e0029db06e6/badge.svg?style=flat)](https://www.versioneye.com/user/projects/56f5381635630e0029db06e6)

Functor coproducts.

## Installation

```
bower install purescript-functor-coproducts
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-functor-coproducts).
