# purescript-restify-router

A PureScript wrapper around [restify-router](https://github.com/ukayani/restify-router).

This library is a work in progress. Most of the code is inspired by
[purescript-express](https://github.com/nkly/purescript-express).

## Installation

```
bower install --save purescript-restify-router
npm install --save restify-router
```

## See Also

For a wrapper around restify, see
[purescript-restify](https://github.com/freqlabs/purescript-restify).
