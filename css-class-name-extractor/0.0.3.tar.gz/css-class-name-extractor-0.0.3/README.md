# CssClassNameExtractor

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Test](https://github.com/himanoa/class-name-extractor/actions/workflows/ci.yml/badge.svg)](https://github.com/himanoa/class-name-extractor/actions/workflows/ci.yml)

[class-name-extractor](https://github.com/himanoa/class-name-extractor) 's backend

## Installation

```bash
spago install css-class-name-extractor
```

## Feedback and Contributions

If you find any bugs or issues while using the tool, please create an Issue.

## LICENSE

MIT
