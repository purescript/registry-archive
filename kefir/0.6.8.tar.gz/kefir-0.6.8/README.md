purescript-kefir
================
[![Build Status](https://travis-ci.org/philopon/purescript-kefir.svg?branch=master)](https://travis-ci.org/philopon/purescript-kefir)
[![Bower version](https://badge.fury.io/bo/purescript-kefir.svg)](http://badge.fury.io/bo/purescript-kefir)
[![devDependency Status](https://david-dm.org/philopon/purescript-kefir/dev-status.svg)](https://david-dm.org/philopon/purescript-kefir#info=devDependencies)

kefir binding for purescript

- [Module documentation](docs/FRP/Kefir.md)
