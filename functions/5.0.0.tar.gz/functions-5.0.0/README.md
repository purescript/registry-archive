# purescript-functions

[![Latest release](http://img.shields.io/github/release/purescript/purescript-functions.svg)](https://github.com/purescript/purescript-functions/releases)
[![Build status](https://github.com/purescript/purescript-functions/workflows/CI/badge.svg?branch=master)](https://github.com/purescript/purescript-functions/actions?query=workflow%3ACI+branch%3Amaster)
[![Pursuit](https://pursuit.purescript.org/packages/purescript-functions/badge)](https://pursuit.purescript.org/packages/purescript-functions)

Function combinators and types for uncurried multi-argument functions.

## Installation

```
spago install functions
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-functions).
