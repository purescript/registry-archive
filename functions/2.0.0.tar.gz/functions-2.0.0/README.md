# purescript-functions

[![Latest release](http://img.shields.io/bower/v/purescript-functions.svg)](https://github.com/purescript/purescript-functions/releases)
[![Build Status](https://travis-ci.org/purescript/purescript-functions.svg?branch=master)](https://travis-ci.org/purescript/purescript-functions)
[![Dependency Status](https://www.versioneye.com/user/projects/55848cea363861001500040b/badge.svg?style=flat)](https://www.versioneye.com/user/projects/55848cea363861001500040b)

Function combinators and types for uncurried multi-argument functions.

## Installation

```
bower install purescript-functions
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-functions).
