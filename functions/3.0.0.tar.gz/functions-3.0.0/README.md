# purescript-functions

[![Latest release](http://img.shields.io/github/release/purescript/purescript-functions.svg)](https://github.com/purescript/purescript-functions/releases)
[![Build status](https://travis-ci.org/purescript/purescript-functions.svg?branch=master)](https://travis-ci.org/purescript/purescript-functions)

Function combinators and types for uncurried multi-argument functions.

## Installation

```
bower install purescript-functions
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-functions).
