const framerMotion = require("framer-motion")

exports.infinity = Infinity

