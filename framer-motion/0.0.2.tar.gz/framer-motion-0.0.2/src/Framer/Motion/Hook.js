const framerMotion = require("framer-motion")

exports.useViewportScrollImpl = framerMotion.useViewportScroll
exports.useTransformImpl = framerMotion.useTransform
exports.useSpringImpl = framerMotion.useSpring
exports.useAnimationImpl = framerMotion.useAnimation