export const infinity = Infinity

