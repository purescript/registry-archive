# purescript-aws-sdk

[![Latest release](https://img.shields.io/bower/v/purescript-aws-sdk.svg)](https://github.com/plippe/purescript-aws-sdk/releases)

## Getting started

```sh
bower install purescript-aws-sdk
npm install aws-sdk # bower package seems broken :(
```

## Module documentation
Module documentation is [published on GitHub](https://github.com/plippe/purescript-aws-sdk/tree/master/docs).

## Development

```sh
cat Makefile
```
