# purescript-ejson

[![Latest release](http://img.shields.io/bower/v/purescript-ejson.svg)](https://github.com/purescript/purescript-ejson/releases)
[![Build Status](https://travis-ci.org/slamdata/purescript-ejson.svg?branch=master)](https://travis-ci.org/slamdata/purescript-ejson)
[![Dependency Status](https://www.versioneye.com/user/projects/578d451f3e6a8b00457f8efe/badge.svg?style=flat)](https://www.versioneye.com/user/projects/578d451f3e6a8b00457f8efe)

EJSON data representation, as used by [Quasar](https://github.com/quasar-analytics/quasar).

## Installation

```
bower install purescript-ejson
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-ejson).
