# purescript-ejson

[![Latest release](http://img.shields.io/github/release/slamdata/purescript-ejson.svg)](https://github.com/slamdata/purescript-ejson/releases)
[![Build status](https://travis-ci.org/slamdata/purescript-ejson.svg?branch=master)](https://travis-ci.org/slamdata/purescript-ejson)

EJSON data representation, as used by [Quasar](https://github.com/quasar-analytics/quasar).

## Installation

```
bower install purescript-ejson
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-ejson).
