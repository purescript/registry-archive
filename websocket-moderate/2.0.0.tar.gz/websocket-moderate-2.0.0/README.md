# purescript-websocket-moderate

An alternative websocket client implementation for servers and browsers.
