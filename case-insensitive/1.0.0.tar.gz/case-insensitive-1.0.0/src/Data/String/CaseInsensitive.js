'use strict';

exports.toUpper = function(s) {
  return s.toUpperCase();
};
