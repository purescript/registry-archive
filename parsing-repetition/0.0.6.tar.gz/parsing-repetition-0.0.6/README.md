# purescript-parsing-repetition

Helper functions for the repetition of PureScript parsers, e.g. range of number of occurrences and validation constraints on trailing input.
