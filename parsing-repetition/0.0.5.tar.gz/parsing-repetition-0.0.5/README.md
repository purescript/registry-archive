# purescript-parsing-repetition

Helper functions for the repetition of PureScript parsers, e.g. range of number of occurrences and validation constraints on trailing input.

Current unit tests can be run with `pulp test` after cloning the project and running `bower install`.
