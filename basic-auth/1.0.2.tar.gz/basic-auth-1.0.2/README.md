# purescript-basic-auth

[![Latest release](http://img.shields.io/github/release/oreshinya/purescript-basic-auth.svg)](https://github.com/oreshinya/purescript-basic-auth/releases)

Basic authentication helper.

## Installation

### Bower

```
$ bower install purescript-basic-auth
```

### Spago

```
$ spago install basic-auth
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-basic-auth).

## LICENSE

MIT
