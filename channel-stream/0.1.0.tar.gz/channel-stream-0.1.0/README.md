# Channel.Stream

Provides a `Node.Stream` backend for the [channel](https://github.com/ConnorDillon/purescript-channel) package.
