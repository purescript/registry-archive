purescript client code for talking to [servant-subscriber](https://github.com/eskimor/servant-subscriber).
