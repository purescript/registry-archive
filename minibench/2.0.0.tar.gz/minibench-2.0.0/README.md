# purescript-minibench

[![Latest release](http://img.shields.io/github/release/purescript/purescript-minibench.svg)](https://github.com/purescript/purescript-minibench/releases)
[![Build Status](https://travis-ci.org/purescript/purescript-minibench.svg?branch=master)](https://travis-ci.org/purescript/purescript-minibench)

A minimal benchmarking library

## Installation

```
bower install purescript-minibench
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-minibench).
