# purescript-minibench

[![Latest release](http://img.shields.io/github/release/purescript/purescript-minibench.svg)](https://github.com/purescript/purescript-minibench/releases)
[![Build status](https://github.com/purescript/purescript-minibench/workflows/CI/badge.svg?branch=master)](https://github.com/purescript/purescript-minibench/actions?query=workflow%3ACI+branch%3Amaster)
[![Pursuit](https://pursuit.purescript.org/packages/purescript-minibench/badge)](https://pursuit.purescript.org/packages/purescript-minibench)

A minimal benchmarking library

## Installation

```
spago install minibench
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-minibench).
