"use strict";

exports.hrTime = process.hrtime;

exports.toFixed = function(n) {
  return n.toFixed(2);
};
