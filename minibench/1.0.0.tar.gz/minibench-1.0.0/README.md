# purescript-minibench

[![Build Status](https://travis-ci.org/paf31/purescript-minibench.svg?branch=master)](https://travis-ci.org/paf31/purescript-minibench)

A tiny benchmarking library

Documentation is available [on Pursuit](https://pursuit.purescript.org/packages/purescript-minibench).
