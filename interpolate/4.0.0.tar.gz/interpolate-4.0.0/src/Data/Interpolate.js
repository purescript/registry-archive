export const unsafeCrashWith = function(msg) {
  throw new Error(msg);
}
