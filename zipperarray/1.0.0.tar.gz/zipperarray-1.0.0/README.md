purescript-zipperarray
======================

A non-empty array with one element focused.
