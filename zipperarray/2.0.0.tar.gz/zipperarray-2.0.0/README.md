purescript-zipperarray
======================

A non-empty array with one element focused.

## License

Licensed under a MIT license

## Documentation

- Module documentation is [published on Pursuit](https://pursuit.purescript.org/packages/purescript-zipperarray).
