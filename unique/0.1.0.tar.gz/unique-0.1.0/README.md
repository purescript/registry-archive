purescript-unique [![Build Status](https://travis-ci.org/mechairoi/purescript-unique.svg?branch=master)](https://travis-ci.org/mechairoi/purescript-unique)
===
Data.Unique for PureScript.

## Documentations
- [Data.Unique](docs/Data/Unique.md)
