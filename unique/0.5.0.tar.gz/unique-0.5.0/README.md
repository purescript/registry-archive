# purescript-unique

[![Build Status](https://travis-ci.org/mechairoi/purescript-unique.svg?branch=master)](https://travis-ci.org/mechairoi/purescript-unique)

Data.Unique for PureScript.

## Documentations
- [purescript-unique on Pursuit](https://pursuit.purescript.org/packages/purescript-unique)
