# purescript-node-mongodb

(Alpha Release)