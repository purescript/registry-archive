# purescript-versions

A small library defining data types and operations on software versions.

Documentation is [on Pursuit](http://pursuit.purescript.org/packages/purescript-versions/).
