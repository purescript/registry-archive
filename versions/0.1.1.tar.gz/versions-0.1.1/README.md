# purescript-versions

A small library defining data types and operations on software versions.

Documentation is [on Pursuit](pursuit.purescript.org/packages/purescript-versions/).
