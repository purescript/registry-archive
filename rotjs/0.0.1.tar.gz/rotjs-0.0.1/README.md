# purescript-rotjs

[PureScript](http://www.purescript.org/) bindings for the [Rot.js](https://github.com/ondras/rot.js) Roguelike library.
