# purescript-polymorphic-vectors

## Installation

```sh
spago install polymorphic-vectors
```

## Documentation

### Reference

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-polymorphic-vectors).
