# purescript-polymorphic-vectors

## Installation

```sh
spago install polymorphic-vectors
```

## Developing

Open the REPL using `npm run repl` (`npx spago -x dev.dhall repl`).

## Documentation

### Reference

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-polymorphic-vectors).
