# purescript-domparser

[`DOMParser`](https://developer.mozilla.org/docs/Web/API/DOMParser) wrapper for integration with PureScript DOM.


[![Latest release](http://img.shields.io/github/release/toastal/purescript-domparser.svg)](https://github.com/purescript/domparser/releases)


## Installation

```bash
bower install purescript-domparser
```

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/domparser).

