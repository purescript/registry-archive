# purescript-dynamic-buffer

Growable buffers

Can be used to build up binary data. Inspired by OCaml's buffer type.

## License
Copyright 2020 Christoph Hegemann

This software is subject to the terms of the Mozilla Public License, v. 2.0. If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
