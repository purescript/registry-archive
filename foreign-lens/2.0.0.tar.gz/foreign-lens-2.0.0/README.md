# purescript-foreign-lens

A lens-compatible set of getters for purescript-foreign

- [Module Documentation](docs/Data/Foreign/Lens.md)
- [Example](test/Main.purs)
