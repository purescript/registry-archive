# purescript-foreign-lens

[![Latest release](http://img.shields.io/github/release/purescript-contrib/purescript-foreign-lens.svg)](https://github.com/purescript/purescript-foreign-lens/releases)
[![Build status](https://travis-ci.org/purescript-contrib/purescript-foreign-lens.svg?branch=master)](https://travis-ci.org/purescript-contrib/purescript-foreign-lens)
[![Maintainer: paf31](https://img.shields.io/badge/maintainer-paf31-lightgrey.svg)](http://github.com/paf31)


A lens-compatible set of getters for purescript-foreign

- [Module Documentation](docs/Data/Foreign/Lens.md)
- [Example](test/Main.purs)
