"use strict";

exports.unsafeStringify = function(a) {
  return JSON.stringify(a);
}
