# purescript-node-process

[![Latest release](http://img.shields.io/github/release/purescript-node/purescript-node-process.svg)](https://github.com/purescript-node/purescript-node-process/releases)
[![Build status](https://github.com/purescript-node/purescript-node-process/workflows/CI/badge.svg?branch=master)](https://github.com/purescript-node/purescript-node-process/actions?query=workflow%3ACI+branch%3Amaster)
[![Pursuit](https://pursuit.purescript.org/packages/purescript-node-process/badge)](https://pursuit.purescript.org/packages/purescript-node-process)

The Node.js global `process` object in PureScript.

## Installation

```
spago install node-process
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-node-process).
