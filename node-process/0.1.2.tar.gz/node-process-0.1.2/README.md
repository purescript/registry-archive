# purescript-node-process

Access the Node.js global `process` object in PurScript.

- [Module Documentation](docs/)
