# PureScript Fakerjs

PureScript version of https://github.com/faker-js/faker/

TODO:

1. use Gen monad, dont use Effect, for this - reimplement all functions outselves
