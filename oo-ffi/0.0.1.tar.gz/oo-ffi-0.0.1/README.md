## Purescript OO FFI

[![Build Status](https://travis-ci.org/CapillarySoftware/purescript-oo-ffi.svg?branch=master)](https://travis-ci.org/CapillarySoftware/purescript-oo-ffi)

A collection of helper functions for binding into foreign OO style apis




