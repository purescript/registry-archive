# Purescript-Jolly-Pong

## This library is meant to be used as reference code for your own implementations.

![](https://i.imgur.com/uNv6ewT.png)

Don't use this library and expect things to not break -- they inevitably will.

For the rest of you who want to go full YOLO, take a look at the [tests](test/Main.purs) and start reading about row types and variants. You might be interested in reading material from:

* Purescript-Variant's docs https://github.com/natefaubion/purescript-variant
* Some more about row types and Variants here: http://qiita.com/kimagure/items/eeb40541fc56b8dba2cc
