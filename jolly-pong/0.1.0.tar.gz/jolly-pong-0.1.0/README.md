# Purescript-Jolly-Pong

## This library is only meant to be used if you are stuck with having to integrate with an existing Redux project and you are on your way to migrating your application to a more sane approach.

![](https://i.imgur.com/uNv6ewT.png)

Don't use this library and expect things to not break -- they inevitably will.

For the rest of you who want to go full YOLO, take a look at the [tests](test/Main.purs) and start reading about row types and variants. You might be interested in reading mateiral from:

* Purescript-Variant's docs https://github.com/natefaubion/purescript-variant
* Some more about row types and Variants here: http://qiita.com/kimagure/items/eeb40541fc56b8dba2cc
