# purescript-aff-free

[![Latest release](http://img.shields.io/bower/v/purescript-aff-free.svg)](https://github.com/slamdata/purescript-aff-free/releases)
[![Build Status](https://travis-ci.org/slamdata/purescript-aff-free.svg?branch=master)](https://travis-ci.org/slamdata/purescript-aff-free)
[![Dependency Status](https://www.versioneye.com/user/projects/56e3557fdf573d00495abbdd/badge.svg?style=flat)](https://www.versioneye.com/user/projects/56e3557fdf573d00495abbdd)

A utility type class for lifting `Aff` values into a `Free` monad.

## Installation

``` purescript
bower install purescript-aff-free
```

## Module documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-aff-free).
