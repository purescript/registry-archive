# purescript-aff-free

[![Latest release](http://img.shields.io/github/release/slamdata/purescript-aff-free.svg)](https://github.com/slamdata/purescript-aff-free/releases)
[![Build status](https://travis-ci.org/slamdata/purescript-aff-free.svg?branch=master)](https://travis-ci.org/slamdata/purescript-aff-free)

A utility type class for lifting `Aff` values into a `Free` monad.

## Installation

``` purescript
bower install purescript-aff-free
```

## Module documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-aff-free).
