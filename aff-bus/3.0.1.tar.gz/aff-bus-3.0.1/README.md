# purescript-aff-bus

[![Latest release](http://img.shields.io/github/release/slamdata/purescript-aff-bus.svg)](https://github.com/slamdata/purescript-aff-bus/releases)
[![Build status](https://travis-ci.org/slamdata/purescript-aff-bus.svg?branch=master)](https://travis-ci.org/slamdata/purescript-aff-bus)

Many-to-many broadcasting.

## Installation

```
bower install purescript-aff-bus
```

## Documentation

- Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-aff-bus).

