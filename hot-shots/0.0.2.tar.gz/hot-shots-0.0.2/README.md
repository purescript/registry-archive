# purescript-hot-shots

[![Build Status](https://travis-ci.org/mcoffin/purescript-hot-shots.svg?branch=master)](https://travis-ci.org/mcoffin/purescript-hot-shots)
![Bower](https://img.shields.io/bower/v/purescript-hot-shots.svg)

Purescript bindings for [hot-shots](https://www.npmjs.com/package/hot-shots)
