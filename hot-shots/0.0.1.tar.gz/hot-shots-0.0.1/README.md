# purescript-hot-shots

Purescript bindings for [hot-shots](https://www.npmjs.com/package/hot-shots)
