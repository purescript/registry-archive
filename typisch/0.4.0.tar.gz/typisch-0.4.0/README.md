# purescript-typisch

Some conveniences for type-level programming.

## Copyright and License

Copyright (c) 2021 James Laver and Gargantext team

This software is free and open source software licensed under the
terms of the Mozilla Public License (MPL) 2.0

