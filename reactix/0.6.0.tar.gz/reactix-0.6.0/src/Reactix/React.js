'use strict';

import * as React from 'react';
import * as ReactDom from 'react-dom';

export let react = React;
export let reactDOM = ReactDom;

