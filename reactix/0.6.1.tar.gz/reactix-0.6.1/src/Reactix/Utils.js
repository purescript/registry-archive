'use strict';

export function _tuple(ctor, v) { return ctor(v[0])(v[1]); };

