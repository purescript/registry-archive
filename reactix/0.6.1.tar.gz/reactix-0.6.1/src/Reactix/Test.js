'use strict';

import * as TestUtils from 'react-dom/test-utils';
import * as TestingLibrary from '@testing-library/react';

export let testUtils = TestUtils;
export let testingLibrary = TestingLibrary;
