/* global exports */
'use strict';

// module Data.Moment.Simple.Internal

exports.isValid = function (a) {
  return a.isValid();
};
