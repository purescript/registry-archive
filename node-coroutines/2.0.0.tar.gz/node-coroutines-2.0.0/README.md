# purescript-node-coroutines

Coroutines for working with Node streams

- [Module Documentation](generated-docs/)
- [Example](test/Main.purs)
