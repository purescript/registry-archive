# purescript-node-coroutines

Coroutines for working with Node streams
