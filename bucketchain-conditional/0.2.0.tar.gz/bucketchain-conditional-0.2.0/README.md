# purescript-bucketchain-conditional

[![Latest release](http://img.shields.io/github/release/Bucketchain/purescript-bucketchain-conditional.svg)](https://github.com/Bucketchain/purescript-bucketchain-conditional/releases)

A conditional GET middleware of [Bucketchain](https://github.com/Bucketchain/purescript-bucketchain).

## Installation

```
bower install purescript-bucketchain-conditional
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-bucketchain-conditional).

## LICENSE

MIT
