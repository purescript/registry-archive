"use strict";

// module Partial.Unsafe

exports._unsafePartial = function (f) {
  return f();
};
