"use strict";

// module Partial

exports._crashWith = function (msg) {
  throw new Error(msg);
};
