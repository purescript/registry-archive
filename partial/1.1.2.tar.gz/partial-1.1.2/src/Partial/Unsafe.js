"use strict";

// module Partial.Unsafe

exports.unsafePartial = function (f) {
  return f();
};
