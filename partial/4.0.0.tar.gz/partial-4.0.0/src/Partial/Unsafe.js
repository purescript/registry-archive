// module Partial.Unsafe

export const _unsafePartial = function (f) {
  return f();
};
