// module Partial

export const _crashWith = function (msg) {
  throw new Error(msg);
};
