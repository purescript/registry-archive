# purescript-partial

[![Latest release](http://img.shields.io/bower/v/purescript-partial.svg)](https://github.com/purescript/purescript-partial/releases)
[![Build Status](https://travis-ci.org/purescript/purescript-partial.svg?branch=master)](https://travis-ci.org/purescript/purescript-partial)

Utilities for working with partial functions.

## Installation

```
bower install purescript-partial
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-partial).
