On account of [debug](https://github.com/garyb/purescript-debug.git) and [debugger](https://github.com/paf31/purescript-debugger.git) already being taken, I present `debuggest` - a debugging library inspired by Elm's [Debug](https://package.elm-lang.org/packages/elm/core/latest/Debug).

`ursi.debug` on [purs-nix](https://github.com/ursi/purs-nix).
