"use strict";

var CSSTransition = require('react-transition-group').CSSTransition;

exports.cssTransitionImpl = CSSTransition;
