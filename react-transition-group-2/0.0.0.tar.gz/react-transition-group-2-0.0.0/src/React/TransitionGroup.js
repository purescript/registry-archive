"use strict";

var TransitionGroup = require('react-transition-group').TransitionGroup;

exports.transitionGroupImpl = TransitionGroup;
