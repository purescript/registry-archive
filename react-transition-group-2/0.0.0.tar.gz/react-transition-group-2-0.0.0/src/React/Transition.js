"use strict";

var Transition = require('react-transition-group').Transition;

exports.transitionImpl = Transition;
