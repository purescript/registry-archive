export const singleton = (x) => [x];
