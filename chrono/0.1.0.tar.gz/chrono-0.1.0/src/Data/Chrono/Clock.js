'use strict';

// module Data.Chrono.Clock

exports.systemClock = function() {
    return Date.now();
};
