# purescript-react-basic-classic

[![Build Status](https://travis-ci.com/lumihq/purescript-react-basic-classic.svg?branch=main)](https://travis-ci.com/lumihq/purescript-react-basic-classic)

This library contains the [React Basic](https://github.com/lumihq/purescript-react-basic) Classic implementation.
