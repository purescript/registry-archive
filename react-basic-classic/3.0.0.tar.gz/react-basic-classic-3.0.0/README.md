# purescript-react-basic-classic

[![Build Status](https://github.com/lumihq/purescript-react-basic-classic/actions/workflows/ci.yml/badge.svg)](https://github.com/lumihq/purescript-react-basic-classic/actions/workflows/ci.yml)
<a href="https://pursuit.purescript.org/packages/purescript-react-basic-classic">
  <img src="https://pursuit.purescript.org/packages/purescript-react-basic-classic/badge"
       alt="React Basic Classic on Pursuit">
  </img>
</a>

This library contains the [React Basic](https://github.com/lumihq/purescript-react-basic) Classic implementation.
