# purescript-platform
PureScript bindings for platform.js

To develop this library, run:

```sh
npm install
bower install
gulp
```
