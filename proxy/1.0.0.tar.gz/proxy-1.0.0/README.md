# purescript-proxy

[![Latest release](http://img.shields.io/bower/v/purescript-proxy.svg)](https://github.com/purescript/purescript-proxy/releases)
[![Build Status](https://travis-ci.org/purescript/purescript-proxy.svg?branch=master)](https://travis-ci.org/purescript/purescript-proxy)

Value proxy for type inputs.

## Installation

```
bower install purescript-proxy
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-proxy).
