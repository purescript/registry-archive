# purescript-stylesheet

### What is this?

A work in progress CSS-In-Purs that stores all the styles we want in a big hashmap and then updates the actual CSSOM whenever needed. 

### Does it work?

Broadly, yes. Whether it's performant or not is yet to be seen.

### Can I try it?

The best way to see the library in action is currently used in [React Stylesheet](https://github.com/danieljharvey/purescript-react-stylesheet) which uses this library with Purescript React.

### Documentation?

Are you suggesting this is not enough? More docs on [Pursuit](https://pursuit.purescript.org/packages/purescript-stylesheet/0.0.2)
