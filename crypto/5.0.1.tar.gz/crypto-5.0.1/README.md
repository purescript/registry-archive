# purescript-crypto

[![Latest release](http://img.shields.io/github/release/oreshinya/purescript-crypto.svg)](https://github.com/oreshinya/purescript-crypto/releases)

PureScript wrapper for `crypto` module of NodeJS.

## Installation

### Bower

```
$ bower install purescript-crypto
```

### Spago

```
$ spago install crypto
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-crypto).

## LICENSE

MIT
