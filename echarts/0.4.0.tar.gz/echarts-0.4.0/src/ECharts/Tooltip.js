// module ECharts.Tooltip

exports.func2json = function(fn) {
    return fn;
};
