// module ECharts.Series.EventRiver

exports.jsDateToJson = function(date) {
    return date;
};
