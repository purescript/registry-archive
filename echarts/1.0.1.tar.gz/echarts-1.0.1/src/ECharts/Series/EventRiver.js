// module ECharts.Series.EventRiver

exports.jsDateToJson = function(date) {
    return date;
};

exports.jsonToJSDate = function(json) {
    return json;
};
