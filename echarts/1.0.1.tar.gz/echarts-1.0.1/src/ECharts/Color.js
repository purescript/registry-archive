// module ECharts.Color

exports.func2json = function(fn) {
    return fn;
};