// module ECharts.Symbol

exports.func2json = function(fn) {
    return fn;
};
