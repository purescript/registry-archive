# Redox React

[![Maintainer: coot](https://img.shields.io/badge/maintainer-coot-lightgrey.svg)](http://github.com/coot) [![documentation](https://pursuit.purescript.org/packages/purescript-react-redox/badge)](https://pursuit.purescript.org/packages/purescript-react-redox)
[![Build Status](https://travis-ci.org/coot/purescript-react-redox.svg?branch=master)](https://travis-ci.org/coot/purescript-react-redox)

[Redox](https://github.com/coot/purescript-redox) bindings for React.
