# Redox React

[![Maintainer: coot](https://img.shields.io/badge/maintainer-coot-lightgrey.svg)](http://github.com/coot) [![documentation](https://pursuit.purescript.org/packages/purescript-react-redox/badge)](https://pursuit.purescript.org/packages/purescript-react-redox)

[Redox](https://github.com/coot/purescript-redox) bindings for React.
