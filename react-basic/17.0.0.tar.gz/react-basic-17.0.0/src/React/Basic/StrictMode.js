import React from "react";
export const strictMode_ = React.StrictMode;
