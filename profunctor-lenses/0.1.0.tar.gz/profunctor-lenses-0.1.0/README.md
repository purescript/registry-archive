# purescript-profunctor-lenses

Pure profunctor lenses.

- [Module Documentation](docs/Data/Lens.md)
- [Example](test/Main.purs)

## Usage

    bower install purescript-profunctor-lenses
