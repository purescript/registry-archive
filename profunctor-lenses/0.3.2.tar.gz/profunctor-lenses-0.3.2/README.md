# purescript-profunctor-lenses

[![Latest release](http://img.shields.io/bower/v/purescript-profunctor-lenses.svg)](https://github.com/purescript-contrib/purescript-profunctor-lenses/releases)
[![Build Status](https://travis-ci.org/purescript-contrib/purescript-profunctor-lenses.svg)](https://travis-ci.org/purescript-contrib/purescript-profunctor-lenses)
[![Maintainer: paf31](https://img.shields.io/badge/maintainer-paf31-lightgrey.svg)](http://github.com/paf31)

Pure profunctor lenses.

- [Module Documentation](docs/Data/Lens.md)
- [Example](test/Main.purs)

## Usage

    bower install purescript-profunctor-lenses
