# purescript-profunctor-lenses

[![Latest release](http://img.shields.io/bower/v/purescript-profunctor-lenses.svg)](https://github.com/paf31/purescript-profunctor-lenses/releases)
[![Build Status](https://travis-ci.org/paf31/purescript-profunctor-lenses.svg)](https://travis-ci.org/paf31/purescript-profunctor-lenses)

Pure profunctor lenses.

- [Module Documentation](docs/Data/Lens.md)
- [Example](test/Main.purs)

## Usage

    bower install purescript-profunctor-lenses
