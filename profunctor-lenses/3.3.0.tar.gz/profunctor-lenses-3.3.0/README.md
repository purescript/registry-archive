# purescript-profunctor-lenses

[![Latest release](http://img.shields.io/bower/v/purescript-profunctor-lenses.svg)](https://github.com/purescript-contrib/purescript-profunctor-lenses/releases)
[![Build Status](https://travis-ci.org/purescript-contrib/purescript-profunctor-lenses.svg)](https://travis-ci.org/purescript-contrib/purescript-profunctor-lenses)
[![Maintainer: paf31](https://img.shields.io/badge/maintainer-paf31-lightgrey.svg)](http://github.com/paf31)

Pure profunctor lenses.

## Installation

```
bower install purescript-profunctor-lenses
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-profunctor-lenses).

You can find an example usage [here](test/Main.purs).

