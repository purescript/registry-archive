# purescript-minimatch
Purescript bindings for minimatch lib
