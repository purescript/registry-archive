exports.heightImpl = function(p5, image) {
  return image.height;
};
exports.widthImpl = function(p5, image) {
  return image.width;
};
