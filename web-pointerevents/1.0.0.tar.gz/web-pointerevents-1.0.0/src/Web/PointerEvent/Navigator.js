export function maxTouchPoints(nav) {
  return function () {
    return nav.maxTouchPoints;
  };
}