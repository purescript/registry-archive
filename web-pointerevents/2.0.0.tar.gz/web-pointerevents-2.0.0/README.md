# purescript-web-pointerevents

Type definitions and low level interface implementations for the [W3C Pointer Events API](https://www.w3.org/TR/2022/WD-pointerevents3-20220321/).
