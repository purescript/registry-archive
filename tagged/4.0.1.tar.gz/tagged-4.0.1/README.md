# purescript-tagged

Phantom tags.

Inspired by [ekmett/tagged](https://github.com/ekmett/tagged).

