"strict";

exports._charIndex = function(e) {
    return e.charIndex;
};

exports._elapsedTime = function(e) {
    return e.elapsedTime;
};

exports._name = function(e) {
    return e.name;
};
