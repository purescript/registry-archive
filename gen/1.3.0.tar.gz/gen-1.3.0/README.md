# purescript-gen

[![Latest release](http://img.shields.io/github/release/purescript/purescript-gen.svg)](https://github.com/purescript/purescript-gen/releases)
[![Build status](https://travis-ci.org/purescript/purescript-gen.svg?branch=master)](https://travis-ci.org/purescript/purescript-gen)

A type class for random generator implementations.

## Installation

```
bower install purescript-gen
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-gen).
