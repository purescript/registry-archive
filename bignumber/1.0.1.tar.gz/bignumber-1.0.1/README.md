# purescript-bignumber

Bindings to [bignumber.js](https://github.com/MikeMcl/bignumber.js/).
