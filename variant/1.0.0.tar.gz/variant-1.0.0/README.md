# purescript-variant

[![Latest release](http://img.shields.io/github/release/natefaubion/purescript-variant.svg)](https://github.com/natefaubion/purescript-variant/releases)
[![Build status](https://travis-ci.org/natefaubion/purescript-variant.svg?branch=master)](https://travis-ci.org/natefaubion/purescript-variant)

Polymorphic variants for PureScript.

## Install

```
bower install purescript-variant
```

## Documentation

- Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-variant).
