// module IdePurescript.Modules

exports.tmpDir = function() {
  return require('os').tmpdir();
};
