# purescript-incremental-functions

Incremental lambda calculus in the HOAS style, based on

> "A Theory of Changes for Higher-Order Languages" by Cai, Giarrusso, Rendel and Ostermann.

- [Module Documentation](generated-docs/Data)
