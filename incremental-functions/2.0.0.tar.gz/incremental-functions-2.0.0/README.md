# purescript-incremental-functions

[![Build Status](https://travis-ci.org/paf31/purescript-incremental-functions.svg?branch=master)](https://travis-ci.org/paf31/purescript-incremental-functions)

Incremental lambda calculus in the HOAS style, based on

> "A Theory of Changes for Higher-Order Languages" by Cai, Giarrusso, Rendel and Ostermann.

- [Module Documentation](generated-docs/Data)
