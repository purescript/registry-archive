# purescript-pairing

Pairings of functors, based on <http://hackage.haskell.org/package/adjunctions-0.6.0/docs/Data-Functor-Zap.html>.

Documentation is available on [Pursuit](https://pursuit.purescript.org/packages/purescript-pairing).
