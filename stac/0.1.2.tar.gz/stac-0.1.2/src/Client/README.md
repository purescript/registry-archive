# STAC Client

The `Client.Stac` module includes methods for interacting with
STAC APIs.

## Quick start

forthcoming

## Documentation

forthcoming

## Contributing

forthcoming