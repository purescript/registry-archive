# STAC Model

The `Model.Foo` modules includes types modeling specific pieces of the STAC specification.

## Quick start

forthcoming

## Documentation

forthcoming

## Contributing

forthcoming