# purescript-iterable

[![Latest release](http://img.shields.io/github/release/Risto-Stevcev/purescript-iterable.svg)](https://github.com/Risto-Stevcev/purescript-iterable/releases)
[![Build Status](https://travis-ci.org/Risto-Stevcev/purescript-iterable.svg?branch=master)](https://travis-ci.org/Risto-Stevcev/purescript-iterable)

JS Iterable and Iterator interfaces for purescript

## Installation

```
bower install purescript-iterable
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-iterable).
