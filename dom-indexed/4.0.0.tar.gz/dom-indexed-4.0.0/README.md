# purescript-dom-indexed

[![Latest release](http://img.shields.io/github/release/slamdata/purescript-dom-indexed.svg)](https://github.com/slamdata/purescript-dom-indexed/releases)
[![Build status](https://travis-ci.org/slamdata/purescript-dom-indexed.svg?branch=master)](https://travis-ci.org/slamdata/purescript-dom-indexed)

Typed DOM attributes and properties

## Installation

```
bower install purescript-dom-indexed
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-dom-indexed).
