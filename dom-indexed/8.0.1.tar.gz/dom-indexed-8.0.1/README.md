# purescript-dom-indexed

[![Latest release](http://img.shields.io/github/release/purescript-halogen/purescript-dom-indexed.svg)](https://github.com/purescript-halogen/purescript-dom-indexed/releases)
[![Build status](https://github.com/purescript-halogen/purescript-dom-indexed/workflows/CI/badge.svg?branch=master)](https://github.com/purescript-halogen/purescript-dom-indexed/actions?query=workflow%3ACI+branch%3Amaster)
[![Pursuit](https://pursuit.purescript.org/packages/purescript-dom-indexed/badge)](https://pursuit.purescript.org/packages/purescript-dom-indexed)

Typed DOM attributes and properties

## Installation

```
spago install dom-indexed
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-dom-indexed).
