# purescript-nullable

A library for dealing with null values in foreign libraries.

## Installing

    bower i purescript-nullable

- [Module Documentation](docs/Data/Nullable.md)
