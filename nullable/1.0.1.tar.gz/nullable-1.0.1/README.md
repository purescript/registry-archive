# purescript-nullable

[![Latest release](http://img.shields.io/bower/v/purescript-nullable.svg)](https://github.com/purescript-contrib/purescript-nullable/releases)
[![Maintainer: paf31](https://img.shields.io/badge/maintainer-paf31-lightgrey.svg)](http://github.com/paf31)

A library for dealing with null values in foreign libraries.

## Installing

    bower i purescript-nullable

- [Module Documentation](docs/Data/Nullable.md)
