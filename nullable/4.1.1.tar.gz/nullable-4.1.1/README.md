# purescript-nullable

[![Latest release](http://img.shields.io/github/release/purescript-contrib/purescript-nullable.svg)](https://github.com/purescript-contrib/purescript-nullable/releases)
[![Build status](https://travis-ci.org/purescript-contrib/purescript-nullable.svg?branch=master)](https://travis-ci.org/purescript-contrib/purescript-nullable)
[![Pursuit](http://pursuit.purescript.org/packages/purescript-nullable/badge)](http://pursuit.purescript.org/packages/purescript-nullable/)
[![Maintainer: paf31](https://img.shields.io/badge/maintainer-paf31-lightgrey.svg)](http://github.com/paf31)

A library for dealing with null values in foreign libraries.

## Installing

    bower i purescript-nullable

- [Module Documentation](https://pursuit.purescript.org/packages/purescript-nullable)

## Contributing

Read the [contribution guidelines](https://github.com/purescript-contrib/purescript-nullable/blob/master/.github/contributing.md) to get started and see helpful related resources.
