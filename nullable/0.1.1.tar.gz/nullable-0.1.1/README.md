# purescript-nullable

A library for dealing with null values in foreign libraries.

