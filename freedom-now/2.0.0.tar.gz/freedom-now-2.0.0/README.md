# purescript-freedom-now

[![Latest release](http://img.shields.io/github/release/purescript-freedom/purescript-freedom-now.svg)](https://github.com/purescript-freedom/purescript-freedom-now/releases)

`Subscription` to get current time for [purescript-freedom](https://github.com/purescript-freedom/purescript-freedom).

[Demo](https://purescript-freedom.github.io/purescript-freedom-now/)

## Installation

### Bower

```
$ bower install purescript-freedom-now
```

### Spago

```
$ spago install freedom-now
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-freedom-now).

## LICENSE

MIT
