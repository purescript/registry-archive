# purescript-lines
Currently only supports non word-breaking lines.
