# purescript-unsafe-reference

[![Latest release](http://img.shields.io/github/release/purescript-contrib/purescript-unsafe-reference.svg)](https://github.com/purescript-contrib/purescript-unsafe-reference/releases)
[![Build status](https://travis-ci.org/purescript-contrib/purescript-unsafe-reference.svg?branch=master)](https://travis-ci.org/purescript-contrib/purescript-unsafe-reference)

Highly unsafe functions for comparing values using the runtime's strict (`===`) equality.

## Installation

```
bower install purescript-unsafe-reference
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-unsafe-reference).
