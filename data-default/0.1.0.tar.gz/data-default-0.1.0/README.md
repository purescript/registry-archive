# purescript-data-default

Typeclass for datatypes which have default values

## Documentation

- [Data.Default](docs/Data/Default.md)
