# purescript-unfoldable

[![Latest release](http://img.shields.io/bower/v/purescript-unfoldable.svg)](https://github.com/purescript/purescript-unfoldable/releases)
[![Build Status](https://travis-ci.org/purescript/purescript-unfoldable.svg?branch=master)](https://travis-ci.org/purescript/purescript-unfoldable)
[![Dependency Status](https://www.versioneye.com/user/projects/55848c8f36386100150003f1/badge.svg?style=flat)](https://www.versioneye.com/user/projects/55848c8f36386100150003f1)

Unfoldable functors.

## Installation

```
bower install purescript-unfoldable
```

## Module documentation

- [Data.Unfoldable](docs/Data/Unfoldable.md)
