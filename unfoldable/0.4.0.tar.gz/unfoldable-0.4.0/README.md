# purescript-unfoldable

[![Build Status](https://travis-ci.org/purescript/purescript-unfoldable.svg?branch=master)](https://travis-ci.org/purescript/purescript-unfoldable)

Unfoldable functors.

## Installation

```
bower install purescript-unfoldable
```

## Module documentation

- [Data.Unfoldable](docs/Data.Unfoldable.md)
