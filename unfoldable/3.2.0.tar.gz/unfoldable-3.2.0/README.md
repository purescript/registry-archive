# purescript-unfoldable

[![Latest release](http://img.shields.io/github/release/purescript/purescript-unfoldable.svg)](https://github.com/purescript/purescript-unfoldable/releases)
[![Build status](https://travis-ci.org/purescript/purescript-unfoldable.svg?branch=master)](https://travis-ci.org/purescript/purescript-unfoldable)

Unfoldable functors.

## Installation

```
bower install purescript-unfoldable
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-unfoldable).
