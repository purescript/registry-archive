# purescript-unfoldable

[![Latest release](http://img.shields.io/github/release/purescript/purescript-unfoldable.svg)](https://github.com/purescript/purescript-unfoldable/releases)
[![Build status](https://github.com/purescript/purescript-unfoldable/workflows/CI/badge.svg?branch=master)](https://github.com/purescript/purescript-unfoldable/actions?query=workflow%3ACI+branch%3Amaster)
[![Pursuit](https://pursuit.purescript.org/packages/purescript-unfoldable/badge)](https://pursuit.purescript.org/packages/purescript-unfoldable)

Unfoldable functors.

## Installation

```
spago install unfoldable
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-unfoldable).
