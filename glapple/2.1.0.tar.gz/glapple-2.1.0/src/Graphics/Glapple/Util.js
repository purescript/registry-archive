"use strict";

exports.createCanvasElement = () => document.createElement("canvas");
