# purescript-profunctor

[![Latest release](http://img.shields.io/github/release/purescript/purescript-profunctor.svg)](https://github.com/purescript/purescript-profunctor/releases)
[![Build Status](https://travis-ci.org/purescript/purescript-profunctor.svg?branch=master)](https://travis-ci.org/purescript/purescript-profunctor)

Profunctor typeclass.

## Installation

```
bower install purescript-profunctor
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-profunctor).
