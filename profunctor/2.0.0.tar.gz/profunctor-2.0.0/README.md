# purescript-profunctor

[![Latest release](http://img.shields.io/bower/v/purescript-profunctor.svg)](https://github.com/purescript/purescript-profunctor/releases)
[![Build Status](https://travis-ci.org/purescript/purescript-profunctor.svg?branch=master)](https://travis-ci.org/purescript/purescript-profunctor)
[![Dependency Status](https://www.versioneye.com/user/projects/55848c93363861001b00019f/badge.svg?style=flat)](https://www.versioneye.com/user/projects/55848c93363861001b00019f)

Profunctor typeclass.

## Installation

```
bower install purescript-profunctor
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-profunctor).
