# purescript-profunctor

[![Latest release](http://img.shields.io/github/release/purescript/purescript-profunctor.svg)](https://github.com/purescript/purescript-profunctor/releases)
[![Build status](https://github.com/purescript/purescript-profunctor/workflows/CI/badge.svg?branch=master)](https://github.com/purescript/purescript-profunctor/actions?query=workflow%3ACI+branch%3Amaster)
[![Pursuit](https://pursuit.purescript.org/packages/purescript-profunctor/badge)](https://pursuit.purescript.org/packages/purescript-profunctor)

Profunctor typeclass.

## Installation

```
spago install profunctor
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-profunctor).
