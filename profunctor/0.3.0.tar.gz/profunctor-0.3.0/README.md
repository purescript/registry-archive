# purescript-profunctor

[![Build Status](https://travis-ci.org/purescript/purescript-profunctor.svg?branch=master)](https://travis-ci.org/purescript/purescript-profunctor)

Profunctor typeclass.

## Installation

```
bower install purescript-profunctor
```

## Module documentation

- [Data.Profunctor](docs/Data.Profunctor.md)
- [Data.Profunctor.Choice](docs/Data.Profunctor.Choice.md)
- [Data.Profunctor.Strong](docs/Data.Profunctor.Strong.md)
