'use strict';

exports['null'] = null;
