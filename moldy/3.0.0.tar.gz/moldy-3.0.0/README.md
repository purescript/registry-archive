# purscript-moldy

[![Build status](https://travis-ci.org/LiamGoodacre/purescript-moldy.svg?branch=master)](https://travis-ci.org/LiamGoodacre/purescript-moldy)

* `Moldable` type class for monomorphic foldable types
* `Moldy` type for lifting `Moldable` types to `Foldable`
