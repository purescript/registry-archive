# purscript-moldy

* `Moldable` type class for monomorphic foldable types
* `Moldy` type for lifting `Moldable` types to `Foldable`

