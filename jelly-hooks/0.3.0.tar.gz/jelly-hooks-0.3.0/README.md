# Jelly Hooks

Hooks is a way to manage the application logic with [`jelly-signal`](https://github.com/yukikurage/purescript-jelly-signal).

This adds the Cleanup Effect, and provides the ability to describe the entire app in one monad or divide it into components.
