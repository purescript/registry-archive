/* global exports */
"use strict";

// module Data.Sequence.Internal

exports.unsafeCoerce = function(x) { return x; }
