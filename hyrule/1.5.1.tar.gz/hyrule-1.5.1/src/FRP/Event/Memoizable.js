exports.unsafeMarkAsMemoizable = function (e) {
	e.p$mmzbl = true;
	return e;
};
