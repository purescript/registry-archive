# purescript-event

The `Event` type, extracted from my `purescript-behaviors` library.

- [Module Documentation](generated-docs/FRP/)