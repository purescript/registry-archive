# purescript-strings

[![Latest release](http://img.shields.io/bower/v/purescript-strings.svg)](https://github.com/purescript/purescript-strings/releases)
[![Build Status](https://travis-ci.org/purescript/purescript-strings.svg?branch=master)](https://travis-ci.org/purescript/purescript-strings)
[![Dependency Status](https://www.versioneye.com/user/projects/55848c29363861001b000193/badge.svg?style=flat)](https://www.versioneye.com/user/projects/55848c29363861001b000193)

String and char utility functions, regular expressions.

## Installation

```
bower install purescript-strings
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-strings).
