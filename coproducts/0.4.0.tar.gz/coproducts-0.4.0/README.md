# purescript-coproducts

[![Build Status](https://travis-ci.org/purescript/purescript-coproducts.svg?branch=master)](https://travis-ci.org/purescript/purescript-coproducts)

Functor coproducts.

## Installation

```
bower install purescript-coproducts
```

## Module documentation

- [Data.Functor.Coproduct](docs/Data.Functor.Coproduct.md)
