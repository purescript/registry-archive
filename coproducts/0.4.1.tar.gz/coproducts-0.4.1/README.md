# purescript-coproducts

[![Latest release](http://img.shields.io/bower/v/purescript-coproducts.svg)](https://github.com/purescript/purescript-coproducts/releases)
[![Build Status](https://travis-ci.org/purescript/purescript-coproducts.svg?branch=master)](https://travis-ci.org/purescript/purescript-coproducts)
[![Dependency Status](https://www.versioneye.com/user/projects/55848c86363861001b00019d/badge.svg?style=flat)](https://www.versioneye.com/user/projects/55848c86363861001b00019d)

Functor coproducts.

## Installation

```
bower install purescript-coproducts
```

## Module documentation

- [Data.Functor.Coproduct](docs/Data/Functor/Coproduct.md)
