# url-immutable
Type-safe immutable bindings to the `URL` web / node api.
