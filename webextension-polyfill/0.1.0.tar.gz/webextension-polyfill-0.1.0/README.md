# purescript-webextension-polyfill

This is a PureScript wrapper for the webextension-polyfill library
# purescript-webextension-polyfill
