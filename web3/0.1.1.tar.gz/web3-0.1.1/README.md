# purescript-web3
Purescript bindings for Web3

## Getting Started
```
> git clone
> cd purescript-web3
> bower install
> npm install
> pulp build
> pulp test
```
## Resources

 - [web3.js repo](https://github.com/ethereum/web3.js)
 - [web3 Javascript API wiki](https://github.com/ethereum/wiki/wiki/JavaScript-API)
