# purescript-aws-request

## Getting started

```sh
bower install purescript-aws-request
npm install aws-sdk # bower package seems broken :(
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-aws-request).
