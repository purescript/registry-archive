# Cycle

This is a quickly done port of [Cycle.js](http://cycle.js.org) to purescript
built on top of my experimental stream library [Almost](https://gitub.com/Tylors/Almost)

### You're crazy and want to install this untested beast?
```
$ bower install purescript-cycle
```
