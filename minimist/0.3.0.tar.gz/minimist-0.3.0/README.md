# purescript-minimist

[![Build Status](https://travis-ci.org/mcoffin/purescript-minimist.svg?branch=master)](https://travis-ci.org/mcoffin/purescript-minimist)
![Bower](https://img.shields.io/bower/v/purescript-minimist.svg)
[![Issues Ready](https://img.shields.io/waffle/label/mcoffin/purescript-minimist/ready.svg)](https://waffle.io/mcoffin/purescript-minimist)
[![Issues In Progress](https://img.shields.io/waffle/label/mcoffin/purescript-minimist/in%20progress.svg)](https://waffle.io/mcoffin/purescript-minimist)

`purescript-minimist` is a [PureScript](http://purescript.org) wrapper for [minimist](https://github.com/substack/minimist).

# Documentation

Documentation is hosted on [Pursuit](https://pursuit.purescript.org/packages/purescript-minimist)
