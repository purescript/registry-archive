# purescript-minimist

[![Build Status](https://travis-ci.org/mcoffin/purescript-minimist.svg?branch=master)](https://travis-ci.org/mcoffin/purescript-minimist)

`purescript-minimist` is a [PureScript](http://purescript.org) wrapper for [minimist](https://github.com/substack/minimist).
