# purescript-aff-future

[![Latest release](http://img.shields.io/github/release/slamdata/purescript-aff-future.svg)](https://github.com/slamdata/purescript-aff-future/releases)
[![Build status](https://travis-ci.org/slamdata/purescript-aff-future.svg?branch=master)](https://travis-ci.org/slamdata/purescript-aff-future)

One-to-many asynchronous resolution.

## Installation

```
bower install purescript-aff-future
```

## Documentation

- Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-aff-future).

