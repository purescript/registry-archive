Impur
=====================

WIP static site generator for PureScript

Do not use yet, in frequent update.