exports.none = {
  toString: function() {
    return "none";
  }
};
