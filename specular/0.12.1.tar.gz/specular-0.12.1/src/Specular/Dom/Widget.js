// documentBody :: IOSync Node
exports.documentBody = function() {
  return document.body;
};
