# purescript-bucketchain-header-utils

[![Latest release](http://img.shields.io/github/release/Bucketchain/purescript-bucketchain-header-utils.svg)](https://github.com/Bucketchain/purescript-bucketchain-header-utils/releases)

The HTTP header utilities of [Bucketchain](https://github.com/Bucketchain/purescript-bucketchain).

## Installation

### Bower

```
$ bower install purescript-bucketchain-header-utils
```

### Spago

```
$ spago install bucketchain-header-utils
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-bucketchain-header-utils).

## LICENSE

MIT
