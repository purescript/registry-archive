// module Data.Rational

exports.abs = Math.abs;
