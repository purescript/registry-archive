# purescript-globals

[![Latest release](http://img.shields.io/bower/v/purescript-globals.svg)](https://github.com/purescript/purescript-globals/releases)
[![Build Status](https://travis-ci.org/purescript/purescript-globals.svg?branch=master)](https://travis-ci.org/purescript/purescript-globals)
[![Dependency Status](https://www.versioneye.com/user/projects/55848c2b363861001b000195/badge.svg?style=flat)](https://www.versioneye.com/user/projects/55848c2b363861001b000195)

Typed definitions for standard Javascript globals.

## Installation

```
bower install purescript-globals
```

## Module documentation

- [Global](docs/Global.md)
