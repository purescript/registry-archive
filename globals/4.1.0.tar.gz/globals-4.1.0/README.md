# purescript-globals

[![Latest release](http://img.shields.io/github/release/purescript/purescript-globals.svg)](https://github.com/purescript/purescript-globals/releases)
[![Build status](https://travis-ci.org/purescript/purescript-globals.svg?branch=master)](https://travis-ci.org/purescript/purescript-globals)

Typed definitions for standard Javascript globals.

## Installation

```
bower install purescript-globals
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-globals).

