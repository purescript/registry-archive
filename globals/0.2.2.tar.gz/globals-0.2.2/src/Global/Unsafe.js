/* globals exports, JSON */
"use strict";

// module Global.Unsafe

exports.unsafeStringify = function (x) {
  return JSON.stringify(x);
};
