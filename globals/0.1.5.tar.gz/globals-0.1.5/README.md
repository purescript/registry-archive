# Module Documentation

## Module Global

### Values

    infinity :: Number

    isFinite :: Number -> Boolean

    isNaN :: Number -> Boolean

    nan :: Number

    readFloat :: String -> Number

    readInt :: Number -> String -> Number