# purescript-globals

[![Build Status](https://travis-ci.org/purescript/purescript-globals.svg?branch=master)](https://travis-ci.org/purescript/purescript-globals)

Typed definitions for standard Javascript globals.

## Installation

```
bower install purescript-globals
```

## Module documentation

- [Global](docs/Global.md)
