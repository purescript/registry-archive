
purescript-words-lines
======================

[![Build
Status](https://travis-ci.org/cdepillabout/purescript-words-lines.svg)](https://travis-ci.org/cdepillabout/purescript-words-lines)

[`words`](http://hackage.haskell.org/package/base/docs/Prelude.html#v:words),
[`unwords`](http://hackage.haskell.org/package/base/docs/Prelude.html#v:unwords),
[`lines`](http://hackage.haskell.org/package/base/docs/Prelude.html#v:lines),
and
[`unlines`](http://hackage.haskell.org/package/base/docs/Prelude.html#v:unlines)
functions from Haskell.

### Installing

```sh
$ npm install bower
$ ./node_modules/.bin/bower install --save purescript-words-lines
```

### Building / Testing

```sh
$ pulp build
$ pulp test
```

### Usage

*TODO*
