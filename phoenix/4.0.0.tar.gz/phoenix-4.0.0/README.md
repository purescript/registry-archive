# purescript-phoenix

[![Maintainer: brandonhamilton](https://img.shields.io/badge/maintainer-brandonhamilton-lightgrey.svg)](http://github.com/brandonhamilton) ![Phoenix: 1.2.0](https://img.shields.io/badge/phoenix-1.2.0-lightgrey.svg)

[Phoenix Framework](http://www.phoenixframework.org) Bindings for PureScript.

## Installation

```
bower install purescript-phoenix
```

## Documentation

Module documentation is [published on Pursuit](https://pursuit.purescript.org/packages/purescript-phoenix/).


