PureScript wrapper around the [Spectacle](https://github.com/FormidableLabs/spectacle) slide deck library for use with [Pux](https://github.com/alexmingoia/purescript-pux).
You will need to also `npm install -S react react-dom spectacle` for this to work.

Example [here](https://github.com/spicydonuts/purescript-spectacle-presentation)!