# purescript-kleene-logic

[![Latest release](http://img.shields.io/github/release/Risto-Stevcev/purescript-kleene-logic.svg)](https://github.com/Risto-Stevcev/purescript-kleene-logic/releases)

Kleene Logic in purescript

## Installation

```
bower install purescript-kleene-logic
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-kleene-logic).
