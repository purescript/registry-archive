# halogen-canvas

Halogen component for html5 canvas. 

## Example
See the [line sketch example](https://grybiena.github.io/example/index.html#halogen-canvas-sketch).

## Documentation

Module documentation is [published on Pursuit](https://pursuit.purescript.org/packages/purescript-halogen-canvas).
