# purescript-halogen-datepicker

[![Latest release](http://img.shields.io/github/release/slamdata/purescript-halogen-datepicker.svg)](https://github.com/slamdata/purescript-halogen-datepicker/releases)
[![Build status](https://travis-ci.org/slamdata/purescript-halogen-datepicker.svg?branch=master)](https://travis-ci.org/slamdata/purescript-halogen-datepicker)

## Pickers included:

- Date
- Time
- DateTime
- Duration
- Interval

## Examples

To run examples

```bash
npm run build
http-server example
```

you can install [http-server using npm](https://www.npmjs.com/package/http-server)
