# purescript-halogen-datepicker

[![Latest release](http://img.shields.io/github/release/slamdata/purescript-halogen-datepicker.svg)](https://github.com/slamdata/purescript-halogen-datepicker/releases)
![Build Status](https://github.com/slamdata/purescript-halogen-datepicker/actions/workflows/ci.yml/badge.svg)

## Pickers included:

- Date
- Time
- DateTime
- Duration
- Interval

## Examples

To run examples

```bash
npm run build
http-server example
```

you can install [http-server using npm](https://www.npmjs.com/package/http-server)
