# purescript-sforce-remote-action
Purescript bindings for Salesforce Remote Actions
