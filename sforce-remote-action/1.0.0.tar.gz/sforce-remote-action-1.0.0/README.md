# purescript-sforce-remote-action

[![Build Status](https://travis-ci.org/Woody88/purescript-sforce-remote-action.svg?branch=master)](https://travis-ci.org/Woody88/purescript-sforce-remote-action)

Purescript bindings for [Salesforce Remote Actions](https://developer.salesforce.com/docs/atlas.en-us.pages.meta/pages/pages_js_remoting.htm#!)

## Getting Started

You can install this package using Bower:

```sh
bower install --save purescript-sforce-remote-action
```

See [the documentation](https://pursuit.purescript.org/packages/purescript-sforce-remote-action) for an overview of the API or take a look at the example in the test folder.
