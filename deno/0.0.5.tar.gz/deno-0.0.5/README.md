# purescript-deno

Deno bindings for Purescript

Implemented:
- [ ] [Std](https://deno.land/std@0.144.0)
  - [x] crypto (basic functionality)
  - [x] datetime
  - [x] dotenv
  - [x] fs
  - [x] http 
  - [x] log
  - [x] uuid


# Example Deno web server

An example deno web server can be found [here](https://github.com/njaremko/purescript-deno-example)
