export function _relatedTarget(e) {
  return e.relatedTarget;
}
