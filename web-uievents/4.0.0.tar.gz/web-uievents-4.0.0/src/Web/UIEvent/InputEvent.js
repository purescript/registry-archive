export function data_(e) {
  return e.data;
}

export function isComposing(e) {
  return e.isComposing;
}
