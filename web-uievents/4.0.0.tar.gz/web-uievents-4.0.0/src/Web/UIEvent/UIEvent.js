export function _view(e) {
  return e.view;
}

export function detail(e) {
  return e.detail;
}
