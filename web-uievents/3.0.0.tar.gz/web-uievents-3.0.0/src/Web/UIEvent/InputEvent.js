"use strict";

exports.data_ = function (e) {
  return e.data;
};

exports.isComposing = function (e) {
  return e.isComposing;
};
