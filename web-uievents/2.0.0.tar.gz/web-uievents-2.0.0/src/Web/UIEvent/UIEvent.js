"use strict";

exports._view = function (e) {
  return e.view;
};

exports.detail = function (e) {
  return e.detail;
};
