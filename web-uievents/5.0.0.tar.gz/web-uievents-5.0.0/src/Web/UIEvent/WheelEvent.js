export function deltaX(e) {
  return e.deltaX;
}

export function deltaY(e) {
  return e.deltaY;
}

export function deltaZ(e) {
  return e.deltaZ;
}

export function deltaModeIndex(e) {
  return e.deltaModeIndex;
}
