export function _data_(e) {
  return e.data;
}

export function isComposing(e) {
  return e.isComposing;
}

export function _inputType(e) {
  return e.inputType;
}