export function options(dle) {
  return function () {
    return dle.options;
  };
}
