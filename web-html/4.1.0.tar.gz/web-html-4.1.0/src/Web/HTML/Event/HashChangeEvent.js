export function oldURL(e) {
  return e.oldURL;
}

export function newURL(e) {
  return e.newURL;
}
