export function _form(le) {
  return function () {
    return le.form;
  };
}
