export function persisted(e) {
  return e.persisted;
}
