"use strict";

exports.readProp = function (prop, vs) {
  return vs[prop];
};
