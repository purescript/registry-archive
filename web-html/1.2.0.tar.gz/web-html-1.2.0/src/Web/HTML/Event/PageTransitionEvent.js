"use strict";

exports.persisted = function (e) {
  return e.persisted;
};
