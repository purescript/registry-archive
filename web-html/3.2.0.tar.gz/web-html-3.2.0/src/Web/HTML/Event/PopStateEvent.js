"use strict";

exports.state = function (e) {
  return e.state;
};
