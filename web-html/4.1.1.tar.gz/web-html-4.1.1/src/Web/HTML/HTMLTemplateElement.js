export function content(template) {
  return function () {
    return template.content;
  };
}
