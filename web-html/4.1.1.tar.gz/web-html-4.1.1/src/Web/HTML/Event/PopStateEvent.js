export function state(e) {
  return e.state;
}
