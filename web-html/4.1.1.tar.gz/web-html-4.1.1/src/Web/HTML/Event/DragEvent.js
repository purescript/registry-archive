export function dataTransfer(e) {
  return e.dataTransfer;
}
