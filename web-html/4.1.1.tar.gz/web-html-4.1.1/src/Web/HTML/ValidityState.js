export function readProp(prop, vs) {
  return vs[prop];
}
