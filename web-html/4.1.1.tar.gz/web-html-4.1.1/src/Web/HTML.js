const windowImpl = function () {
  return window;
};
export { windowImpl as window };
