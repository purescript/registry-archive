"use strict";

exports._form = function (le) {
  return function () {
    return le.form;
  };
};
