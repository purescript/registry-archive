# purescript-web-html

[![Latest release](http://img.shields.io/github/release/purescript-web/purescript-web-html.svg)](https://github.com/purescript-web/purescript-web-html/releases)
[![Build status](https://travis-ci.org/purescript-web/purescript-web-html.svg?branch=master)](https://travis-ci.org/purescript-web/purescript-web-html)

Type definitions and low level interface implementations for the W3C HTML5 API.

## Installation

```
bower install purescript-web-html
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-web-html).
