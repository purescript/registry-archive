# purescript-node-datagram

[![Latest release](http://img.shields.io/github/release/brandonhamilton/purescript-node-datagram.svg)](https://github.com/brandonhamilton/purescript-node-datagram/releases)
[![Build Status](https://travis-ci.org/brandonhamilton/purescript-node-datagram.svg?branch=master)](https://travis-ci.org/brandonhamilton/purescript-node-datagram)

A PureScript wrapper for Node's UDP/Datagram APIs.

## Installation

```
bower install purescript-node-datagram
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-node-datagram).