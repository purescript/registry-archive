# purescript-sketch

Sketch Javascript API wrapper for development of Sketch Plugin using Purescript

## Add purescript-sketch to your existing plugin projects

```
bower i purescript-sketch
```
