# purescript-murmur3

[![Build Status](https://travis-ci.com/paulyoung/purescript-murmur3.svg?branch=master)](https://travis-ci.com/paulyoung/purescript-murmur3)

A PureScript implementation of the Murmur3 hash function.

A direct port of [`Skinney/murmur3`](https://github.com/Skinney/murmur3).
