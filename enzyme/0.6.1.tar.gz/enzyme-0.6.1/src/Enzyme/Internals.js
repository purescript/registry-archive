"use strict"

exports.undefined = undefined
