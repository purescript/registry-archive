# purescript-enzyme
Purescript bindings for [enzyme](https://github.com/airbnb/enzyme) library.

# Installation
```
bower install purescript-enzyme
```

# Documentation
Module documentation is [published on Pursuit](http://pursuit.purescript.org/purescript-enzyme).
