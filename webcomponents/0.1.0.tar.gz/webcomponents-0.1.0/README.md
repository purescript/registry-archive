# purescript-webcomponents

[![Latest release](http://img.shields.io/github/release/Risto-Stevcev/purescript-webcomponents.svg)](https://github.com/Risto-Stevcev/purescript-webcomponents/releases)
[![Build Status](https://travis-ci.org/Risto-Stevcev/purescript-webcomponents.svg?branch=master)](https://travis-ci.org/Risto-Stevcev/purescript-webcomponents)

A web components wrapper for purescript

## Installation

```
bower install purescript-webcomponents
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-webcomponents).
