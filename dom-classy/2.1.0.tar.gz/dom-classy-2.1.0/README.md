# purescript-dom-classy

[![Latest release](http://img.shields.io/github/release/garyb/purescript-dom-classy.svg)](https://github.com/garyb/purescript-dom-classy/releases)
[![Build status](https://travis-ci.org/garyb/purescript-dom-classy.svg?branch=master)](https://travis-ci.org/garyb/purescript-dom-classy)

A library providing typeclasses to make working with the DOM more pleasant.

There's plenty of room for improvement, suggestions and additions are very welcome!

## Installation

```
bower install purescript-dom-classy
```

## Documentation

- Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-dom-classy).
