var ReduxMiniFF = require('./MiniFF')

exports.applyReducer = ReduxMiniFF.applyReducer
exports.combineReducers = ReduxMiniFF.combineReducers
exports.provider = ReduxMiniFF.provider
exports.connect = ReduxMiniFF.connect
exports.typeToString = ReduxMiniFF.typeToString
