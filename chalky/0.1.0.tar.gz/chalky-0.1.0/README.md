# purescript-chalk
PureScript bindings to chalk library
