# purescript-halogen-leaflet
Embedding leaflet geocharts to halogen
