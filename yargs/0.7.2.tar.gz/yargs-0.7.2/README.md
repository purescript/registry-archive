purescript-yargs [![Build Status](https://travis-ci.org/paf31/purescript-yargs.svg)](https://travis-ci.org/paf31/purescript-yargs)
================

PureScript bindings to the [yargs](https://github.com/chevex/yargs) command line argument parsing library, including an applicative interface.

- [Documentation](docs/Node/)
- [Examples](test/Main.purs)
