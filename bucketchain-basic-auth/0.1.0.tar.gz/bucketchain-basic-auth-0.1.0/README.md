# purescript-bucketchain-basic-auth

[![Latest release](http://img.shields.io/github/release/Bucketchain/purescript-bucketchain-basic-auth.svg)](https://github.com/Bucketchain/purescript-bucketchain-basic-auth/releases)

A basic authentication middleware of [Bucketchain](https://github.com/Bucketchain/purescript-bucketchain).

## Installation

```
bower install purescript-bucketchain-basic-auth
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-bucketchain-basic-auth).

## LICENSE

MIT
