# purescript-codec-json

[![Latest release](http://img.shields.io/github/release/garyb/purescript-codec-json.svg)](https://github.com/garyb/purescript-codec-json/releases)
![Build Status](https://github.com/garyb/purescript-codec-json/actions/workflows/ci.yml/badge.svg)

Bi-directional codecs for [json](https://github.com/purescript/purescript-json).

## Installation

```
bower install purescript-codec-json
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-codec-json).
