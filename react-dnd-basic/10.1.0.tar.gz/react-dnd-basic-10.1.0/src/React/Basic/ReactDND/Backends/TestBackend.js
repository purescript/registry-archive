import { TestBackend } from "react-dnd-test-backend";

export const testBackend = TestBackend;
