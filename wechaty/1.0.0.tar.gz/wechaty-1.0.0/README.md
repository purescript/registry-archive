# purescript-wechaty
[WIP!] PureScript bindings to the wechaty library
