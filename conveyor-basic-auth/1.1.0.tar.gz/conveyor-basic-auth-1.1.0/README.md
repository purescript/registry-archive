# purescript-conveyor-basic-auth

[![Latest release](http://img.shields.io/github/release/oreshinya/purescript-conveyor-basic-auth.svg)](https://github.com/oreshinya/purescript-conveyor-basic-auth/releases)

Basic authentication for [conveyor](https://github.com/oreshinya/purescript-conveyor).

## Installation

```
bower install purescript-conveyor-basic-auth
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-conveyor-basic-auth).

## LICENSE

MIT
