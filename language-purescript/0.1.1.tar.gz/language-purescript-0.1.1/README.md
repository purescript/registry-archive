# purescript-language-purescript

Types and codecs for the PureScript programming language written in PureScript.

## License

This repo ports part of the code from [PureScript](https://github.com/purescript/purescript), which is licensed under [BSD-3-Clause](https://github.com/purescript/purescript/blob/master/LICENSE) and made possible by its amazing [contributors](https://github.com/purescript/purescript/blob/master/CONTRIBUTORS.md).

This repo ports [bower-json](https://github.com/hdgarrood/bower-json), which is licensed under [MIT](https://github.com/hdgarrood/bower-json/blob/master/LICENSE) thanks to [hdgarood](https://github.com/hdgarrood).

