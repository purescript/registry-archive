# purescript-react-dnd-basic

[react-basic](https://github.com/lumihq/purescript-react-basic) bindings for [react-dnd](https://react-dnd.github.io/react-dnd/)

## Docs

Available on [Pursuit](https://pursuit.purescript.org/packages/purescript-react-dnd-basic)

## Example

```purescript
module Example where
```
