# purescript-react-dnd-basic

[react-basic](https://github.com/lumihq/purescript-react-basic) bindings for [react-dnd](https://react-dnd.github.io/react-dnd/) _*v11*_

## Docs

Available on [Pursuit](https://pursuit.purescript.org/packages/purescript-react-dnd-basic)

## Example

- [Basic](examples/basic/src/Basic.purs)
