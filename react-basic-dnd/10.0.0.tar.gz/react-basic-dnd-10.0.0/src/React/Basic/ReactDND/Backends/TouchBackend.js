import { TouchBackend } from "react-dnd-touch-backend";

export const touchBackend = TouchBackend;
