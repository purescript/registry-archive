"use strict";

exports.html5Backend = require("react-dnd-html5-backend").HTML5Backend;
