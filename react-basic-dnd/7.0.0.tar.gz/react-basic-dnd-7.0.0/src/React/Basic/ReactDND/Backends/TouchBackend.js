"use strict";

exports.touchBackend = require("react-dnd-touch-backend").TouchBackend;
