"use strict";

exports.testBackend = require("react-dnd-test-backend").TestBackend;
