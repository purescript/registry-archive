import { HTML5Backend } from "react-dnd-html5-backend";

export const html5Backend = HTML5Backend;
