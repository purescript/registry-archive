# purescript-codec-argonaut

[![Latest release](http://img.shields.io/github/release/garyb/purescript-codec-argonaut.svg)](https://github.com/slamdata/purescript-codec-argonaut/releases)
[![Build Status](https://travis-ci.org/garyb/purescript-codec-argonaut.svg?branch=master)](https://travis-ci.org/garyb/purescript-codec-argonaut)

Bi-directional codecs for [argonaut](https://github.com/purescript-contrib/purescript-argonaut-core).

## Installation

```
bower install purescript-codec-argonaut
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-codec-argonaut).
