# purescript-jquery-slider


No documentation yet, but checkout the examples - there's one for vanilla purescript and one for halogen.


# for development:
to build the halogen example do: `pulp browserify --main HalogenExample -I examples/halogenExample/src/ --to examples/halogenExample/example.js`

to build the vanilla purescript example do: `pulp browserify --main Example -I examples/example/src --to examples/example/example.js`
