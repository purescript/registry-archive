# purescript-jquery-slider


No documentation yet, but checkout the examples - there's one for vanilla purescript and one for halogen.


# for development:
to build the halogen example do: `pulp browserify --main Example -I example/ --to example/example.js`
to build the halogen example do: `pulp browserify --main HalogenExample -I halogenExample/ --to halogenExample/example.js`
