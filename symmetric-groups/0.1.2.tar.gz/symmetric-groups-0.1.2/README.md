# purescript-symmetric-groups

This library provides a data type for finitary permutations. See the [API
docs on Pursuit][] for more information.

[API docs on Pursuit]: https://pursuit.purescript.org/packages/purescript-symmetric-groups
