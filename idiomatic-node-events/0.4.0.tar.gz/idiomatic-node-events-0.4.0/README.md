# purescript-idiomatic-node-events
An idiomatic wrapper for Node's Events API.
