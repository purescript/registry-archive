# purescript-numberfield

Computation with extension fields of the field of rational numbers 

* minimal polynomials of sum of algebraic numbers,
* algebraic reduction of rational expressions


## Documentation on Pursuit

https://pursuit.purescript.org/packages/purescript-numberfield
