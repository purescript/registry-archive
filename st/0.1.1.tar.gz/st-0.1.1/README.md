# purescript-st

[![Latest release](http://img.shields.io/bower/v/purescript-st.svg)](https://github.com/purescript/purescript-st/releases)
[![Build Status](https://travis-ci.org/purescript/purescript-st.svg?branch=master)](https://travis-ci.org/purescript/purescript-st)
[![Dependency Status](https://www.versioneye.com/user/projects/55848ce7363861001d000358/badge.svg?style=flat)](https://www.versioneye.com/user/projects/55848ce7363861001d000358)

The ST effect, for safe local mutation. For use with compiler version >= 0.7.

## Installation

```
bower install purescript-st
```

## Module documentation

- [Control.Monad.ST](docs/Control/Monad/ST.md)
