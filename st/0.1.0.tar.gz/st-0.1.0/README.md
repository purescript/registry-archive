# purescript-st

[![Build Status](https://travis-ci.org/purescript/purescript-st.svg?branch=master)](https://travis-ci.org/purescript/purescript-st)

The ST effect, for safe local mutation. For use with compiler version >= 0.7.

## Installation

```
bower install purescript-st
```

## Module documentation

- [Control.Monad.ST](docs/Control.Monad.ST.md)
