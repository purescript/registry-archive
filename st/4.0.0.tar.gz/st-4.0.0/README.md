# purescript-st

[![Latest release](http://img.shields.io/github/release/purescript/purescript-st.svg)](https://github.com/purescript/purescript-st/releases)
[![Build status](https://travis-ci.org/purescript/purescript-st.svg?branch=master)](https://travis-ci.org/purescript/purescript-st)

The ST effect, for safe local mutation.

## Installation

```
bower install purescript-st
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-st).
