exports.part_move = MOVE;
exports.part_work = WORK;
exports.part_carry = CARRY;
exports.part_attack = ATTACK;
exports.part_ranged_attack = RANGED_ATTACK;
exports.part_tough = TOUGH;
exports.part_heal = HEAL;
exports.part_claim = CLAIM;

exports.bodypart_cost = BODYPART_COST;

