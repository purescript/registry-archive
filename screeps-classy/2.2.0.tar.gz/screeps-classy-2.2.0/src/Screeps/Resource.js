"use strict";
exports.resource_energy = RESOURCE_ENERGY;
exports.resource_power = RESOURCE_POWER;
