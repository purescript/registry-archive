"use strict";

exports.color_red = COLOR_RED;
exports.color_purple = COLOR_PURPLE;
exports.color_blue = COLOR_BLUE;
exports.color_cyan = COLOR_CYAN;
exports.color_green = COLOR_GREEN;
exports.color_yellow = COLOR_YELLOW;
exports.color_orange = COLOR_ORANGE;
exports.color_brown = COLOR_BROWN;
exports.color_grey = COLOR_GREY;
exports.color_white = COLOR_WHITE;

