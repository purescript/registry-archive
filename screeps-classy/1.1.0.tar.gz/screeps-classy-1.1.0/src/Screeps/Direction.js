exports.top          = TOP;
exports.top_right    = TOP_RIGHT;
exports.right        = RIGHT;
exports.bottom_right = BOTTOM_RIGHT;
exports.bottom       = BOTTOM;
exports.bottom_left  = BOTTOM_LEFT;
exports.left         = LEFT;
exports.top_left     = TOP_LEFT;
