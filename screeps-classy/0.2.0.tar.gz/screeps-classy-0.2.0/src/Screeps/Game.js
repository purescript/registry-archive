"use strict";

exports.getGameGlobal = function(){ return Game; }
