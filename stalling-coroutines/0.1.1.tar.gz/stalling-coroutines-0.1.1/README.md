### purescript-stalling-coroutines

Coroutines for stalling streams (equivalent to `ListT`). This can be used as an
alternative to `Control.Coroutine.Producer` that supports filtering.

    bower install purescript-stalling-coroutines

The project is built using `pulp`:

    pulp build
    pulp docs
    pulp test
