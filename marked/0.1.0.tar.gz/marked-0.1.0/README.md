# purescript-marked

PureScript Bindings to [marked.js](https://marked.js.org/)