export function name(file) { return file.name; }
export function lastModified(file) { return file.lastModified; }
