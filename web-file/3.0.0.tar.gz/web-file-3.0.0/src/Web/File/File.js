"use strict";

exports.name = function (file) { return file.name; };

exports.lastModified = function (file) { return file.lastModified; };
