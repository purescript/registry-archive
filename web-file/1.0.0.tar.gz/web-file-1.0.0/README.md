# purescript-web-file

[![Latest release](http://img.shields.io/github/release/purescript-web/purescript-web-file.svg)](https://github.com/purescript-web/purescript-web-file/releases)
[![Build status](https://travis-ci.org/purescript-web/purescript-web-file.svg?branch=master)](https://travis-ci.org/purescript-web/purescript-web-file)

Type definitions and low level interface implementations for the W3C File API.

## Installation

```
bower install purescript-web-file
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-web-file).
