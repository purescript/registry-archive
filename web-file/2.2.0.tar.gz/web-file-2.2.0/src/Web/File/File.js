"use strict";

exports.name = function (file) { return file.name; };
