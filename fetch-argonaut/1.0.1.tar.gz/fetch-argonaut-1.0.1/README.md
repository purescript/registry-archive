# purescript-fetch-argonaut

## Installation

```
spago install fetch-argonaut
```
