# purescript-day

Day Convolution of contravariant functors, based on 
<https://hackage.haskell.org/package/contravariant/docs/Data-Functor-Day.html>.

Documentation is available on [Pursuit](https://pursuit.purescript.org/packages/purescript-day).
