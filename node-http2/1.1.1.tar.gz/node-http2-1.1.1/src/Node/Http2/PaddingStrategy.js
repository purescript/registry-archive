export const paddingStrategyNone = constants.PADDING_STRATEGY_NONE;
export const paddingStrategyMax = constants.PADDING_STRATEGY_MAX;
