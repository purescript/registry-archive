# purescript-folds

[![Latest release](http://img.shields.io/bower/v/purescript-folds.svg)](https://github.com/paf31/purescript-folds/releases)
[![Build Status](https://travis-ci.org/paf31/purescript-folds.svg)](https://travis-ci.org/paf31/purescript-folds)

Applicative Folds, in the style of Gabriel Gonzalez' foldl library

- [Module Documentation](generated-docs/Control/Fold.md)
- [Example](test/Main.purs)
