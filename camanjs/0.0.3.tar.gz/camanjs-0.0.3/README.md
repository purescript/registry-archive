# Purescript Camanjs Wrapper
Tries to get the whole functionality of Camanjs canvas manipulation library into purescript.

## JS Dependencies
You have to make sure camanjs.full has to be present in your distribution

# Compile steps

## Installing dependencies via psc-package
```
# make install
```

## Build
```
# make build
```
