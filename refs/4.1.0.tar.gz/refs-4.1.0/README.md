# purescript-refs

[![Latest release](http://img.shields.io/github/release/purescript/purescript-refs.svg)](https://github.com/purescript/purescript-refs/releases)
[![Build status](https://travis-ci.org/purescript/purescript-refs.svg?branch=master)](https://travis-ci.org/purescript/purescript-refs)

Mutable value references.

## Installation

```
bower install purescript-refs
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-refs).
