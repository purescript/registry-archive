# purescript-refs

[![Build Status](https://travis-ci.org/purescript/purescript-refs.svg?branch=master)](https://travis-ci.org/purescript/purescript-refs)

Mutable value references.

## Installation

```
bower install purescript-refs
```

## Module documentation

- [Control.Monad.Eff.Ref](docs/Control.Monad.Eff.Ref.md)
- [Control.Monad.Eff.Ref.Unsafe](docs/Control.Monad.Eff.Ref.Unsafe.md)
