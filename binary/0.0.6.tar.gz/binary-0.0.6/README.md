# purescript-binary

[![Build Status](https://travis-ci.org/Unisay/purescript-binary.svg?branch=master)](https://travis-ci.org/Unisay/purescript-binary)

Binary encoding for PureScript

- [x] Data.Binary.Bit
- [x] Data.Binary.Nibble
- [x] Data.Binary.Byte
- [x] ∀ a. Fixed a => Array a
