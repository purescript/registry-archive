export const traceShow = a => {
	console.log(a);
	return a;
};
