# purescript-strongcheck-generics

[![Build Status](https://travis-ci.org/zudov/purescript-strongcheck-generics.svg?branch=master)](https://travis-ci.org/zudov/purescript-strongcheck-generics)

Generic deriving for `Arbitrary`/`CoArbitrary`, and generation of `GenericSpine`/`GenericSignature`.

## Installation

```shell
bower install purescript-strongcheck-generics
```

## Documentation

- [Test.StrongCheck.Generic](docs/Test/StrongCheck/Generic.md)
