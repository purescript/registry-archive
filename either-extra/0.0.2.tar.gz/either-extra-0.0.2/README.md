# purescript-either-extra
Some extra utilities for the Either type
