# purescript-either-extra
Some extra utilities for the Either type


Instead of using `catLefts` and `catRights`, you may also
want to consider using 
[Filterable](pursuit.purescript.org/packages/purescript-filterable/docs/Data.Filterable);
see the [related discussion](https://github.com/purescript/purescript-either/issues/38).
