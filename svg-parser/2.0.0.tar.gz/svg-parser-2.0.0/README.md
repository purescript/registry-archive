# purescript-svg-parser

<a href="https://pursuit.purescript.org/packages/purescript-svg-parser">
  <img src="https://pursuit.purescript.org/packages/purescript-svg-parser/badge"
       alt="purescript-svg-parser on Pursuit">
  </img>
</a>

A library to parse string to SVG.

Check [purescript-svg-parser-halogen](https://rnons.github.io/purescript-svg-parser-halogen) or [purescript-svg-parser-smolder](https://rnons.github.io/purescript-svg-parser-smolder) for examples.
